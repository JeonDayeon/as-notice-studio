(function(){
  'use strict';
  const favorites=['😀','😊','🙂','😎','🤔','🙋','👍','👎','👏','🙏','❤️','⭐','✨','💡','📌','📍','📱','💻','🖥️','⌨️','🖱️','🔌','🔋','⚡','🔧','⚙️','🛠️','🏠','🏢','📦','📝','📋','📁','📂','📎','✉️','📞','☎️','📅','🕒','⏱️','⏰','✅','☑️','✔️','❌','❗','❓','⚠️','ℹ️','🔴','🟠','🟡','🟢','🔵','🟣','⚪','⚫','⬆️','⬇️','⬅️','➡️','↔️','🔄','🔍','🔒','🔓','🚫','♻️','🌡️'];
  let dialog,choose;
  async function readFile(file){
    if(!file||file.size>5*1024*1024)throw new Error('5MB 이하 아이콘 이미지를 선택해 주세요.');
    if(!/^image\/(png|jpeg|webp|x-icon|vnd.microsoft.icon)$/i.test(file.type)&&!(/\.ico$/i.test(file.name)&&(!file.type||file.type==='application/octet-stream')))throw new Error('PNG·JPG·WebP·ICO 파일을 선택해 주세요.');
    const url=URL.createObjectURL(file);try{const image=new Image();image.src=url;await image.decode();const ratio=Math.min(1,512/Math.max(image.naturalWidth,image.naturalHeight));const c=document.createElement('canvas');c.width=Math.max(1,Math.round(image.naturalWidth*ratio));c.height=Math.max(1,Math.round(image.naturalHeight*ratio));c.getContext('2d').drawImage(image,0,0,c.width,c.height);return c.toDataURL('image/png');}finally{URL.revokeObjectURL(url);}
  }
  function open(onSelect){
    choose=onSelect;
    if(!dialog){dialog=document.createElement('dialog');dialog.className='modal icon-picker-modal';dialog.innerHTML=`<form method="dialog" class="modal-close-form"><button class="icon-button" aria-label="아이콘 선택 닫기">×</button></form><span class="eyebrow">YOUR ICON</span><h2>이모지 · 내 아이콘</h2><label class="field"><span class="field-label">이모지 직접 입력</span><input id="icon-emoji-input" type="text" maxlength="80" placeholder="여기를 누르고 Win + . 키로 골라 보세요"></label><p class="field-hint">윈도우 이모지 창에서 고르거나 복사해서 붙여넣으세요. 목록 밖의 이모지도 넣을 수 있습니다.</p><button class="button primary wide" id="apply-icon-emoji">입력한 이모지 넣기</button><div class="emoji-choices icon-emoji-grid"></div><div class="icon-upload-section"><strong>내 이미지 아이콘</strong><p class="field-hint">PNG·JPG·WebP·윈도우 ICO / 5MB 이하. PNG의 투명 배경을 유지합니다.</p><label class="button secondary wide">아이콘 파일 선택<input id="icon-custom-file" type="file" accept="image/png,image/jpeg,image/webp,.ico" hidden></label><p id="icon-picker-status" role="status"></p></div>`;document.body.append(dialog);
      const grid=dialog.querySelector('.icon-emoji-grid');for(const emoji of favorites){const b=document.createElement('button');b.type='button';b.textContent=emoji;b.setAttribute('aria-label','이모지 '+emoji);b.onclick=()=>select({icon:'emoji',emoji});grid.append(b);}
      dialog.querySelector('#apply-icon-emoji').onclick=()=>{const emoji=dialog.querySelector('#icon-emoji-input').value.trim();if(emoji)select({icon:'emoji',emoji});else dialog.querySelector('#icon-picker-status').textContent='이모지를 입력하거나 아래에서 골라 주세요.';};
      dialog.querySelector('#icon-custom-file').onchange=async e=>{if(!e.target.files[0])return;const input=e.target;input.disabled=true;try{const iconImage=await readFile(input.files[0]);select({icon:'image',iconImage});}catch(error){dialog.querySelector('#icon-picker-status').textContent=error.message||'아이콘 파일을 열지 못했습니다.';}finally{input.disabled=false;input.value='';}};
    }
    dialog.querySelector('#icon-emoji-input').value='';dialog.querySelector('#icon-picker-status').textContent='';dialog.showModal();
  }
  function select(value){const callback=choose;choose=null;dialog.close();callback?.(value);}
  window.IconPicker={open,readFile};
})();
