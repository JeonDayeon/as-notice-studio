(function () {
  'use strict';
  const states = new Map();
  const ITEM_NAMES = {text:'글',image:'사진',icon:'아이콘',shape:'도형'};
  const ICONS = {phone:'휴대폰',thermometer:'온도계',bolt:'번개',usb:'USB',wrench:'렌치',warning:'주의',check:'체크',clock:'시계',info:'안내',emoji:'이모지'};
  const esc = value => String(value == null ? '' : value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const copy = value => JSON.parse(JSON.stringify(value));
  const id = prefix => prefix+'-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,9);
  const defaultStyle = () => ({fill:'none',stroke:'none',strokeWidth:0,radius:6,opacity:1,blur:0});
  const makeCell = () => ({id:id('cell'),weight:1,padding:8,gap:8,verticalAlign:'start',style:defaultStyle(),items:[]});
  const makeRow = () => ({id:id('row'),gap:10,minHeight:0,cells:[makeCell()]});
  function makeItem(type,theme) {
    const item={id:id('item'),type,width:100,align:'left',style:defaultStyle()};
    if(type==='text')Object.assign(item,{text:'내용을 입력해 주세요.',fontSize:14,weight:400,color:'#26364a',lineHeight:1.5,listStyle:'plain'});
    if(type==='image')Object.assign(item,{src:'',height:120,fit:'contain',align:'center'});
    if(type==='icon')Object.assign(item,{icon:'info',size:40,color:theme.accent||'#0866e8',align:'center'});
    if(type==='shape'){Object.assign(item,{shape:'rect',height:60});item.style.fill=theme.accent||'#0866e8';}
    return item;
  }
  function getImage(value,assets) { const src=(assets&&assets[value])||value||'';return /^data:image\/(?:png|jpe?g|webp);base64,/i.test(src)?src:''; }
  function safeColor(value,fallback='#0866e8') { return /^#[0-9a-f]{6}$/i.test(value||'')?value:fallback; }
  function paintMode(value) { return value&&typeof value==='object'&&value.type==='linear'?'gradient':value==='none'||!value?'none':'solid'; }
  function textField(label,value,scope,path,options={}) {
    const attrs=`data-grid-scope="${esc(scope)}" data-grid-path="${esc(path)}"`;
    return `<label class="ge-field"><span>${esc(label)}</span>${options.area?`<textarea rows="${options.rows||4}" maxlength="10000" ${attrs}>${esc(value)}</textarea>`:`<input type="text" maxlength="500" ${attrs} value="${esc(value)}">`}${options.hint?`<small>${esc(options.hint)}</small>`:''}</label>`;
  }
  function numberField(label,value,scope,path,min,max,step=1,unit='') {
    return `<label class="ge-field"><span>${esc(label)}${unit?`<small>${esc(unit)}</small>`:''}</span><input type="number" data-grid-scope="${esc(scope)}" data-grid-path="${esc(path)}" min="${min}" max="${max}" step="${step}" value="${Number.isFinite(Number(value))?Number(value):min}"></label>`;
  }
  function selectField(label,value,scope,path,options) {
    return `<label class="ge-field"><span>${esc(label)}</span><select data-grid-scope="${esc(scope)}" data-grid-path="${esc(path)}">${options.map(([v,l])=>`<option value="${esc(v)}" ${String(value)===String(v)?'selected':''}>${esc(l)}</option>`).join('')}</select></label>`;
  }
  function rangeField(label,value,scope,path,min,max,step=1,unit='',factor=1) {
    return `<label class="ge-field ge-range"><span>${esc(label)}<output data-grid-readout="${esc(scope+'.'+path)}">${esc(value)}${esc(unit)}</output></span><input type="range" data-grid-scope="${esc(scope)}" data-grid-path="${esc(path)}" data-grid-factor="${factor}" data-grid-unit="${esc(unit)}" min="${min}" max="${max}" step="${step}" value="${esc(value)}"></label>`;
  }
  function paintField(label,key,value) {
    const mode=paintMode(value),from=mode==='gradient'?safeColor(value.from):safeColor(value),to=mode==='gradient'?safeColor(value.to,'#d8eaff'):'#d8eaff';
    let html=`<div class="ge-paint"><label class="ge-field"><span>${label}</span><select data-grid-paint="${key}" data-grid-paint-part="mode"><option value="none" ${mode==='none'?'selected':''}>없음</option><option value="solid" ${mode==='solid'?'selected':''}>단색</option><option value="gradient" ${mode==='gradient'?'selected':''}>그라데이션</option></select></label>`;
    if(mode!=='none')html+=`<div class="ge-color-pair"><label class="ge-field"><span>${mode==='gradient'?'시작 색상':'색상'}</span><input type="color" value="${from}" data-grid-paint="${key}" data-grid-paint-part="from" aria-label="${label} ${mode==='gradient'?'시작 색상':'색상'}"></label>${mode==='gradient'?`<label class="ge-field"><span>끝 색상</span><input type="color" value="${to}" data-grid-paint="${key}" data-grid-paint-part="to" aria-label="${label} 끝 색상"></label>`:''}</div>`;
    if(mode==='gradient')html+=`<label class="ge-field"><span>방향 <small>0° 가로 · 90° 세로</small></span><input type="number" min="0" max="360" step="15" value="${Number(value.angle)||0}" data-grid-paint="${key}" data-grid-paint-part="angle"></label>`;
    return html+'</div>';
  }
  function mount(container,ctx) {
    if(!ctx?.block?.grid){container.innerHTML='<div class="ge-empty">칸 구성을 시작할 블록을 선택해 주세요.</div>';return;}
    const block=ctx.block,grid=block.grid;
    const state=states.get(block.id)||{target:ctx.itemId?'item':'block',details:{}};
    if(container.dataset.gridBlockId===block.id)container.querySelectorAll('details[data-grid-details]').forEach(d=>state.details[d.dataset.gridDetails]=d.open);
    states.set(block.id,state);container.dataset.gridBlockId=block.id;
    const row=grid.rows.find(r=>r.id===ctx.rowId)||grid.rows[0];
    const cell=row?.cells.find(c=>c.id===ctx.cellId)||row?.cells[0];
    const item=cell?.items.find(i=>i.id===ctx.itemId)||cell?.items[0];
    const rowIndex=grid.rows.indexOf(row),cellIndex=row?.cells.indexOf(cell)??-1,itemIndex=cell?.items.indexOf(item)??-1;
    if(state.target==='item'&&!item)state.target='cell';if(state.target==='cell'&&!cell)state.target='block';
    const objectFor = scope => scope==='grid'?grid:scope==='block'?block:scope==='row'?row:scope==='cell'?cell:scope==='item'?item:scope==='style'?styleOwner():null;
    function styleOwner(){return state.target==='item'?item:state.target==='cell'?cell:grid;}
    const style=styleOwner()?.style||defaultStyle();
    const open = (key,fallback=false) => state.details[key]??fallback?' open':'';
    const detail = (key,title,html,fallback=false) => `<details class="ge-details" data-grid-details="${key}"${open(key,fallback)}><summary>${title}</summary><div class="ge-detail-content">${html}</div></details>`;
    const selection = (r=row,c=cell,i=item) => ({rowId:r?.id||null,cellId:c?.id||null,itemId:i?.id||null});
    const refresh = () => mount(container,ctx);
    const change=(fn,rerender=false)=>ctx.change(fn,rerender);
    const select=(r,c,i)=>ctx.select(selection(r,c,i));

    let layout=`<label class="ge-field"><span>행 선택 <small>${grid.rows.length}개 행</small></span><select data-grid-row-select>${grid.rows.map((r,i)=>`<option value="${esc(r.id)}" ${r===row?'selected':''}>${i+1}행 · ${r.cells.length}칸</option>`).join('')}</select></label>`;
    layout+=`<div class="ge-row-tools"><button data-grid-action="add-row">＋ 행 추가</button><button data-grid-action="row-up" ${rowIndex<=0?'disabled':''} aria-label="행 위로">↑</button><button data-grid-action="row-down" ${rowIndex>=grid.rows.length-1?'disabled':''} aria-label="행 아래로">↓</button><button data-grid-action="delete-row" class="ge-danger" ${grid.rows.length<=1?'disabled':''}>행 삭제</button></div>`;
    if(row){
      layout+=`<div class="ge-caption">한 줄 나누기</div><div class="ge-columns">${[1,2,3,4,5,6].map(n=>`<button data-grid-columns="${n}" class="${row.cells.length===n?'active':''}"><span>${'▯'.repeat(n)}</span>${n}칸</button>`).join('')}</div><p class="ge-hint">칸을 줄여도 내용은 마지막 칸으로 모아집니다.</p>`;
      layout+=`<div class="ge-cell-tabs">${row.cells.map((c,i)=>`<button data-grid-cell="${esc(c.id)}" class="${c===cell?'active':''}">${i+1}칸</button>`).join('')}</div>`;
      if(row.cells.length>1)layout+=`<div class="ge-row-tools ge-ratios"><button data-grid-ratio="equal">같은 비율</button>${row.cells.length===2?'<button data-grid-ratio="left">왼쪽 넓게</button><button data-grid-ratio="right">오른쪽 넓게</button>':''}</div>`;
      if(cell){layout+=rangeField('선택한 칸의 비율',cell.weight||1,'cell','weight',.25,20,.25,'배');layout+=selectField('세로 정렬',cell.verticalAlign||'start','cell','verticalAlign',[['start','위쪽'],['center','가운데'],['end','아래쪽']]);}
      layout+=numberField('행의 최소 높이',row.minHeight||0,'row','minHeight',0,600,10,'px · 0은 자동');
    }
    let contents='';
    if(cell){
      contents+=`<div class="ge-caption">${rowIndex+1}행 · ${cellIndex+1}칸의 내용</div><div class="ge-item-list">${cell.items.length?cell.items.map((i,n)=>`<button class="ge-item ${i===item?'active':''}" data-grid-item="${esc(i.id)}" aria-label="${esc(ITEM_NAMES[i.type]||'요소')} ${n+1}: ${esc(i.text?.split('\n')[0]||ITEM_NAMES[i.type]||'요소')}"><b>${esc(ITEM_NAMES[i.type]||'요소')}</b><span>${esc(i.type==='text'?i.text?.split('\n')[0]||'빈 글':i.type==='icon'?ICONS[i.icon]||'아이콘':i.type==='shape'?({rect:'사각형',ellipse:'원형',line:'선'}[i.shape]||'도형'):'선택한 사진')}</span></button>`).join(''):'<div class="ge-empty-cell">이 칸에 내용을 넣어 주세요.</div>'}</div><div class="ge-add-items">${Object.entries(ITEM_NAMES).map(([type,label])=>`<button data-grid-add-item="${type}">＋ ${label}</button>`).join('')}</div>`;
      if(item){
        contents+=`<div class="ge-item-tools"><button data-grid-action="item-up" ${itemIndex<=0?'disabled':''}>↑</button><button data-grid-action="item-down" ${itemIndex>=cell.items.length-1?'disabled':''}>↓</button><button data-grid-action="copy-item">복사</button><button data-grid-action="delete-item" class="ge-danger">삭제</button></div>`;
        if(item.type==='text'){
          contents+=textField('글 내용',item.text,'item','text',{area:true,rows:6})+`<div class="ge-two-fields">${numberField('글자 크기',item.fontSize||14,'item','fontSize',8,48,1,'px')}${selectField('굵기',item.weight||400,'item','weight',[[400,'보통'],[500,'중간'],[600,'약간 굵게'],[700,'굵게'],[800,'아주 굵게']])}</div>`;
          contents+=`<label class="ge-field"><span>글자 색상</span><input type="color" data-grid-scope="item" data-grid-path="color" value="${safeColor(item.color,'#26364a')}" aria-label="글자 색상"></label>`;
          contents+=selectField('목록 표시',item.listStyle||'plain','item','listStyle',[['plain','일반 글'],['bullet','글머리표 목록']]);
          contents+=numberField('줄 간격',item.lineHeight||1.5,'item','lineHeight',1,2.2,.05,'배');
        } else if(item.type==='image'){
          const url=getImage(item.src,ctx.assets);
          contents+=`<div class="ge-photo">${url?`<img src="${esc(url)}" alt="선택한 사진">`:'<span>사진을 선택해 주세요.</span>'}</div><label class="ge-upload">사진 ${url?'바꾸기':'넣기'}<input type="file" data-grid-image accept="image/png,image/jpeg,image/webp" hidden></label>`;
          contents+=rangeField('사진 높이',item.height||120,'item','height',30,420,5,'px')+selectField('사진 맞춤',item.fit||'contain','item','fit',[['contain','사진 전체 보이기'],['cover','칸에 꽉 채우기']]);
        } else if(item.type==='icon'){
          contents+=selectField('아이콘',item.icon||'info','item','icon',Object.entries(ICONS))+rangeField('아이콘 크기',item.size||40,'item','size',16,110,2,'px');
          if(item.icon!=='emoji')contents+=`<label class="ge-field"><span>아이콘 색상</span><input type="color" data-grid-scope="item" data-grid-path="color" value="${safeColor(item.color)}" aria-label="아이콘 색상"></label>`;
          if(item.icon==='emoji')contents+='<p class="ge-hint">이모지는 한 개씩 표시되며 기기의 기본 색상을 사용합니다.</p>'+textField('이모지 입력',item.emoji||'❗','item','emoji')+'<div class="emoji-choices">'+['❗','⚠️','💡','✅','📱','🔌','🔧','🔋','ℹ️','⏱️'].map(emoji=>`<button data-grid-emoji="${emoji}" aria-label="이모지 ${emoji}">${emoji}</button>`).join('')+'</div>';
        } else if(item.type==='shape'){
          contents+=selectField('도형 종류',item.shape||'rect','item','shape',[['rect','사각형'],['ellipse','원형'],['line','가로 선']])+rangeField('도형 높이',item.height||60,'item','height',4,300,2,'px');
        }
        contents+=selectField('가로 정렬',item.align||'left','item','align',[['left','왼쪽'],['center','가운데'],['right','오른쪽']])+rangeField('칸 안의 너비',item.width||100,'item','width',10,100,5,'%');
        contents+=`<label class="ge-field"><span>다른 칸으로 옮기기</span><select data-grid-move-to>${grid.rows.flatMap((r,ri)=>r.cells.map((c,ci)=>`<option value="${esc(c.id)}" ${c===cell?'selected':''}>${ri+1}행 · ${ci+1}칸</option>`)).join('')}</select></label>`;
      }
    }else contents='<p class="ge-hint">먼저 행과 칸을 선택해 주세요.</p>';
    let styles=`<label class="ge-field"><span>디자인할 대상</span><select data-grid-style-target><option value="block" ${state.target==='block'?'selected':''}>블록 전체</option><option value="cell" ${state.target==='cell'?'selected':''} ${!cell?'disabled':''}>선택한 칸</option><option value="item" ${state.target==='item'?'selected':''} ${!item?'disabled':''}>선택한 요소</option></select></label>`;
    styles+=paintField('채우기','fill',style.fill)+paintField('선','stroke',style.stroke);
    styles+=rangeField('선 두께',style.strokeWidth||0,'style','strokeWidth',0,16,.5,'px')+rangeField('모서리 둥글기',style.radius??6,'style','radius',0,40,1,'px')+rangeField('불투명도',Math.round((style.opacity??1)*100),'style','opacity',0,100,1,'%',.01)+rangeField('블러',style.blur||0,'style','blur',0,24,.5,'px');
    styles+='<p class="ge-hint">블러를 높이면 글이나 사진이 흐려집니다. 읽어야 할 안내 문구는 0을 권장합니다.</p>';
    let spacing=`<div class="ge-two-fields">${numberField('블록 안 여백',grid.padding??12,'grid','padding',0,50,1,'px')}${numberField('행 사이 간격',grid.gap??10,'grid','gap',0,40,1,'px')}</div>`;
    if(row)spacing+=numberField('칸 사이 간격',row.gap??10,'row','gap',0,40,1,'px');
    if(cell)spacing+=`<div class="ge-two-fields">${numberField('칸 안 여백',cell.padding||0,'cell','padding',0,40,1,'px')}${numberField('내용 사이 간격',cell.gap??8,'cell','gap',0,40,1,'px')}</div>`;
    container.innerHTML=`<div class="grid-editor"><div class="ge-heading"><span class="ge-eyebrow">BLOCK DESIGN</span><h2>칸 구성 · 디자인</h2><p>이 블록 안에서 내용을 배치합니다.<br>안내문의 큰 틀은 유지됩니다.</p><div class="ge-header-actions"><button data-grid-action="show-style" class="ge-gradient-shortcut">◐ 그라데이션 · 색상</button>${ctx.remove?'<button data-grid-action="remove-block" class="ge-danger">블록 삭제</button>':''}<button data-grid-action="save-block">내 블록에 저장</button><button data-grid-action="exit">나가기</button></div></div><div class="ge-content">${ctx.placementHTML||''}${textField('블록 이름',block.title||'새 블록','block','title')}${detail('layout','① 행과 칸 나누기',layout,true)}${detail('contents','② 칸 안에 내용 넣기',contents,true)}${detail('style','③ 채우기 · 선 · 그라데이션 · 효과',styles,false)}${detail('spacing','여백 · 간격',spacing,false)}<div class="ge-row-tools">${ctx.move?'<button data-grid-action="block-up">↑ 블록 위로</button><button data-grid-action="block-down">↓ 블록 아래로</button>':''}${ctx.restore?'<button data-grid-action="restore-layout">기본 배치로 복원</button>':''}</div></div></div>`;

    function stop(e){e.stopPropagation();}
    function assign(target,path,value){const keys=path.split('.');let owner=target;for(const key of keys.slice(0,-1)){if(!owner[key]||typeof owner[key]!=='object')owner[key]={};owner=owner[key];}owner[keys.at(-1)]=value;}
    function inputValue(el){if(el.type==='number'||el.type==='range'){const number=Number(el.value);const min=Number(el.min),max=Number(el.max);return Math.min(Number.isFinite(max)&&el.max!==''?max:Infinity,Math.max(Number.isFinite(min)&&el.min!==''?min:-Infinity,Number.isFinite(number)?number:0))*(Number(el.dataset.gridFactor)||1);}return el.value;}
    function updateProperty(el){
      const scope=el.dataset.gridScope,path=el.dataset.gridPath;let target=objectFor(scope);if(!target||!path)return;
      const value=inputValue(el);
      change(()=>{if(scope==='style'){target.style=Object.assign(defaultStyle(),target.style||{});assign(target.style,path,value);}else assign(target,path,value);if(path==='icon'&&value==='emoji'&&!target.emoji)target.emoji='❗';},path==='icon');
      container.querySelectorAll('[data-grid-readout]').forEach(output=>{if(output.dataset.gridReadout===scope+'.'+path)output.textContent=el.value+(el.dataset.gridUnit||'');});
    }
    function updatePaint(el){
      const owner=styleOwner();if(!owner)return;const key=el.dataset.gridPaint,part=el.dataset.gridPaintPart,old=owner.style?.[key],mode=paintMode(old);
      const from=mode==='gradient'?safeColor(old.from):safeColor(old),to=mode==='gradient'?safeColor(old.to,'#d8eaff'):'#d8eaff';let value;
      if(part==='mode')value=el.value==='none'?'none':el.value==='solid'?from:{type:'linear',from,to,angle:mode==='gradient'?Number(old.angle)||0:0};
      else if(mode==='gradient')value=Object.assign({},old,{[part]:part==='angle'?Math.min(360,Math.max(0,Number(el.value)||0)):el.value});
      else value=el.value;
      change(()=>{owner.style=Object.assign(defaultStyle(),owner.style||{});owner.style[key]=value;if(key==='stroke'&&value!=='none'&&!(owner.style.strokeWidth>0))owner.style.strokeWidth=1;},part==='mode');
    }
    container.oninput=e=>{const el=e.target;if(el.tagName==='SELECT')return;if(el.dataset.gridScope){stop(e);updateProperty(el);}else if(el.dataset.gridPaint&&el.dataset.gridPaintPart!=='mode'){stop(e);updatePaint(el);}};
    container.onchange=async e=>{
      const el=e.target;
      if(el.hasAttribute('data-grid-row-select')){stop(e);const r=grid.rows.find(r=>r.id===el.value);select(r,r?.cells[0],r?.cells[0]?.items[0]);}
      else if(el.hasAttribute('data-grid-move-to')&&item){stop(e);const targetRow=grid.rows.find(r=>r.cells.some(c=>c.id===el.value)),targetCell=targetRow?.cells.find(c=>c.id===el.value);if(targetCell&&targetCell!==cell){change(()=>{cell.items.splice(itemIndex,1);targetCell.items.push(item);},true);select(targetRow,targetCell,item);}}
      else if(el.hasAttribute('data-grid-style-target')){stop(e);state.target=el.value;refresh();}
      else if(el.dataset.gridPaint&&el.dataset.gridPaintPart==='mode'){stop(e);updatePaint(el);}
      else if(el.matches('select[data-grid-scope]')){stop(e);updateProperty(el);}
      else if(el.hasAttribute('data-grid-image')&&el.files[0]&&item){stop(e);const selected=item;el.disabled=true;try{const src=await ctx.pickImage(el.files[0]);change(()=>selected.src=src,true);ctx.notify('사진을 넣었습니다.');}catch(error){ctx.notify(error.message||'사진을 확인해 주세요.');el.disabled=false;}}
    };
    container.onclick=e=>{
      const button=e.target.closest('button');if(!button||!container.contains(button))return;const data=button.dataset;
      if(data.gridEmoji&&item){stop(e);change(()=>{item.icon='emoji';item.emoji=data.gridEmoji;},true);return;}
      if(data.gridCell){stop(e);const c=row.cells.find(c=>c.id===data.gridCell);select(row,c,c?.items[0]);return;}
      if(data.gridItem){stop(e);select(row,cell,cell.items.find(i=>i.id===data.gridItem));return;}
      if(data.gridColumns){stop(e);const count=Number(data.gridColumns);change(()=>{if(row.cells.length>count){const removed=row.cells.splice(count);row.cells[count-1].items.push(...removed.flatMap(c=>c.items||[]));}else while(row.cells.length<count)row.cells.push(makeCell());},true);select(row,row.cells[Math.min(cellIndex,count-1)],row.cells[Math.min(cellIndex,count-1)]?.items[0]);return;}
      if(data.gridRatio){stop(e);change(()=>{row.cells.forEach(c=>c.weight=1);if(data.gridRatio==='left')row.cells[0].weight=2;if(data.gridRatio==='right')row.cells[row.cells.length-1].weight=2;},true);return;}
      if(data.gridAddItem){stop(e);const next=makeItem(data.gridAddItem,ctx.model.theme||{});change(()=>cell.items.push(next),true);state.target='item';select(row,cell,next);return;}
      const action=data.gridAction;if(!action)return;stop(e);
      if(action==='show-style'){const panel=container.querySelector('[data-grid-details="style"]');if(panel){panel.open=true;state.details.style=true;panel.scrollIntoView({behavior:'smooth',block:'start'});}return;}
      if(action==='save-block'){ctx.saveLibrary(block);return;}
      if(action==='exit'){ctx.exit();return;}
      if(action==='restore-layout'){ctx.restore?.();return;}
      if(action==='block-up'||action==='block-down'){ctx.move?.(action==='block-up'?-1:1);return;}
      if(action==='remove-block'){ctx.remove?.();return;}
      if(action==='add-row'){const r=makeRow();change(()=>grid.rows.push(r),true);select(r,r.cells[0],null);return;}
      if(action==='delete-row'&&grid.rows.length>1){const index=grid.rows.indexOf(row);change(()=>grid.rows.splice(index,1),true);const next=grid.rows[Math.max(0,index-1)];select(next,next.cells[0],next.cells[0]?.items[0]);return;}
      if(action==='row-up'||action==='row-down'){const next=rowIndex+(action==='row-up'?-1:1);if(next>=0&&next<grid.rows.length)change(()=>{grid.rows.splice(rowIndex,1);grid.rows.splice(next,0,row);},true);return;}
      if(action==='copy-item'&&item){const next=copy(item);next.id=id('item');change(()=>cell.items.splice(itemIndex+1,0,next),true);select(row,cell,next);return;}
      if(action==='delete-item'&&item){change(()=>cell.items.splice(itemIndex,1),true);select(row,cell,cell.items[Math.min(itemIndex,cell.items.length-1)]);return;}
      if((action==='item-up'||action==='item-down')&&item){const next=itemIndex+(action==='item-up'?-1:1);if(next>=0&&next<cell.items.length)change(()=>{cell.items.splice(itemIndex,1);cell.items.splice(next,0,item);},true);}
    };
  }
  window.GridEditor={mount};
})();
