(function(){
  'use strict';
  let serial=0;const id=()=> 'faq-card-'+(++serial);
  const blue='#0866e8',ink='#132b49',body='#26364a';
  const st=extra=>Object.assign({fill:'none',stroke:'none',strokeWidth:0,radius:8,opacity:1,blur:0},extra);
  const t=(text,size=25,weight=400,color=body,extra={})=>Object.assign({id:id(),type:'text',text,fontSize:size,weight,color,width:100,align:'left',lineHeight:1.55,listStyle:'plain',style:st()},extra);
  const c=(items,extra={})=>Object.assign({id:id(),weight:1,padding:0,gap:12,verticalAlign:'start',style:st(),items},extra);
  const row=(cells,extra={})=>Object.assign({id:id(),gap:18,minHeight:0,cells},extra);
  const g=(rows,extra={})=>Object.assign({version:1,padding:26,gap:22,style:st({fill:'#ffffff',stroke:'#d6e4f4',strokeWidth:1.5,radius:16}),rows},extra);
  const icon=(name,color=blue)=>({id:id(),type:'icon',icon:name,color,size:42,height:46,width:100,align:'left',style:st()});
  const header=(title,name='phone',color=blue)=>row([c([icon(name,color)],{weight:1}),c([t(title,36,700,color)],{weight:20,verticalAlign:'center'})],{gap:14});
  const action=(n,title,body)=>c([t(n+'  '+title,27,700,ink),t(body,24)],{padding:20,gap:18,style:st({fill:'#f0f6ff',radius:12})});
  const table=(label,value,head=false)=>row([
    c([t(label,head?23:25,700,head?ink:blue)],{weight:2,padding:18,style:st({fill:head?'#eaf2fc':'#ffffff',stroke:'#dce8f5',strokeWidth:1,radius:0})}),
    c([t(value,head?23:25,head?700:400,head?ink:body)],{weight:9,padding:18,style:st({fill:head?'#eaf2fc':'#ffffff',stroke:'#dce8f5',strokeWidth:1,radius:0})})
  ],{gap:0});
  const warning=(n,title,text,action)=>c([t(n+'. '+title+':',27,700,ink),t(text,25)],{padding:22,gap:22,style:st({fill:'#fff8f2',radius:12})});
  const steps=()=>row([
    action('1','지원 기종 확인','휴대폰이 무선충전을 지원하는 기종인지 확인해 주세요.'),
    action('2','위치 · 케이스 확인','충전 위치에 정확히 올려놓고, 케이스를 제거한 상태에서 사용해 주세요.'),
    action('3','전원 리셋','그래도 충전되지 않는다면 전원을 리셋해 주세요.')
  ]);
  const warnings=()=>row([
    warning('1','카드 손상 및 발열 위험','케이스에 보관된 신용카드 등의 금속 성분이 무선충전 중 발열하여 카드가 손상되거나 변형될 수 있습니다.','케이스와 카드를 분리해 주세요.'),
    warning('2','충전 효율 저하 및 발열','두꺼운 케이스는 충전 거리를 증가시켜 충전 효율과 속도를 떨어뜨리고 발열을 증가시킬 수 있습니다.','두꺼운 케이스를 제거해 주세요.')
  ],{gap:22});
  const modelRows=()=>[table('구분','해당 기종',true),table('갤럭시 :','A시리즈, 퀀텀 3 • 4, 버디, 노트 4 포함 이전 모델'),table('아이폰 :','아이폰 7포함 이전 모델')];
  const block=(title,grid)=>({id:id(),type:'grid',title,grid});
  const faq=(title,name,text,color=blue)=>block(title,g([header(title,name,color),row([c([],{weight:1}),c([t(text,25,400,body,{listStyle:'bullet',bulletColor:blue})],{weight:20})],{gap:0})],{gap:18}));
  window.AS_FAQ_LAYOUTS={
    'steps-three':g([row([c([t('아래 순서대로 확인해 주세요.',29,700,ink)])]),steps()]),
    'model-table':g([row([c([t('지원하지 않는 기종은 다음과 같습니다.',29,700,ink)])]),...modelRows()],{gap:0}),
    'two-notices':g([header('충전 사용 시 주의 사항','warning','#e27a30'),row([c([t('휴대폰을 충전 위치에 정확히 올려놓고, 케이스를 제거한 상태에서 사용해 주세요.',25,500)])]),warnings()],{style:st({fill:'#ffffff',stroke:'#f0d7c7',strokeWidth:1.5,radius:16})})
  };
  const blocks=[
    block('안내문 머리말',g([row([c([t('사용 시 주의사항',44,800,'#ffffff')])])],{padding:26,style:st({fill:ink,radius:16})})),
    block('Q1. 무선충전이 되지 않아요.',g([
      header('Q1. 무선충전이 되지 않아요.'),
      row([c([t('아래 순서대로 확인해 주세요.',26,500,'#64748b')])]),steps(),
      row([c([t('지원하지 않는 기종은 다음과 같습니다.',29,700,ink)])]),
      ...modelRows()
    ],{gap:14})),
    block('충전 사용 시 주의 사항',JSON.parse(JSON.stringify(window.AS_FAQ_LAYOUTS['two-notices']))),
    faq('Q2. 제품이나 휴대폰이 따뜻해져요.','thermometer','무선충전 과정에서 일정 수준의 발열이 발생할 수 있습니다.\n휴대폰 케이스나 금속 부착물로 인해 발열이 증가하고, 열이 무선충전기로 전달되면서 제품이 손상될 수 있습니다.\n과도한 발열, 변형, 녹음 등이 발생하면 사용을 중단하고 점검을 요청해 주세요.','#ff1835'),
    faq('Q3. 충전 속도가 느려요.','bolt','본 제품의 무선충전기는 10W이며, 일반 초고속 충전기(25W)에 비해 충전 속도가 느릴 수 있습니다.\n휴대폰 기종 및 제조사의 충전 지원 조건에 따라 속도에 차이가 발생할 수 있습니다.','#ffad00'),
    faq('Q4. USB 충전이 느리거나 되지 않아요.','usb','USB 출력은 DC 5V / 총 최대 3.0A(15W)이며, 2개 포트의 합산 출력 기준입니다.\n태블릿, 노트북 등 높은 출력을 요구하는 기기는 전용 어댑터를 사용하여 충전하시길 바랍니다.\n연결된 기기의 소비전력에 따라 LED가 깜빡일 수 있으므로 다른 기능의 작동 여부도 함께 확인해 주세요.'),
    faq('Q5. 도색 벗겨짐, 케이스 불량, 스크래치, 설비 관련(제품 고정 안 됨), 뚜껑 파손 등도 AS 가능한가요?','wrench','당사는 PCB 제조 업체로, 제품의 기능 및 작동과 관련된 사항을 중심으로 AS를 지원하고 있습니다.\n도색 벗겨짐, 케이스 불량, 스크래치, 설비 관련 사항 등 외관 및 설치상의 문제는 당사에서 직접 처리하기 어려운 점 양해 부탁드립니다.')
  ];
  // Align Q1 and caution contents with the heading, and keep consistent card spacing.
  for(const b of blocks){b.gapAfter=24;}
  for(const b of [blocks[1],blocks[2]])for(const r of b.grid.rows.slice(1)){r.insetLeft=84;r.insetRight=12;}
  // Keep the shared heading blue, while each pictogram retains its original color.
  for(const b of blocks.slice(3))b.grid.rows[0].cells[1].items[0].color=blue;
  const model={schemaVersion:2,theme:{accent:blue,ink,fontScale:1},document:{id:'template-faq-cards-20261105',name:'무선충전 FAQ · 기종 표와 주의사항 카드',layout:{columns:1,width:1536},sections:[{id:'faq-cards',label:'사용 안내 · FAQ',title:'사용 시 주의사항',hideTitle:true,span:1,startNewRow:false,blocks}]}};
  window.AS_TEMPLATES.unshift({id:'faq-cards-20261105',name:'무선충전 FAQ · 기종 표와 주의사항 카드',description:'확인 순서 3칸 + 기종 안내 표 + 2열 주의사항. 글·표·카드를 각각 편집합니다.',model});
})();
