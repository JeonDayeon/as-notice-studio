(function(){
  'use strict';
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const id=()=> 'source-'+crypto.randomUUID();
  let pdfModule,ocrScript;
  const hex=a=>'#'+a.map(n=>Math.max(0,Math.min(255,Math.round(n))).toString(16).padStart(2,'0')).join('');
  function colors(ctx,b){
    const x=Math.max(0,Math.floor(b.x)-3),y=Math.max(0,Math.floor(b.y)-3),w=Math.min(ctx.canvas.width-x,Math.ceil(b.width)+6),h=Math.min(ctx.canvas.height-y,Math.ceil(b.height)+6),p=ctx.getImageData(x,y,w,h).data;
    const bins=new Map(),edge=new Map();
    for(let j=0;j<h;j++)for(let i=0;i<w;i++){const k=(j*w+i)*4,r=p[k],g=p[k+1],a=p[k+2],key=[r>>4,g>>4,a>>4].join(',');const dst=i<3||j<3||i>=w-3||j>=h-3?edge:bins;const v=dst.get(key)||[0,r,g,a];v[0]++;dst.set(key,v);}
    const bg=[...edge.values()].sort((a,b)=>b[0]-a[0])[0]||[0,255,255,255];const contrast=v=>Math.abs(v[1]-bg[1])+Math.abs(v[2]-bg[2])+Math.abs(v[3]-bg[3]);
    const fg=[...bins.values()].filter(v=>contrast(v)>120).sort((a,b)=>b[0]-a[0])[0]||[0,20,30,45];return {background:hex(bg.slice(1)),color:hex(fg.slice(1))};
  }
  function photos(ctx,regions){
    const tile=16,W=ctx.canvas.width,H=ctx.canvas.height,nx=Math.ceil(W/tile),ny=Math.ceil(H/tile),pix=ctx.getImageData(0,0,W,H).data,mask=new Uint8Array(nx*ny),seen=new Uint8Array(nx*ny);
    for(let cy=0;cy<ny;cy++)for(let cx=0;cx<nx;cx++){
      const x=cx*tile,y=cy*tile;if(regions.some(r=>x+tile>r.x-3&&x<r.x+r.width+3&&y+tile>r.y-3&&y<r.y+r.height+3))continue;
      let sum=0,sq=0,n=0;const hues=new Set();for(let j=y;j<Math.min(H,y+tile);j+=2)for(let i=x;i<Math.min(W,x+tile);i+=2){const k=(j*W+i)*4,v=(pix[k]+pix[k+1]+pix[k+2])/3;sum+=v;sq+=v*v;n++;hues.add((pix[k]>>4)*256+(pix[k+1]>>4)*16+(pix[k+2]>>4));}
      if(n&&Math.sqrt(Math.max(0,sq/n-(sum/n)**2))>10&&hues.size>9)mask[cy*nx+cx]=1;
    }
    // Bridge nearby textured tiles. Text regions remain excluded from candidates.
    const dense=mask.slice();for(let y=1;y<ny-1;y++)for(let x=1;x<nx-1;x++){let n=0;for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++)n+=mask[(y+dy)*nx+x+dx];if(n>=3)dense[y*nx+x]=1;}
    const result=[];
    for(let at=0;at<dense.length;at++)if(dense[at]&&!seen[at]){
      const queue=[at];seen[at]=1;let loX=nx,hiX=0,loY=ny,hiY=0;
      for(let q=0;q<queue.length;q++){const t=queue[q],x=t%nx,y=Math.floor(t/nx);loX=Math.min(loX,x);hiX=Math.max(hiX,x);loY=Math.min(loY,y);hiY=Math.max(hiY,y);for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const xx=x+dx,yy=y+dy,k=yy*nx+xx;if(xx>=0&&yy>=0&&xx<nx&&yy<ny&&dense[k]&&!seen[k]){seen[k]=1;queue.push(k);}}}
      const x=loX*tile,y=loY*tile,width=Math.min(W-x,(hiX-loX+1)*tile),height=Math.min(H-y,(hiY-loY+1)*tile);
      if(width>=90&&height>=60&&queue.length>20&&width*height<W*H*.55)result.push({id:id(),kind:'image',x,y,width,height,src:'',label:'사진 후보 '+(result.length+1)});
    }
    return result.sort((a,b)=>a.y-b.y||a.x-b.x).slice(0,40);
  }
  function loadOCR(){
    if(window.Tesseract)return Promise.resolve(window.Tesseract);
    if(!ocrScript)ocrScript=new Promise((resolve,reject)=>{const el=document.createElement('script');el.src='https://cdn.jsdelivr.net/npm/tesseract.js@6.0.1/dist/tesseract.min.js';el.onload=()=>resolve(window.Tesseract);el.onerror=()=>{ocrScript=null;el.remove();reject(new Error('글자 인식 도구를 불러오지 못했습니다. 인터넷 연결을 확인해 주세요.'));};document.head.append(el);});return ocrScript;
  }
  async function pdf(){if(!pdfModule){pdfModule=import('https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.min.mjs').catch(e=>{pdfModule=null;throw e;});}const lib=await pdfModule;lib.GlobalWorkerOptions.workerSrc='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.worker.min.mjs';return lib;}
  function canvas(w,h){const c=document.createElement('canvas');c.width=Math.round(w);c.height=Math.round(h);return c;}
  function splitLines(lines){
    return lines.flatMap(line=>{
      const words=(line.words||[]).filter(w=>w.text?.trim()&&w.bbox).sort((a,b)=>a.bbox.x0-b.bbox.x0);if(words.length<2)return [line];
      const heights=words.map(w=>w.bbox.y1-w.bbox.y0).sort((a,b)=>a-b),threshold=Math.max(12,heights[Math.floor(heights.length/2)]*.95),groups=[];let group=[];
      for(const word of words){if(group.length&&word.bbox.x0-group[group.length-1].bbox.x1>threshold){groups.push(group);group=[];}group.push(word);}if(group.length)groups.push(group);
      if(groups.length===1)return [line];
      return groups.map(g=>({text:g.map(w=>w.text.trim()).join(' '),confidence:g.reduce((a,w)=>a+(w.confidence||0),0)/g.length,bbox:{x0:Math.min(...g.map(w=>w.bbox.x0)),y0:Math.min(...g.map(w=>w.bbox.y0)),x1:Math.max(...g.map(w=>w.bbox.x1)),y1:Math.max(...g.map(w=>w.bbox.y1))}}));
    });
  }
  function normalize(source){
    if(!source||typeof source!=='object')throw new Error('가져온 페이지 형식을 확인해 주세요.');
    const data=s=>/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=\s]+$/.test(s||'')?s:'';
    const n=(v,a,b)=>Math.min(b,Math.max(a,Number(v)||a));
    const out={image:data(source.image),width:n(source.width,1,4000),height:n(source.height,1,6000),regions:[]};if(!out.image||out.image.length>16000000)throw new Error('가져온 페이지 사진을 확인해 주세요.');
    if(!Array.isArray(source.regions)||source.regions.length>700)throw new Error('페이지의 글상자·사진 수를 확인해 주세요.');
    const ids=new Set();out.regions=source.regions.map(r=>{const x=n(r.x,0,out.width-1),y=n(r.y,0,out.height-1),key=typeof r.id==='string'&&/^[a-zA-Z0-9_-]+$/.test(r.id)&&!ids.has(r.id)?r.id:id();ids.add(key);const v={id:key,kind:r.kind==='image'?'image':'text',x,y,width:n(r.width,1,out.width-x),height:n(r.height,1,out.height-y)};
      if(v.kind==='image'){v.src=data(r.src);v.label=String(r.label||'사진 후보').slice(0,100);}else{for(const k of ['text','originalText'])v[k]=String(r[k]||'').slice(0,2000);v.fontSize=n(r.fontSize,6,200);v.confidence=n(r.confidence,0,100);v.verified=r.verified===true;v.force=r.force===true;v.color=/^#[a-f0-9]{6}$/i.test(r.color||'')?r.color:'#142030';v.background=/^#[a-f0-9]{6}$/i.test(r.background||'')?r.background:'#ffffff';}return v;});return out;
  }
  async function analyze(file,{progress=()=>{},signal}={}){
    if(!file||file.size>25*1024*1024)throw new Error('25MB 이하의 PDF·PNG·JPG·WebP를 선택해 주세요.');
    const check=()=>{if(signal?.aborted)throw new Error('가져오기를 취소했습니다.');};check();
    const isPdf=file.type==='application/pdf'||/\.pdf$/i.test(file.name);if(!isPdf&&!/^image\/(png|jpeg|webp)$/.test(file.type))throw new Error('PDF·PNG·JPG·WebP 파일을 선택해 주세요.');
    let doc,bitmap,worker,activePage=1,total=1;const sections=[];
    try{
      if(isPdf){progress('PDF를 여는 중',0);const lib=await pdf();check();doc=await lib.getDocument({data:await file.arrayBuffer(),isEvalSupported:false}).promise;total=doc.numPages;if(total>5)throw new Error('한 번에 최대 5쪽을 가져올 수 있습니다. PDF를 나누어 선택해 주세요.');}
      else bitmap=await createImageBitmap(file);
      progress('한글 인식 도구 준비 중 · 첫 실행은 시간이 걸립니다',1);const T=await loadOCR();check();
      worker=await T.createWorker('kor+eng',1,{logger:m=>{if(m.status==='recognizing text')progress(`${activePage}/${total}쪽 · 글자 인식 중`,Math.round(((activePage-1)+m.progress)/total*90));}});
      const abort=()=>worker?.terminate().catch(()=>{});signal?.addEventListener('abort',abort,{once:true});
      await worker.setParameters({tessedit_pageseg_mode:'3',preserve_interword_spaces:'1',user_defined_dpi:'150'});
      for(activePage=1;activePage<=total;activePage++){
        check();let c;
        if(doc){const page=await doc.getPage(activePage),v=page.getViewport({scale:1}),scale=2000/Math.max(v.width,v.height),vp=page.getViewport({scale});c=canvas(vp.width,vp.height);await page.render({canvasContext:c.getContext('2d'),viewport:vp}).promise;}
        else{const scale=Math.min(2,2000/Math.max(bitmap.width,bitmap.height));c=canvas(bitmap.width*scale,bitmap.height*scale);const ctx=c.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,c.width,c.height);ctx.drawImage(bitmap,0,0,c.width,c.height);}
        check();const {data}=await worker.recognize(c,{}, {text:true,blocks:true});check();
        const lines=splitLines((data.blocks||[]).flatMap(b=>(b.paragraphs||[]).flatMap(p=>p.lines||[])));const ctx=c.getContext('2d',{willReadFrequently:true});
        const regions=lines.filter(l=>l.text?.trim()&&l.bbox&&l.bbox.x1-l.bbox.x0>2&&l.bbox.y1-l.bbox.y0>3).map(l=>{const b={x:Math.max(0,l.bbox.x0-2),y:Math.max(0,l.bbox.y0-2),width:l.bbox.x1-l.bbox.x0+4,height:l.bbox.y1-l.bbox.y0+4},text=l.text.trim();return {id:id(),kind:'text',...b,text,originalText:text,fontSize:(b.height-4)*1.15,confidence:l.confidence||0,verified:false,...colors(ctx,b)};});
        if(regions.length>650)throw new Error('글상자가 너무 많습니다. 한 페이지의 내용을 나눠 가져와 주세요.');
        progress(`${activePage}/${total}쪽 · 사진 영역 찾는 중`,Math.round(activePage/total*92));regions.push(...photos(ctx,regions));
        const block={id:id(),type:'reference',title:`${activePage}쪽 · 가져온 안내문`,source:normalize({image:c.toDataURL('image/jpeg',.96),width:c.width,height:c.height,regions})};
        sections.push({id:id(),label:activePage+'쪽',title:'',hideTitle:true,blocks:[block]});c.width=1;c.height=1;
      }
      progress('가져오기 완료 · 원본과 비교해 주세요',100);
      return {schemaVersion:2,theme:{accent:'#0866e8',ink:'#132b49',fontScale:1},document:{id:id(),name:file.name.replace(/\.[^.]+$/,'')+' · 가져온 안내문',layout:{columns:1,width:1536},sections}};
    }finally{bitmap?.close();if(worker)await worker.terminate().catch(()=>{});if(doc)await doc.destroy();}
  }
  function mount(container,ctx){
    const {block}=ctx,s=block.source,regions=s.regions;let r=regions.find(r=>r.id===ctx.itemId)||regions.find(r=>r.kind==='text'&&r.confidence>=80&&/[가-힣]/.test(r.text))||regions[0];const texts=regions.filter(r=>r.kind==='text'),uncertain=texts.filter(r=>r.confidence<80&&!r.verified).length;
    container.innerHTML=`<div class="inspector-heading"><span class="eyebrow">IMPORTED PAGE</span><h2>원본을 보며 수정</h2><p>글상자는 자동 인식한 내용입니다. 수정 전에는 원본 모습이 그대로 표시됩니다.</p></div><div class="inspector-content"><div class="info-note">글상자 ${texts.length}개 · 사진 후보 ${regions.length-texts.length}개${uncertain?`<br><b>인식 불확실 ${uncertain}개 · 모든 글 원본 대조 필요</b>`:''}<br>사진 후보 영역이 맞는지 확인한 뒤 교체하세요.</div><label class="field"><span class="field-label">수정할 글 · 사진</span><select data-ref-select>${regions.map((v,i)=>`<option value="${esc(v.id)}" ${v===r?'selected':''}>${v.kind==='image'?'▧ '+esc(v.label):`${v.confidence<80&&!v.verified?'⚠ ':''}${i+1}. ${esc(v.text.slice(0,30))}`}</option>`).join('')}</select></label>${r?.kind==='text'?`<label class="field"><span class="field-label">글 내용 ${r.confidence<80?'· 원본 대조 필요':''}</span><textarea rows="5" maxlength="2000" data-ref-text>${esc(r.text)}</textarea></label><p class="field-hint">글상자 위치는 원본에 맞춰 고정됩니다. 내용이 길면 글자 크기가 자동으로 줄어듭니다.</p><label class="field"><span class="field-label">글자 크기</span><input type="number" min="6" max="200" data-ref-font value="${r.fontSize.toFixed(1)}"></label><div class="color-row"><label class="field"><span class="field-label">글자 색상</span><input type="color" data-ref-color value="${r.color}"></label><label class="field"><span class="field-label">덮을 배경 색상</span><input type="color" data-ref-background value="${r.background}"></label></div><label class="toggle-field"><span>원본과 확인 완료</span><input type="checkbox" data-ref-verified ${r.verified?'checked':''}></label><button class="button secondary wide" data-ref-restore>원본 글자로 복원</button>`:r?`<div class="photo-field"><p class="field-hint">선택한 테두리가 사진 전체를 감싸는지 먼저 확인하세요.</p><label class="button secondary wide" role="button" tabindex="0">사진 교체<input type="file" hidden data-ref-photo accept="image/png,image/jpeg,image/webp"></label></div><button class="button secondary wide" data-ref-restore>원본 사진으로 복원</button>`:'<p>인식된 글상자가 없습니다. 원본 이미지는 보존됩니다.</p>'}${r?'<button class="button secondary wide" data-ref-ignore>이 영역을 인식에서 제외</button>':''}<button class="button secondary wide" data-ref-copy>인식한 글 복사</button><button class="button delete-block-top" data-ref-delete>페이지 블록 삭제</button></div>`;
    container.oninput=e=>{if(!r)return;const el=e.target;if(el.hasAttribute('data-ref-text'))ctx.change(()=>r.text=el.value);if(el.hasAttribute('data-ref-font'))ctx.change(()=>{r.fontSize=Math.min(200,Math.max(6,Number(el.value)||6));r.force=true;});for(const k of ['color','background'])if(el.hasAttribute('data-ref-'+k))ctx.change(()=>{r[k]=el.value;r.force=true;});};
    container.onchange=async e=>{const el=e.target;if(el.hasAttribute('data-ref-select'))ctx.select(el.value);if(el.hasAttribute('data-ref-verified')&&r)ctx.change(()=>r.verified=el.checked);if(el.hasAttribute('data-ref-photo')&&el.files[0]&&r?.kind==='image'){try{const src=await ctx.pickImage(el.files[0]);ctx.change(()=>r.src=src,true);}catch(error){ctx.notify(error.message);}}};
    container.onclick=e=>{const b=e.target.closest('button');if(!b)return;if(b.hasAttribute('data-ref-delete'))ctx.remove();if(b.hasAttribute('data-ref-ignore')&&r){const next=regions.find(v=>v!==r);ctx.change(()=>s.regions=s.regions.filter(v=>v!==r),true);if(next)ctx.select(next.id);ctx.notify('인식 영역에서 제외했습니다. 원본 내용은 그대로이며 되돌리기로 복구할 수 있습니다.');return;}if(b.hasAttribute('data-ref-restore')&&r)ctx.change(()=>{if(r.kind==='image')r.src='';else{r.text=r.originalText;r.force=false;}},true);if(b.hasAttribute('data-ref-copy'))navigator.clipboard.writeText(texts.map(t=>t.text).join('\n')).then(()=>ctx.notify('인식한 글을 복사했습니다.')).catch(()=>ctx.notify('글상자의 내용을 선택해 복사해 주세요.'));};
  }
  window.ReferenceImport={analyze,normalize,mount,splitLines};
})();
