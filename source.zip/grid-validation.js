(function () {
  'use strict';

  var serial = 0;
  var LIMITS = { rows: 40, cellsPerRow: 8, itemsPerCell: 100, totalItems: 500, textLength: 10000, emojiLength: 80, imageLength: 16000000 };
  var HEX = /^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i;
  var DATA_IMAGE = /^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/]*={0,2}$/i;
  var ICONS = ['phone', 'thermometer', 'bolt', 'usb', 'wrench', 'warning', 'check', 'clock', 'info', 'emoji', 'image'];

  function fail(message) { throw new Error(message); }
  function record(value, label) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) fail(label + ' 형식이 올바르지 않습니다.');
    return value;
  }
  function number(value, min, max, fallback, label) {
    if (value == null || value === '') return fallback;
    if (typeof value !== 'number' && typeof value !== 'string') fail(label + '에는 숫자를 입력해 주세요.');
    var result = Number(value);
    if (!Number.isFinite(result)) fail(label + '에는 유효한 숫자를 입력해 주세요.');
    return Math.min(max, Math.max(min, result));
  }
  function text(value, max, fallback, label) {
    var result = value == null ? fallback : String(value);
    if (result.length > max) fail(label + '은(는) ' + max + '자 이하로 입력해 주세요.');
    if (/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(result)) fail(label + '에 지원하지 않는 제어 문자가 있습니다.');
    return result.replace(/\r\n?/g, '\n');
  }
  function choice(value, allowed, fallback, label) {
    if (value == null || value === '') return fallback;
    if (allowed.indexOf(value) < 0) fail(label + ' 설정을 확인해 주세요.');
    return value;
  }
  function color(value, fallback, label) {
    if (value == null || value === '') return fallback;
    if (typeof value !== 'string' || !HEX.test(value)) fail(label + '은(는) 올바른 색상으로 지정해 주세요.');
    return value.toLowerCase();
  }
  function paint(value, fallback, label) {
    if (value == null || value === '') return fallback;
    if (value === 'none') return 'none';
    if (typeof value === 'string') return color(value, fallback, label);
    record(value, label);
    if (value.type !== 'linear') fail(label + '의 그라데이션 형식을 확인해 주세요.');
    return {
      type: 'linear',
      from: color(value.from, '#0866e8', label + ' 시작 색상'),
      to: color(value.to, '#e7f3ff', label + ' 끝 색상'),
      angle: number(value.angle, 0, 360, 0, label + ' 방향')
    };
  }
  function style(value, defaults) {
    var original = value == null ? {} : record(value, '디자인 설정');
    defaults = defaults || {};
    return {
      fill: paint(original.fill, defaults.fill || 'none', '채우기'),
      stroke: paint(original.stroke, defaults.stroke || 'none', '선 색상'),
      strokeWidth: number(original.strokeWidth, 0, 20, defaults.strokeWidth || 0, '선 두께'),
      radius: number(original.radius, 0, 100, defaults.radius == null ? 6 : defaults.radius, '모서리'),
      opacity: number(original.opacity, 0, 1, 1, '불투명도'),
      blur: number(original.blur, 0, 24, 0, '블러'),
      ...(original.strokePattern!=null?{strokePattern:choice(original.strokePattern,['solid','dashed','dotted'],'solid','선 모양')}:{}),
      ...(original.strokeSides!=null?{strokeSides:Array.isArray(original.strokeSides)?Array.from(new Set(original.strokeSides.map(v=>choice(v,['top','right','bottom','left'],null,'테두리 위치')))):(fail('테두리 위치 형식을 확인해 주세요.'))}:{}),
    };
  }
  function imageSource(value) {
    if (value == null || value === '') return '';
    if (typeof value !== 'string') fail('사진 데이터 형식이 올바르지 않습니다.');
    if (value.length > LIMITS.imageLength) fail('사진 데이터가 너무 큽니다. 편집기에서 사진을 다시 선택해 주세요.');
    var assets = window.AS_ASSETS || {};
    if (Object.prototype.hasOwnProperty.call(assets, value)) {
      if (typeof assets[value] !== 'string' || !DATA_IMAGE.test(assets[value].replace(/\s/g, ''))) fail('기본 사진 데이터를 확인해 주세요.');
      return value;
    }
    var source = value.replace(/\s/g, '');
    if (!DATA_IMAGE.test(source) || source.slice(source.indexOf(',') + 1).length === 0) fail('사진은 JPG, PNG, WebP 데이터 또는 기본 사진을 사용해 주세요.');
    return source;
  }
  function normalize(input) {
    var original = record(input, '블록 서식');
    if (original.version != null && original.version !== 1) fail('지원하지 않는 블록 서식 버전입니다.');
    if (!Array.isArray(original.rows) || !original.rows.length) fail('블록에는 한 개 이상의 행이 필요합니다.');
    if (original.rows.length > LIMITS.rows) fail('한 블록에는 최대 ' + LIMITS.rows + '개 행을 넣을 수 있습니다. 블록을 나누어 주세요.');
    var used = new Set(), totalItems = 0;
    function id(value, prefix) {
      var candidate = typeof value === 'string' ? value.replace(/[^A-Za-z0-9_-]/g, '').slice(0, 128) : '';
      if (!candidate || used.has(candidate)) {
        do { serial++; candidate = prefix + '-' + Date.now().toString(36) + '-' + serial.toString(36); } while (used.has(candidate));
      }
      used.add(candidate);
      return candidate;
    }
    function item(value) {
      var value = record(value, '요소');
      var type = choice(value.type, ['text', 'image', 'icon', 'shape'], null, '요소 종류');
      if (!type) fail('요소 종류를 선택해 주세요.');
      totalItems++;
      if (totalItems > LIMITS.totalItems) fail('한 블록에는 최대 ' + LIMITS.totalItems + '개 요소를 넣을 수 있습니다. 블록을 나누어 주세요.');
      var output = {
        id: id(value.id, 'item'), type: type,
        width: number(value.width, 10, 100, 100, '요소 너비'),
        align: choice(value.align, ['left', 'center', 'right'], type === 'text' ? 'left' : 'center', '요소 정렬'),
        style: style(value.style)
      };
      if (type === 'text') {
        output.text = text(value.text, LIMITS.textLength, '', '문구');
        if(value.spans!=null)output.spans=window.RichText.normalize(output.text,value.spans);
        output.fontSize = number(value.fontSize, 8, 72, 14, '글자 크기');
        output.weight = Math.round(number(value.weight, 400, 800, 400, '글자 굵기') / 100) * 100;
        output.color = color(value.color, '#26364a', '글자 색상');
        output.lineHeight = number(value.lineHeight, 1, 2.5, 1.5, '줄 간격');
        output.listStyle = choice(value.listStyle, ['plain', 'bullet'], 'plain', '목록');
        if (value.bulletColor != null) output.bulletColor = color(value.bulletColor, '#0866e8', '글머리표 색상');
      } else if (type === 'image') {
        output.src = imageSource(value.src);
        output.height = number(value.height, 16, 800, 120, '사진 높이');
        output.fit = choice(value.fit, ['contain', 'cover'], 'contain', '사진 맞춤');
      } else if (type === 'icon') {
        output.icon = choice(value.icon, ICONS, 'info', '아이콘');
        output.size = number(value.size, 8, 120, 36, '아이콘 크기');
        output.color = color(value.color, '#0866e8', '아이콘 색상');
        if (value.height != null) output.height = number(value.height, 16, 800, 48, '아이콘 칸 높이');
        if(output.icon==='image')output.iconImage=imageSource(value.iconImage);
        if (output.icon === 'emoji' || value.emoji != null) output.emoji = text(value.emoji, LIMITS.emojiLength, '😊', '아이콘 문구');
      } else {
        output.shape = choice(value.shape, ['rect', 'ellipse', 'line'], 'rect', '도형');
        output.height = number(value.height, 16, 800, 60, '도형 높이');
      }
      return output;
    }
    function cell(value) {
      var value = record(value, '칸');
      var items = value.items === undefined ? [] : value.items;
      if (!Array.isArray(items)) fail('칸 안의 요소 형식이 올바르지 않습니다.');
      if (items.length > LIMITS.itemsPerCell) fail('한 칸에는 최대 ' + LIMITS.itemsPerCell + '개 요소를 넣을 수 있습니다. 칸을 나누어 주세요.');
      return {
        id: id(value.id, 'cell'),
        weight: number(value.weight, 0.2, 20, 1, '칸 너비 비율'),
        padding: number(value.padding, 0, 48, 0, '칸 안쪽 여백'),
        gap: number(value.gap, 0, 48, 8, '요소 간격'),
        verticalAlign: choice(value.verticalAlign, ['start', 'center', 'end'], 'start', '세로 정렬'),
        style: style(value.style),
        items: items.map(item)
      };
    }
    return {
      version: 1,
      padding: number(original.padding, 0, 48, 13, '블록 안쪽 여백'),
      gap: number(original.gap, 0, 48, 9, '행 간격'),
      style: style(original.style, { fill: '#ffffff', stroke: '#dce8f5', strokeWidth: 1, radius: 8 }),
      rows: original.rows.map(function (value) {
        value = record(value, '행');
        if (!Array.isArray(value.cells) || !value.cells.length) fail('각 행에는 한 개 이상의 칸이 필요합니다.');
        if (value.cells.length > LIMITS.cellsPerRow) fail('한 행에는 최대 ' + LIMITS.cellsPerRow + '개 칸을 넣을 수 있습니다. 행을 나누어 주세요.');
        return {
          id: id(value.id, 'row'),
          gap: number(value.gap, 0, 48, 10, '칸 간격'),
          minHeight: number(value.minHeight, 0, 1200, 0, '행 최소 높이'),
          cells: value.cells.map(cell)
        };
      })
    };
  }
  window.GridValidator = { normalize: normalize, limits: Object.freeze(LIMITS) };
})();
