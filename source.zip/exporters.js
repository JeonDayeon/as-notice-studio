(function () {
  'use strict';

  // Keep the PDF entirely self-contained: the canvas already holds the Korean
  // text, selected font and photos, so no PDF font installation is required.
  var encoder = new TextEncoder();
  function ascii(value) { return encoder.encode(String(value)); }
  function decimal(value) { return String(Number(value.toFixed(4))); }

  function jpegBlob(canvas) {
    return new Promise(function (resolve, reject) {
      try {
        canvas.toBlob(function (blob) {
          if (blob && blob.size) resolve(blob);
          else reject(new Error('PDF용 이미지를 만들 수 없습니다. 이미지 크기를 줄여 다시 시도해 주세요.'));
        }, 'image/jpeg', 0.97);
      } catch (error) {
        reject(new Error('PDF용 이미지를 읽을 수 없습니다. 사진을 다시 선택한 뒤 저장해 주세요.'));
      }
    });
  }

  function assemble(jpeg, width, height, landscape) {
    var pageWidth = landscape ? 842 : 595;
    var pageHeight = landscape ? 595 : 842;
    var margin = 24;
    var ratio = Math.min((pageWidth - margin * 2) / width, (pageHeight - margin * 2) / height);
    var drawWidth = width * ratio;
    var drawHeight = height * ratio;
    var left = (pageWidth - drawWidth) / 2;
    var bottom = (pageHeight - drawHeight) / 2;
    var command = ascii('q\n' + decimal(drawWidth) + ' 0 0 ' + decimal(drawHeight) + ' ' + decimal(left) + ' ' + decimal(bottom) + ' cm\n/Im0 Do\nQ\n');
    var chunks = [];
    var offsets = [0];
    var size = 0;
    function append(bytes) { chunks.push(bytes); size += bytes.byteLength; }
    function begin(id) { offsets[id] = size; append(ascii(id + ' 0 obj\n')); }
    function end() { append(ascii('\nendobj\n')); }

    append(ascii('%PDF-1.4\n'));
    // The binary marker must be raw bytes, not UTF-8 encoded Unicode characters.
    append(new Uint8Array([0x25, 0xe2, 0xe3, 0xcf, 0xd3, 0x0a]));
    begin(1);
    append(ascii('<< /Type /Catalog /Pages 2 0 R >>'));
    end();
    begin(2);
    append(ascii('<< /Type /Pages /Kids [3 0 R] /Count 1 >>'));
    end();
    begin(3);
    append(ascii('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' + pageWidth + ' ' + pageHeight + '] /Resources << /ProcSet [/PDF /ImageC] /XObject << /Im0 5 0 R >> >> /Contents 4 0 R >>'));
    end();
    begin(4);
    append(ascii('<< /Length ' + command.byteLength + ' >>\nstream\n'));
    append(command);
    append(ascii('endstream'));
    end();
    begin(5);
    append(ascii('<< /Type /XObject /Subtype /Image /Width ' + width + ' /Height ' + height + ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Interpolate true /Length ' + jpeg.byteLength + ' >>\nstream\n'));
    append(jpeg);
    append(ascii('\nendstream'));
    end();
    begin(6);
    append(ascii('<< /Title (AS Notice) /Creator (AS Notice Editor) /Producer (AS Notice Editor) >>'));
    end();

    var xrefOffset = size;
    append(ascii('xref\n0 7\n0000000000 65535 f \n'));
    for (var id = 1; id <= 6; id++) {
      if (offsets[id] > 9999999999) throw new Error('PDF 파일이 너무 큽니다. 사진 크기를 줄여 주세요.');
      append(ascii(String(offsets[id]).padStart(10, '0') + ' 00000 n \n'));
    }
    append(ascii('trailer\n<< /Size 7 /Root 1 0 R /Info 6 0 R >>\nstartxref\n' + xrefOffset + '\n%%EOF\n'));
    return new Blob(chunks, { type: 'application/pdf' });
  }

  async function toPDF(canvas, options) {
    options = options || {};
    if (!canvas || typeof canvas.toBlob !== 'function' || !Number.isInteger(canvas.width) || !Number.isInteger(canvas.height) || canvas.width < 1 || canvas.height < 1) {
      throw new Error('PDF로 저장할 안내문을 먼저 만들어 주세요.');
    }
    var blob = await jpegBlob(canvas);
    var jpeg = new Uint8Array(await blob.arrayBuffer());
    if (jpeg.length < 4 || jpeg[0] !== 0xff || jpeg[1] !== 0xd8 || jpeg[jpeg.length - 2] !== 0xff || jpeg[jpeg.length - 1] !== 0xd9) {
      throw new Error('PDF용 이미지 변환에 실패했습니다. 최신 브라우저에서 다시 시도해 주세요.');
    }
    return assemble(jpeg, canvas.width, canvas.height, options.landscape === true);
  }

  window.NoticeExporter = { toPDF: toPDF };
})();
