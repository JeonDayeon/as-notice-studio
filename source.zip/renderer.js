(function () {
  'use strict';

  var FAMILY = '"Noto Sans KR", "Malgun Gothic", sans-serif';
  var measureCanvas = document.createElement('canvas');
  var measure = measureCanvas.getContext('2d');
  var imageCache = new Map();
  var svgSerial=0;

  function textValue(value) { return value == null ? '' : typeof value==='object'&&typeof value.text==='string'?value.text:String(value); }
  function richValue(block,key){var v=key.split('.').reduce((o,k)=>o?.[k],block),spans=block.textStyles?.[key];return spans?.length?{text:textValue(v),spans:spans}:v;}
  function escapeXml(value) {
    return textValue(value).replace(/[&<>"']/g, function (ch) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' })[ch];
    });
  }
  function safeColor(value, fallback) { return /^#(?:[0-9a-f]{3}|[0-9a-f]{4}|[0-9a-f]{6}|[0-9a-f]{8})$/i.test(value || '') ? value : fallback; }
  function number(value,fallback,min,max){var n=Number(value);return Number.isFinite(n)?Math.min(max==null?Infinity:max,Math.max(min==null?-Infinity:min,n)):fallback;}
  function paint(value,fallback){
    if(value&&typeof value==='object'&&value.type==='linear')return {type:'linear',from:safeColor(value.from,'#ffffff'),to:safeColor(value.to,'#0866e8'),angle:number(value.angle,0,0,360)};
    return value==='none'||value===''?'none':safeColor(value,fallback||'none');
  }
  function style(value){value=value||{};return {fill:paint(value.fill,'none'),stroke:paint(value.stroke,'none'),strokeWidth:number(value.strokeWidth,0,0,30),radius:number(value.radius,6,0,100),opacity:number(value.opacity,1,0,1),blur:number(value.blur,0,0,24),strokePattern:['dashed','dotted'].includes(value.strokePattern)?value.strokePattern:'solid',strokeSides:Array.isArray(value.strokeSides)?value.strokeSides.filter(v=>['top','right','bottom','left'].includes(v)):['top','right','bottom','left']};}
  function gradientPoints(bounds,value){var a=(Number(value.angle)||0)*Math.PI/180,dx=Math.cos(a)*.5,dy=Math.sin(a)*.5;return {x1:bounds.x+( .5-dx)*bounds.width,y1:bounds.y+(.5-dy)*bounds.height,x2:bounds.x+(.5+dx)*bounds.width,y2:bounds.y+(.5+dy)*bounds.height};}
  function imageSource(value) {
    var source = (window.AS_ASSETS && window.AS_ASSETS[value]) || value || '';
    return /^data:image\/(?:png|jpe?g|webp);base64,/i.test(source) ? source : '';
  }
  function font(size, weight, family) { return (weight || 400) + ' ' + size + 'px ' + (family||FAMILY); }
  function emojiValue(value){var s=textValue(value||'❗');try{return Array.from(new Intl.Segmenter(undefined,{granularity:'grapheme'}).segment(s),function(v){return v.segment;}).slice(0,1).join('');}catch(_){return Array.from(s).slice(0,1).join('');}}
  function wrapped(value, width, size, weight) {
    measure.font = font(size, weight);
    var result = [];
    textValue(value).split('\n').forEach(function (paragraph) {
      if (!paragraph) { result.push(''); return; }
      var line = '';
      Array.from(paragraph).forEach(function (ch) {
        var next = line + ch;
        if (line && measure.measureText(next).width > width) {
          // Prefer a nearby word boundary, retaining long Korean words safely.
          var split = line.lastIndexOf(' ');
          if (split > line.length * 0.45) {
            result.push(line.slice(0, split).trimEnd());
            line = line.slice(split + 1) + ch;
          } else { result.push(line.trimEnd()); line = ch; }
        } else { line = next; }
      });
      result.push(line.trimEnd());
    });
    return result.length ? result : [''];
  }

  function build(model, options) {
    options = options || {};
    var theme = model.theme || {};
    var scale = Math.min(1.35, Math.max(0.8, Number(theme.fontScale) || 1));
    var accent = safeColor(theme.accent, '#0866e8');
    var ink = safeColor(theme.ink, '#132b49');
    var colors = { accent: accent, ink: ink, text: '#26364a', muted: '#64748b', line: '#dce8f5', pale: '#edf7ff', red: '#ef233c', rose: '#fff7f7' };
    var sections = ((model.document || {}).sections || []).filter(function (s) { return options.view === 'all' || !options.view || s.id === options.view; });
    var all = options.view==='all'||(!options.view&&sections.length>1);
    var documentLayout=(model.document||{}).layout||{};
    var columns=all?Math.round(number(documentLayout.columns,3,1,4)):1;
    var margin = 8, gap = 12;
    var width=all?number(documentLayout.width,1536,600,6000):708;
    var available=width-margin*2-gap*(columns-1);
    var widths=all&&columns===3?[available*706/1496,available*376/1496,available*414/1496]:Array(columns).fill(available/columns);
    if (!sections.length) width = 708;
    var primitives = [], regions = [], warnings = [];
    var currentBlock = null;
    var fs = 13.2 * scale, lh = 19.5 * scale;
    function add(p) { p.blockId = currentBlock; primitives.push(p); return p; }
    function rect(x, y, w, h, fill, stroke, radius, strokeWidth) { return add({ type: 'rect', x: x, y: y, width: w, height: h, fill: fill || 'none', stroke: stroke || '', radius: radius == null ? 8 : radius, strokeWidth: strokeWidth || 1 }); }
    function circle(x, y, r, fill, stroke, strokeWidth) { return add({ type: 'circle', x: x, y: y, radius: r, fill: fill || 'none', stroke: stroke || '', strokeWidth: strokeWidth || 1 }); }
    function line(x1, y1, x2, y2, stroke, strokeWidth) { return add({ type: 'line', x1: x1, y1: y1, x2: x2, y2: y2, stroke: stroke || colors.accent, strokeWidth: strokeWidth || 2 }); }
    function text(x, y, str, size, weight, fill) { return add({ type: 'text', x: x, y: y + size, text: textValue(str), fontSize: size, weight: weight || 400, fill: fill || colors.text }); }
    function paragraph(x, y, str, w, size, weight, fill, leading) {
      if(str?.spans?.length)return drawRich(x,y,str,w,size,weight,fill,(leading||size*1.5)/size);
      var lines = wrapped(str, w, size, weight), lineHeight = leading || size * 1.5;
      lines.forEach(function (s, i) { text(x, y + i * lineHeight, s, size, weight, fill); });
      return lines.length * lineHeight;
    }
    function richPlan(value,w,size,weight,fill,leading,bullet){
      return window.RichText.layout(textValue(value),value.spans,w,{fontSize:size,weight:weight||400,color:fill||colors.text,lineHeight:leading||1.5},measureTextWidth,scale,bullet);
    }
    function drawRich(x,y,value,w,size,weight,fill,leading,bullet){
      var p=richPlan(value,w,size,weight,fill,leading,bullet),cy=y;
      p.lines.forEach(function(l){var px=x;if(l.bullet)circle(x-12,cy+l.size*.75,2.2,colors.accent);l.runs.forEach(function(r){text(px,cy+l.size-r.fontSize,r.text,r.fontSize,r.weight,r.color);px+=r.width;});cy+=l.height;});return p.height;
    }
    function paragraphHeight(value,w,size,weight,leading){return value?.spans?.length?richPlan(value,w,size,weight,colors.text,leading/size).height:wrapped(value,w,size,weight).length*leading;}
    function title(x, y, str, w, size, fill) {
      var size = size || 17 * scale;
      return paragraph(x, y, str, w, size, 700, fill || colors.accent, size * 1.35);
    }
    function bullets(x, y, str, w, size, fill, itemGap) {
      if(str?.spans?.length)return drawRich(x+15,y,str,w-15,size||fs,400,colors.text,1.48,true);
      var fontSize = size || fs, cy = y, itemGap = itemGap == null ? 4 : itemGap;
      textValue(str).split('\n').filter(function (s) { return s.trim(); }).forEach(function (s) {
        // A compact triangular-style marker formed from two short strokes.
        line(x + 2, cy + fontSize * .6, x + 5, cy + fontSize * .85, fill || colors.accent, 1.6);
        line(x + 5, cy + fontSize * .85, x + 2, cy + fontSize * 1.1, fill || colors.accent, 1.6);
        cy += paragraph(x + 15, cy, s, w - 15, fontSize, 400, colors.text, fontSize * 1.48) + itemGap;
      });
      return Math.max(0, cy - y - itemGap);
    }
    function image(x, y, w, h, value, focus, sectionId) {
      rect(x, y, w, h, '#eff4f8', '', 6);
      var source = imageSource(value);
      if (source) add({ type: 'image', x: x, y: y, width: w, height: h, href: source });
      else {
        var center = x + w / 2;
        rect(center - 13, y + h / 2 - 16, 26, 20, 'none', '#9eafc3', 3, 1.7);
        circle(center + 5, y + h / 2 - 10, 2.5, '#9eafc3');
        line(center - 11, y + h / 2 + 2, center - 2, y + h / 2 - 5, '#9eafc3', 1.7);
        text(center - 25, y + h / 2 + 11, '사진 넣기', 11 * scale, 500, colors.muted);
      }
      regions.push({ id: currentBlock, sectionId: sectionId, x: x, y: y, width: w, height: h, label: '사진 교체', focus: focus || 'image' });
    }
    function faqIcon(number, x, y) {
      var blue = colors.accent, red = '#ff1835', yellow = '#ffad00';
      if (number === 1) {
        rect(x + 9, y + 1, 20, 35, 'none', blue, 4, 2.5);
        line(x + 15, y + 6, x + 23, y + 6, blue, 2);
        line(x + 16, y + 31, x + 22, y + 31, blue, 1.8);
      } else if (number === 2) {
        rect(x + 15, y, 9, 29, '#ffffff', red, 5, 2.5);
        circle(x + 19.5, y + 31, 8.5, '#ffffff', red, 2.5);
        line(x + 19.5, y + 10, x + 19.5, y + 32, red, 3.2);
        circle(x + 19.5, y + 32, 4.5, red);
        line(x + 26, y + 8, x + 31, y + 8, red, 1.8);
        line(x + 26, y + 14, x + 31, y + 14, red, 1.8);
      } else if (number === 3) {
        var points = [[24,0],[8,23],[20,23],[14,43],[36,17],[24,17],[29,0],[24,0]];
        for (var i=0;i<points.length-1;i++) line(x+points[i][0],y+points[i][1],x+points[i+1][0],y+points[i+1][1],yellow,2.8);
      } else if (number === 4) {
        rect(x + 12,y + 1,14,16,'none',blue,2,2.5);
        rect(x + 8,y + 14,22,22,blue,'',4);
        line(x + 19,y + 36,x + 19,y + 43,blue,3.8);
        line(x + 19,y + 20,x + 19,y + 29,'#ffffff',1.8);
        line(x + 15,y + 24,x + 23,y + 24,'#ffffff',1.8);
      } else {
        line(x + 11,y + 34,x + 28,y + 17,blue,6);
        circle(x + 8,y + 37,5.3,'#ffffff',blue,2.6);
        circle(x + 30,y + 12,10,'#ffffff',blue,2.6);
        rect(x + 30,y - 1,15,15,'#ffffff','',0);
        line(x + 29,y + 4,x + 29,y + 12,blue,2.6);
        line(x + 29,y + 12,x + 37,y + 12,blue,2.6);
        circle(x + 8,y + 37,1.5,blue);
      }
    }
    function namedIcon(kind,x,y,size,color,emoji,iconImage){
      if(kind==='image'){var src=imageSource(iconImage);if(src)add({type:'image',x:x,y:y,width:size,height:size,href:src,fit:'contain',radius:0});return;}
      if(kind==='none')return;
      if(kind==='emoji'){var value=emojiValue(emoji),emojiFamily='"Segoe UI Emoji", "Apple Color Emoji", sans-serif',es=size||32;measure.font=font(es,400,emojiFamily);var ew=measure.measureText(value).width,fit=Math.min(1,es/Math.max(1,ew));var ep=text(x+(es-ew*fit)/2,y+(es-es*fit)/2,value,es*fit,400,color);ep.fontFamily=emojiFamily;return;}
      var first=primitives.length,faqNumber={phone:1,thermometer:2,bolt:3,usb:4,wrench:5}[kind];
      if(faqNumber)faqIcon(faqNumber,0,0);
      else if(kind==='clock'){circle(22,22,19,'none',color,3);line(22,22,22,9,color,3);line(22,22,33,22,color,3);}
      else if(kind==='check'){circle(22,22,19,color);line(12,22,19,29,'#ffffff',3);line(19,29,32,15,'#ffffff',3);}
      else{circle(22,22,19,color);text(kind==='warning'?17:18,2,kind==='warning'?'!':'i',29,800,'#ffffff');}
      var factor=(size||40)/44;
      primitives.slice(first).forEach(function(p){
        if(p.x!=null)p.x=x+p.x*factor;if(p.y!=null)p.y=y+p.y*factor;
        if(p.width!=null)p.width*=factor;if(p.height!=null)p.height*=factor;if(p.radius!=null)p.radius*=factor;
        if(p.x1!=null){p.x1=x+p.x1*factor;p.x2=x+p.x2*factor;p.y1=y+p.y1*factor;p.y2=y+p.y2*factor;}
        if(p.fontSize)p.fontSize*=factor;if(p.strokeWidth)p.strokeWidth*=factor;
        if(p.stroke&&p.stroke!=='none'&&p.stroke!=='#ffffff')p.stroke=color;
        if(p.fill&&p.fill!=='none'&&p.fill!=='#ffffff')p.fill=color;
      });
    }
    function gridBlock(b,sectionId,x,y,w){
      var g=b.grid||{},pad=number(g.padding,12,0,80),gGap=number(g.gap,10,0,80),inner=Math.max(1,w-pad*2),rows=Array.isArray(g.rows)?g.rows:[];
      var blockStyle=style(g.style),plans=[],height=pad*2;
      function itemPlan(item,cw){
        item=item||{};var iw=Math.max(1,cw*number(item.width,100,10,100)/100),s=style(item.style),ip=s.fill!=='none'?4:0;
        var p={item:item,width:iw,style:s,pad:ip,lines:[],fontSize:number(item.fontSize,14,6,120)*scale,lineHeight:0,height:0};
        p.lineHeight=p.fontSize*number(item.lineHeight,1.5,1,3);
        if(item.type==='text'){
          var bullet=item.listStyle==='bullet',tw=Math.max(1,iw-ip*2-(bullet?15:0));
          if(item.spans?.length){p.rich=richPlan(item,tw,p.fontSize,item.weight,item.color,number(item.lineHeight,1.5,1,3),bullet);p.height=p.rich.height+ip*2;return p;}
          textValue(item.text).split('\n').forEach(function(para){if(bullet&&!para.trim())return;var ls=wrapped(para,tw,p.fontSize,number(item.weight,400,100,900));ls.forEach(function(t,i){p.lines.push({text:t,bullet:bullet&&i===0});});});
          if(!p.lines.length)p.lines.push({text:'',bullet:false});p.height=p.lines.length*p.lineHeight+ip*2;
        }else if(item.type==='icon')p.height=number(item.height,number(item.size,40,12,300),12,600);
        else p.height=number(item.height,item.type==='shape'&&item.shape==='line'?6:120,1,2400);
        return p;
      }
      rows.forEach(function(r){
        var cells=Array.isArray(r.cells)?r.cells:[],rg=number(r.gap,10,0,80);
        if(cells.length>1)rg=Math.min(rg,Math.max(0,(inner-cells.length*12)/(cells.length-1)));
        var usable=Math.max(1,inner-rg*Math.max(0,cells.length-1)),total=cells.reduce(function(sum,c){return sum+number(c.weight,1,.05,100);},0)||1;
        var plan={row:r,gap:rg,cells:[],height:number(r.minHeight,0,0,5000)};
        cells.forEach(function(c){
          var cw=usable*number(c.weight,1,.05,100)/total,cp=Math.min(number(c.padding,8,0,80),cw/3),cg=number(c.gap,8,0,80),items=(Array.isArray(c.items)?c.items:[]).map(function(i){return itemPlan(i,Math.max(1,cw-cp*2));});
          var ch=items.reduce(function(sum,p){return sum+p.height;},0)+cg*Math.max(0,items.length-1)+cp*2;
          plan.cells.push({cell:c,width:cw,padding:cp,gap:cg,items:items,contentHeight:ch,style:style(c.style)});plan.height=Math.max(plan.height,ch);
        });
        plan.height=Math.max(plan.height,24);plans.push(plan);height+=plan.height;
      });
      height+=gGap*Math.max(0,plans.length-1);height=Math.max(54,height);
      function effects(s,bounds,fn,meta){
        var first=primitives.length;fn();
        if(s.opacity!==1||s.blur){var children=primitives.splice(first);add(Object.assign({type:'group',x:bounds.x,y:bounds.y,width:bounds.width,height:bounds.height,opacity:s.opacity,blur:s.blur,children:children},meta||{}));}
      }
      function background(bounds,s,extra){
        if(s.fill==='none'&&(s.stroke==='none'||!s.strokeWidth))return;
        var sides=s.strokeSides||['top','right','bottom','left'],partial=sides.length!==4;
        var p=rect(bounds.x,bounds.y,bounds.width,bounds.height,s.fill,partial?'none':s.stroke,s.radius,s.strokeWidth);p.strokeWidth=s.strokeWidth;if(s.strokePattern!=='solid')p.strokePattern=s.strokePattern;Object.assign(p,extra||{});
        if(partial&&s.stroke!=='none'&&s.strokeWidth){var x=bounds.x,y=bounds.y,w=bounds.width,h=bounds.height,edges={top:[x,y,x+w,y],right:[x+w,y,x+w,y+h],bottom:[x,y+h,x+w,y+h],left:[x,y,x,y+h]};sides.forEach(function(side){var v=edges[side],edge=line(v[0],v[1],v[2],v[3],s.stroke,s.strokeWidth);if(s.strokePattern!=='solid')edge.strokePattern=s.strokePattern;});}
      }
      function gridIcon(item,bounds,color){
        var sz=Math.min(number(item.size,40,12,300),bounds.width,bounds.height),ox=bounds.x+(item.align==='left'?0:item.align==='right'?bounds.width-sz:(bounds.width-sz)/2),oy=bounds.y+(bounds.height-sz)/2;
        namedIcon(item.icon||'info',ox,oy,sz,color,item.emoji,item.iconImage);
      }
      currentBlock=b.id;
      effects(blockStyle,{x:x,y:y,width:w,height:height},function(){
        background({x:x,y:y,width:w,height:height},blockStyle,{gridBackground:true});
        var ry=y+pad;
        plans.forEach(function(rp){
          var cx=x+pad;
          regions.push({id:b.id,sectionId:sectionId,rowId:rp.row.id,x:x+pad,y:ry,width:inner,height:rp.height,label:'행 설정'});
          rp.cells.forEach(function(cp){
            var bounds={x:cx,y:ry,width:cp.width,height:rp.height},cell=cp.cell;
            regions.push({id:b.id,sectionId:sectionId,rowId:rp.row.id,cellId:cell.id,x:cx,y:ry,width:cp.width,height:rp.height,label:'칸 설정'});
            effects(cp.style,bounds,function(){
              background(bounds,cp.style);
              var slack=Math.max(0,rp.height-cp.contentHeight),iy=ry+cp.padding+(cell.verticalAlign==='center'?slack/2:cell.verticalAlign==='end'?slack:0);
              cp.items.forEach(function(ip){
                var item=ip.item,align=item.align||'left',space=cp.width-cp.padding*2-ip.width,ix=cx+cp.padding+(align==='center'?space/2:align==='right'?space:0),ib={x:ix,y:iy,width:ip.width,height:ip.height};
                regions.push({id:b.id,sectionId:sectionId,rowId:rp.row.id,cellId:cell.id,itemId:item.id,x:ix,y:iy,width:ip.width,height:ip.height,label:item.type==='text'?textValue(item.text).slice(0,60)||'글자':item.type==='image'?'사진':item.type==='icon'?'아이콘':'도형'});
                effects(ip.style,ib,function(){
                  var elementFirst=primitives.length;
                  if(item.type==='shape'){
                    if(item.shape==='ellipse'){add({type:'ellipse',x:ix,y:iy,width:ip.width,height:ip.height,fill:ip.style.fill,stroke:ip.style.stroke,strokeWidth:ip.style.strokeWidth});}
                    else if(item.shape==='line'&&ip.style.stroke!=='none'&&ip.style.strokeWidth>0)line(ix,iy+ip.height/2,ix+ip.width,iy+ip.height/2,ip.style.stroke,ip.style.strokeWidth);
                    else background(ib,ip.style);
                  }else{
                    background(ib,ip.style);
                    if(item.type==='text'){
                      var color=safeColor(item.color,colors.text),bullet=item.listStyle==='bullet',tx=ix+ip.pad,ty=iy+ip.pad;
                      if(ip.rich)ip.rich.lines.forEach(function(l){
                        var contentW=ip.width-ip.pad*2-(bullet?15:0),px=tx+(bullet?15:0)+(align==='center'?(contentW-l.width)/2:align==='right'?contentW-l.width:0);
                        if(l.bullet)circle(tx+3,ty+l.size*.75,2.2,safeColor(item.bulletColor,color));
                        l.runs.forEach(function(r){text(px,ty+l.size-r.fontSize,r.text,r.fontSize,r.weight,r.color);px+=r.width;});ty+=l.height;
                      });else ip.lines.forEach(function(l){
                        var tw=measureTextWidth(l.text,ip.fontSize,number(item.weight,400,100,900));
                        var contentW=ip.width-ip.pad*2-(bullet?15:0),px=tx+(bullet?15:0)+(align==='center'?(contentW-tw)/2:align==='right'?contentW-tw:0);
                        if(l.bullet){circle(tx+3,ty+ip.fontSize*.75,2.2,safeColor(item.bulletColor,color));}
                        text(px,ty,l.text,ip.fontSize,number(item.weight,400,100,900),color);ty+=ip.lineHeight;
                      });
                    }else if(item.type==='image'){
                      var href=imageSource(item.src||item.href||'');
                      if(href)add({type:'image',x:ix,y:iy,width:ip.width,height:ip.height,href:href,fit:item.fit==='cover'?'cover':'contain',radius:ip.style.radius});
                      else{rect(ix,iy,ip.width,ip.height,'#eff4f8','#cbd8e6',ip.style.radius,1);paragraph(ix+8,iy+Math.max(4,(ip.height-16)/2),'사진 넣기',Math.max(1,ip.width-16),12,500,colors.muted,18);}
                    }else if(item.type==='icon')gridIcon(item,ib,safeColor(item.color,colors.accent));
                  }
                  if((item.type==='image'||(item.type==='icon'&&item.icon==='image'))&&ip.style.stroke!=='none'&&ip.style.strokeWidth)background(ib,Object.assign({},ip.style,{fill:'none'}));
                  primitives.slice(elementFirst).forEach(function(p){if(ip.style.strokePattern!=='solid'&&['rect','line','ellipse'].includes(p.type))p.strokePattern=ip.style.strokePattern;p.itemId=item.id;p.cellId=cell.id;p.rowId=rp.row.id;});
                },{itemId:item.id,cellId:cell.id,rowId:rp.row.id});
                iy+=ip.height+cp.gap;
              });
            },{cellId:cell.id,rowId:rp.row.id});
            cx+=cp.width+rp.gap;
          });ry+=rp.height+gGap;
        });
      },{gridRoot:true});
      regions.push({id:b.id,sectionId:sectionId,x:x,y:y,width:w,height:height,label:b.title||'블록 설정'});
      currentBlock=null;return height;
    }
    function referenceBlock(b,sectionId,x,y,w){
      var s=b.source,f=w/s.width,h=s.height*f;currentBlock=b.id;
      add({type:'image',x:x,y:y,width:w,height:h,href:s.image,fit:'contain',radius:0});
      regions.push({id:b.id,sectionId:sectionId,x:x,y:y,width:w,height:h,label:b.title||'가져온 페이지'});
      s.regions.forEach(function(r){
        var rx=x+r.x*f,ry=y+r.y*f,rw=r.width*f,rh=r.height*f;
        regions.push({id:b.id,sectionId:sectionId,itemId:r.id,x:rx,y:ry,width:rw,height:rh,label:r.kind==='image'?r.label:r.text});
        if(r.kind==='image'){if(r.src)add({type:'image',x:rx,y:ry,width:rw,height:rh,href:r.src,fit:'cover',radius:0});return;}
        if(r.text===r.originalText&&!r.force)return;
        rect(rx,ry,rw,rh,r.background,'',0);var size=r.fontSize*f,ls;
        do{ls=wrapped(r.text,Math.max(1,rw-2),size,500);if(ls.length*size*1.15<=rh)break;size*=.94;}while(size>.5);
        if(size<6)warnings.push('수정한 글이 원본 글상자에 비해 깁니다. 문구를 줄이면 더 읽기 쉽습니다.');
        ls.forEach(function(t,i){text(rx+1,ry+i*size*1.15,t,size,500,r.color);});
      });currentBlock=null;return h;
    }
    function block(block, sectionId, x, y, w) {
      if(block.type==='reference'&&block.source)return referenceBlock(block,sectionId,x,y,w);
      if(block.grid)return gridBlock(block,sectionId,x,y,w);
      var start = primitives.length, childStart = regions.length;
      currentBlock = block.id;
      var pad = 13, inner = w - pad * 2, cy = y + pad;
      var border = colors.line, bg = '#ffffff';
      if (block.type === 'hero') {
        if (block.eyebrow) cy += paragraph(x + pad, cy, richValue(block,'eyebrow'), inner, 25 * scale, 800, colors.ink, 31 * scale) + 2;
        cy += title(x + pad, cy, richValue(block,'title'), inner, 28 * scale) + 6;
        cy += paragraph(x + pad, cy, richValue(block,'body'), inner, fs, 500, colors.text, lh) + 8;
        var heroH = 198;
        image(x + pad, cy, inner, heroH, block.image, 'image', sectionId); cy += heroH;
      } else if (block.type === 'steps') {
        // Four adjoining step tiles are the original form's main organizing row.
        pad = 0; inner = w; cy = y;
        if (block.title && block.title !== '리셋 순서') cy += title(x + 8, cy, richValue(block,'title'), inner-16, 17 * scale) + 8;
        var items = Array.isArray(block.items) ? block.items : [];
        var columns = items.length > 4 ? 3 : Math.max(1, Math.min(4, items.length));
        var tileGap = 6, tileW = (inner - tileGap * (columns - 1)) / columns;
        var rows = Math.ceil(items.length / columns);
        for (var row = 0; row < rows; row++) {
          var rowItems = items.slice(row * columns, (row + 1) * columns), dimensions = [];
          rowItems.forEach(function (item, i) {
            dimensions.push({ headingH: paragraphHeight(richValue(block,'items.'+(row*columns+i)+'.title'),tileW-20,14.2*scale,700,20*scale), bodyH: paragraphHeight(richValue(block,'items.'+(row*columns+i)+'.body'),tileW-20,12.5*scale,400,18*scale) });
          });
          var headingMax = Math.max.apply(null, dimensions.map(function (d) { return d.headingH; }));
          var bodyMax = Math.max.apply(null, dimensions.map(function (d) { return d.bodyH; }));
          var imageH = 108;
          var tileH = 12 + 24 + 9 + headingMax + 9 + imageH + 8 + bodyMax + 12;
          rowItems.forEach(function (item, i) {
            var tx=x+i*(tileW+tileGap),ty=cy;
            rect(tx,ty,tileW,tileH,'#ffffff',colors.line,8);
            rect(tx+Math.max(12,(tileW-76)/2),ty+9,Math.min(76,tileW-24),24,colors.accent,'',7);
            text(tx+Math.max(18,(tileW-56)/2),ty+11,'STEP '+(row*columns+i+1),12.5*scale,700,'#ffffff');
            paragraph(tx+10,ty+45,richValue(block,'items.'+(row*columns+i)+'.title'),tileW-20,14.2*scale,700,colors.accent,20*scale);
            var iy=ty+45+headingMax+9;
            if(item.duration&&!item.image){
              rect(tx+10,iy,tileW-20,imageH,colors.pale,'',7);
              var clockX=tx+tileW/2,clockY=iy+40;
              circle(clockX,clockY,25,'none',colors.accent,4);
              line(clockX,clockY,clockX,clockY-14,colors.accent,4);
              line(clockX,clockY,clockX+12,clockY,colors.accent,4);
              var ds=16*scale;
              while(ds>10&&measureTextWidth(item.duration,ds,800)>tileW-30)ds-=.5;
              text(tx+14,iy+imageH-28,item.duration,ds,800,colors.accent);
              regions.push({id:block.id,sectionId:sectionId,x:tx,y:ty,width:tileW,height:tileH,focus:'items.'+(row*columns+i)+'.title',label:item.title});
            }else image(tx+10,iy,tileW-20,imageH,item.image,'items.'+(row*columns+i)+'.image',sectionId);
            paragraph(tx+10,iy+imageH+8,richValue(block,'items.'+(row*columns+i)+'.body'),tileW-20,12.5*scale,400,colors.text,18*scale);
          });
          cy+=tileH+tileGap;
        }
        if(rows)cy-=tileGap;
      } else if (block.type === 'photos') {
        cy+=title(x+pad,cy,richValue(block,'title'),inner,16.5*scale)+9;
        var photos=Array.isArray(block.items)?block.items:[];
        var count=Math.min(2,Math.max(1,photos.length)),pw=(inner-10*(count-1))/count;
        for(var pr=0;pr<Math.ceil(photos.length/count);pr++){
          var rowPhotos=photos.slice(pr*count,pr*count+count),maxH=0;
          rowPhotos.forEach(function(item,i){
            var px=x+pad+i*(pw+10),py=cy;
            image(px,py,pw,88,item.image,'items.'+(pr*count+i)+'.image',sectionId);py+=95;
            py+=paragraph(px,py,richValue(block,'items.'+(pr*count+i)+'.title'),pw,13*scale,700,colors.ink,18*scale)+3;
            py+=paragraph(px,py,richValue(block,'items.'+(pr*count+i)+'.body'),pw,11.8*scale,400,colors.muted,17*scale);
            maxH=Math.max(maxH,py-cy);
          });
          cy+=maxH+9;
        }
        if(photos.length)cy-=9;
      } else if (block.type === 'notice') {
        border='#f1acb7';bg=colors.rose;
        if(!block.icon||block.icon==='auto'){circle(x+pad+10,cy+12,11,safeColor(block.iconColor,colors.red));text(x+pad+7,cy-1,'!',17*scale,800,'#ffffff');}
        else if(block.icon!=='none')namedIcon(block.icon,x+pad-1,cy+1,24,safeColor(block.iconColor,colors.red),block.emoji,block.iconImage);
        var noticeInset=block.icon==='none'?0:29;
        cy+=title(x+pad+noticeInset,cy,richValue(block,'title'),inner-noticeInset,16.5*scale,colors.red)+11;
        cy+=bullets(x+pad,cy,richValue(block,'body'),inner,12.8*scale,colors.red,8);
      } else if (block.type === 'intro') {
        cy+=title(x+pad,cy,richValue(block,'title'),inner,16.5*scale,colors.ink)+6;
        cy+=paragraph(x+pad,cy,richValue(block,'body'),inner,13*scale,400,colors.text,19*scale);
      } else if (block.type === 'led') {
        cy+=title(x+pad,cy,richValue(block,'title'),inner,17*scale)+9;
        var ledH=all?112:148,photoW=Math.round((inner-8)*.7),bodyW=inner-photoW-8;
        var bodyH=paragraphHeight(richValue(block,'body'),bodyW-16,13.4*scale,500,20*scale)+16;
        var contentH=Math.max(ledH,bodyH);
        image(x+pad,cy,photoW,contentH,block.image,'image',sectionId);
        rect(x+pad+photoW+8,cy,bodyW,contentH,colors.pale,'',7);
        paragraph(x+pad+photoW+16,cy+8,richValue(block,'body'),bodyW-16,13.4*scale,500,colors.accent,20*scale);
        cy+=contentH;
      } else if (block.type === 'bullets') {
        cy+=title(x+pad,cy,richValue(block,'title'),inner,17*scale)+9;
        cy+=bullets(x+pad,cy,richValue(block,'body'),inner,13.3*scale,colors.accent,7);
      } else if (block.type === 'faq') {
        var n=Number((textValue(block.title).match(/^Q(\d+)/i)||[])[1])||5;
        if(!block.icon||block.icon==='auto'){if(block.iconColor)namedIcon(['phone','thermometer','bolt','usb','wrench'][Math.min(4,Math.max(0,n-1))],x+10,cy+1,44,safeColor(block.iconColor,colors.accent));else faqIcon(n,x+10,cy+1);}
        else if(block.icon!=='none')namedIcon(block.icon,x+10,cy+1,44,safeColor(block.iconColor,block.icon==='thermometer'?'#ff1835':block.icon==='bolt'?'#ffad00':colors.accent),block.emoji,block.iconImage);
        var faqInset=block.icon==='none'?13:62,faqBody=block.icon==='none'?13:48;
        cy+=title(x+faqInset,cy,richValue(block,'title'),w-faqInset-13,16*scale)+8;
        cy+=bullets(x+faqBody,cy,richValue(block,'body'),w-faqBody-13,13*scale,colors.accent,4);
      } else {
        warnings.push('알 수 없는 칸 유형: '+textValue(block.type));
        cy+=title(x+pad,cy,block.title||'내용',inner,17*scale)+8;
        cy+=paragraph(x+pad,cy,richValue(block,'body'),inner,fs,400,colors.text,lh);
      }
      var height=Math.max(54,cy-y+pad);
      // Step tiles already own their borders, so do not draw an enclosing card.
      if(block.type!=='steps')primitives.splice(start,0,{type:'rect',x:x,y:y,width:w,height:height,fill:bg,stroke:border,radius:8,strokeWidth:1,blockId:block.id});
      regions.splice(childStart,0,{id:block.id,sectionId:sectionId,x:x,y:y,width:w,height:height,label:block.title||block.eyebrow||'내용 칸'});
      currentBlock=null;
      return height;
    }
    function measureTextWidth(value,size,weight){measure.font=font(size,weight);return measure.measureText(textValue(value)).width;}
    function stretchCard(id,height){
      var background;
      function find(list){for(var i=0;i<list.length;i++){var p=list[i];if(p.blockId===id&&p.type==='group'&&p.gridRoot)p.height=height;if(!background&&p.blockId===id&&p.type==='rect')background=p;if(p.children)find(p.children);}}
      find(primitives);
      if(background)background.height=height;
      var region=regions.find(function(r){return r.id===id&&!r.focus&&!r.rowId&&!r.cellId&&!r.itemId;});
      if(region)region.height=height;
    }
    var x=margin,height=120,rowY=margin,rowBottom=margin,cursor=0;
    sections.forEach(function(section,index){
      var span=all?Math.round(number(section.span,1,1,columns)):1;
      if(all&&cursor>0&&(section.startNewRow||cursor+span>columns)){rowY=rowBottom+16;rowBottom=rowY;cursor=0;}
      var column=all?cursor:0;
      x=margin;for(var col=0;col<column;col++)x+=widths[col]+gap;
      var w=0;for(var sc=column;sc<column+span;sc++)w+=widths[sc];w+=gap*(span-1);
      var y=rowY;
      if(!section.hideTitle){
      var headerLines=wrapped(section.title||section.label,w-24,18*scale,800);
      var hh=Math.max(34,headerLines.length*24*scale+10);
      rect(x,y,w,hh,colors.ink,'',7);
      paragraph(x+12,y+4,section.title||section.label,w-24,18*scale,800,'#ffffff',24*scale);
      y+=hh+8;
      }
      var blocks=(section.blocks||[]).filter(function(b){return !b.hidden;});
      for(var i=0;i<blocks.length;i++){
        var b=blocks[i],next=blocks[i+1];
        var paired=section.id==='reset'&&next&&((b.type==='photos'&&next.type==='notice')||(b.type==='notice'&&next.type==='photos'));
        if(paired){
          var firstRatio=b.type==='photos'?.55:.45;
          var firstW=Math.round((w-8)*firstRatio),secondW=w-8-firstW;
          var h1=block(b,section.id,x,y,firstW);
          var h2=block(next,section.id,x+firstW+8,y,secondW);
          var rowH=Math.max(h1,h2);stretchCard(b.id,rowH);stretchCard(next.id,rowH);
          y+=rowH+8;i++;
        }else y+=block(b,section.id,x,y,w)+8;
      }
      height=Math.max(height,y);
      rowBottom=Math.max(rowBottom,y);
      cursor+=span;
    });
    if(height>15000)warnings.push('내용이 매우 깁니다. 안내 자료를 나누어 출력하는 것을 권합니다.');
    return {width:width,height:Math.ceil(height),primitives:primitives,regions:regions,warnings:warnings,fontFamily:FAMILY,colors:colors};
  }
  function primitiveBounds(p){
    if(p.type==='circle')return {x:p.x-p.radius,y:p.y-p.radius,width:p.radius*2,height:p.radius*2};
    if(p.type==='line')return {x:Math.min(p.x1,p.x2),y:Math.min(p.y1,p.y2),width:Math.max(1,Math.abs(p.x2-p.x1)),height:Math.max(1,Math.abs(p.y2-p.y1))};
    if(p.type==='text'){measure.font=font(p.fontSize,p.weight,p.fontFamily);return {x:p.x,y:p.y-p.fontSize,width:Math.max(1,measure.measureText(p.text).width),height:p.fontSize*1.4};}
    return {x:number(p.x,0),y:number(p.y,0),width:Math.max(1,number(p.width,1)),height:Math.max(1,number(p.height,1))};
  }
  function toSvg(scene, options) {
    options=options||{};var defs=[],serial=0,prefix='notice-svg-'+(++svgSerial)+'-';
    function svgPaint(value,bounds){
      var v=paint(value,'none');if(typeof v==='string')return v;
      var id=prefix+'gradient-'+(++serial),q=gradientPoints(bounds,v);
      defs.push('<linearGradient id="'+id+'" gradientUnits="userSpaceOnUse" x1="'+q.x1+'" y1="'+q.y1+'" x2="'+q.x2+'" y2="'+q.y2+'"><stop offset="0" stop-color="'+escapeXml(v.from)+'"/><stop offset="1" stop-color="'+escapeXml(v.to)+'"/></linearGradient>');return 'url(#'+id+')';
    }
    function effect(p,b){
      var attrs='',alpha=number(p.opacity,1,0,1),blur=number(p.blur,0,0,24);
      if(alpha!==1)attrs+=' opacity="'+alpha+'"';
      if(blur){var id=prefix+'blur-'+(++serial),pad=blur*4+8;defs.push('<filter id="'+id+'" filterUnits="userSpaceOnUse" x="'+(b.x-pad)+'" y="'+(b.y-pad)+'" width="'+(b.width+pad*2)+'" height="'+(b.height+pad*2)+'" color-interpolation-filters="sRGB"><feGaussianBlur stdDeviation="'+blur+'"/></filter>');attrs+=' filter="url(#'+id+')"';}
      return attrs;
    }
    function render(p){
      var b=primitiveBounds(p),eff=effect(p,b),fill=svgPaint(p.fill,b),stroke=svgPaint(p.stroke,b),sw=number(p.strokeWidth,1,0,50);
      var attr=' fill="'+escapeXml(fill)+'"'+(stroke!=='none'&&sw?' stroke="'+escapeXml(stroke)+'" stroke-width="'+sw+'"':'')+eff;
      var dash=p.strokePattern==='dashed'?[sw*4,sw*3]:p.strokePattern==='dotted'?[sw,sw*2.5]:null;if(dash)attr+=' stroke-dasharray="'+dash.join(' ')+'"'+(p.strokePattern==='dotted'?' stroke-linecap="round"':'');
      var meta=(p.itemId?' data-item-id="'+escapeXml(p.itemId)+'"':'');
      if(p.type==='group')return '<g'+eff+meta+'>'+p.children.map(render).join('')+'</g>';
      if(p.type==='rect')return '<rect x="'+p.x+'" y="'+p.y+'" width="'+p.width+'" height="'+p.height+'" rx="'+(p.radius||0)+'"'+attr+meta+'/>';
      if(p.type==='circle')return '<circle cx="'+p.x+'" cy="'+p.y+'" r="'+p.radius+'"'+attr+meta+'/>';
      if(p.type==='ellipse')return '<ellipse cx="'+(p.x+p.width/2)+'" cy="'+(p.y+p.height/2)+'" rx="'+p.width/2+'" ry="'+p.height/2+'"'+attr+meta+'/>';
      if(p.type==='line')return '<line x1="'+p.x1+'" y1="'+p.y1+'" x2="'+p.x2+'" y2="'+p.y2+'" stroke="'+escapeXml(stroke)+'" stroke-width="'+sw+'" stroke-linecap="round"'+(dash?' stroke-dasharray="'+dash.join(' ')+'"':'')+eff+meta+'/>';
      if(p.type==='text')return '<text x="'+p.x+'" y="'+p.y+'" fill="'+escapeXml(fill)+'" font-family="'+escapeXml(p.fontFamily||'Noto Sans KR, Malgun Gothic, sans-serif')+'" font-size="'+p.fontSize+'" font-weight="'+p.weight+'"'+eff+meta+'>'+escapeXml(p.text)+'</text>';
      if(p.type==='image'&&options.images!==false){
        var clip='';if(p.fit==='cover'||p.radius){var id=prefix+'clip-'+(++serial);defs.push('<clipPath id="'+id+'"><rect x="'+p.x+'" y="'+p.y+'" width="'+p.width+'" height="'+p.height+'" rx="'+(p.radius||0)+'"/></clipPath>');clip=' clip-path="url(#'+id+')"';}
        return '<image x="'+p.x+'" y="'+p.y+'" width="'+p.width+'" height="'+p.height+'" href="'+escapeXml(imageSource(p.href))+'" preserveAspectRatio="xMidYMid '+(p.fit==='cover'?'slice':'meet')+'"'+clip+eff+meta+'/>';
      }return '';
    }
    var content=scene.primitives.map(render).join(''),overlays=[];
    if(options.interactive){
      function rank(r){return r.itemId?4:r.focus?3:r.cellId?2:r.rowId?1:0;}
      scene.regions.slice().sort(function(a,b){return rank(a)-rank(b);}).forEach(function(r){
        var isBlock=!r.focus&&!r.rowId&&!r.cellId&&!r.itemId;
        var selected=r.itemId?options.selectedItemId===r.itemId:r.cellId?options.selectedCellId===r.cellId&&!options.selectedItemId:r.rowId?options.selectedRowId===r.rowId&&!options.selectedCellId&&!options.selectedItemId:options.selectedId===r.id&&isBlock&&!options.selectedItemId&&!options.selectedCellId&&!options.selectedRowId;
        var metadata=' data-block-id="'+escapeXml(r.id)+'" data-section-id="'+escapeXml(r.sectionId)+'"'+(r.focus?' data-focus="'+escapeXml(r.focus)+'"':'')+(r.rowId?' data-row-id="'+escapeXml(r.rowId)+'"':'')+(r.cellId?' data-cell-id="'+escapeXml(r.cellId)+'"':'')+(r.itemId?' data-item-id="'+escapeXml(r.itemId)+'"':'');
        overlays.push('<rect class="edit-region'+(selected?' is-selected':'')+'"'+metadata+' x="'+r.x+'" y="'+r.y+'" width="'+r.width+'" height="'+r.height+'" rx="8" fill="transparent" stroke="'+(selected?'#0866e8':'transparent')+'" stroke-width="'+(selected?'2.3':'1')+'" vector-effect="non-scaling-stroke" tabindex="0" role="button" aria-label="'+escapeXml(r.label)+' 수정"><title>'+escapeXml(r.label)+' 수정</title></rect>');
      });
    }
    return '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 '+scene.width+' '+scene.height+'" width="'+scene.width+'" height="'+scene.height+'" role="img" aria-label="AS 안내문 미리보기"><defs>'+defs.join('')+'</defs><rect width="100%" height="100%" fill="#ffffff"/>'+content+overlays.join('')+'</svg>';
  }
  function loadImage(source) {
    if (imageCache.has(source)) return imageCache.get(source);
    var promise = new Promise(function (resolve, reject) {
      var image = new Image();
      image.onload = function () { resolve(image); };
      image.onerror = function () { reject(new Error('사진을 읽을 수 없습니다. 사진을 다시 선택해 주세요.')); };
      image.src = source;
    });
    imageCache.set(source, promise); return promise;
  }
  function roundPath(ctx, x, y, w, h, r) {
    r = Math.min(r || 0, w / 2, h / 2);
    ctx.beginPath();ctx.moveTo(x + r,y);ctx.lineTo(x+w-r,y);ctx.quadraticCurveTo(x+w,y,x+w,y+r);ctx.lineTo(x+w,y+h-r);ctx.quadraticCurveTo(x+w,y+h,x+w-r,y+h);ctx.lineTo(x+r,y+h);ctx.quadraticCurveTo(x,y+h,x,y+h-r);ctx.lineTo(x,y+r);ctx.quadraticCurveTo(x,y,x+r,y);ctx.closePath();
  }
  async function toCanvas(scene, width) {
    if(document.fonts&&document.fonts.ready)await document.fonts.ready;
    width=Math.max(600,Math.min(6000,Number(width)||2400));
    var ratio=width/scene.width,height=Math.ceil(scene.height*ratio);
    if(height>28000||width*height>65000000)throw new Error('출력할 내용이 너무 깁니다. 자료를 나누어 저장해 주세요.');
    var canvas=document.createElement('canvas');canvas.width=Math.round(width);canvas.height=height;
    var ctx=canvas.getContext('2d');ctx.fillStyle='#ffffff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.scale(ratio,ratio);
    function canvasPaint(value,target,bounds){var v=paint(value,'none');if(typeof v==='string')return v;var q=gradientPoints(bounds,v),g=target.createLinearGradient(q.x1,q.y1,q.x2,q.y2);g.addColorStop(0,v.from);g.addColorStop(1,v.to);return g;}
    async function draw(list,target){
      target.textBaseline='alphabetic';target.lineJoin='round';
      for(var p of list){
        var b=primitiveBounds(p),opacity=number(p.opacity,1,0,1),blur=number(p.blur,0,0,24);
        if(p.type==='group'){
          if(opacity===1&&!blur){await draw(p.children,target);continue;}
          var pad=blur*4+8,layer=document.createElement('canvas');layer.width=Math.max(1,Math.ceil((b.width+pad*2)*ratio));layer.height=Math.max(1,Math.ceil((b.height+pad*2)*ratio));
          if(layer.width*layer.height>65000000)throw new Error('효과가 적용된 영역이 너무 큽니다. 안내문을 나눠 저장해 주세요.');
          var layerCtx=layer.getContext('2d');layerCtx.scale(ratio,ratio);layerCtx.translate(-b.x+pad,-b.y+pad);await draw(p.children,layerCtx);
          target.save();target.globalAlpha*=opacity;if(blur)target.filter='blur('+(blur*ratio)+'px)';target.drawImage(layer,b.x-pad,b.y-pad,layer.width/ratio,layer.height/ratio);target.restore();continue;
        }
        target.save();target.globalAlpha*=opacity;if(blur)target.filter='blur('+(blur*ratio)+'px)';
        var fill=canvasPaint(p.fill,target,b),stroke=canvasPaint(p.stroke,target,b),sw=number(p.strokeWidth,1,0,50);
        if(p.strokePattern&&target.setLineDash){target.setLineDash(p.strokePattern==='dashed'?[sw*4,sw*3]:[sw,sw*2.5]);if(p.strokePattern==='dotted')target.lineCap='round';}
        if(p.type==='rect'){
          roundPath(target,p.x,p.y,p.width,p.height,p.radius);if(fill!=='none'){target.fillStyle=fill;target.fill();}if(stroke!=='none'&&sw){target.strokeStyle=stroke;target.lineWidth=sw;target.stroke();}
        }else if(p.type==='circle'||p.type==='ellipse'){
          target.beginPath();if(p.type==='circle')target.arc(p.x,p.y,p.radius,0,Math.PI*2);else target.ellipse(p.x+p.width/2,p.y+p.height/2,p.width/2,p.height/2,0,0,Math.PI*2);
          if(fill!=='none'){target.fillStyle=fill;target.fill();}if(stroke!=='none'&&sw){target.strokeStyle=stroke;target.lineWidth=sw;target.stroke();}
        }else if(p.type==='line'){
          if(stroke!=='none'&&sw){target.beginPath();target.moveTo(p.x1,p.y1);target.lineTo(p.x2,p.y2);target.lineWidth=sw;target.strokeStyle=stroke;target.lineCap='round';target.stroke();}
        }else if(p.type==='text'){
          target.font=font(p.fontSize,p.weight,p.fontFamily);target.fillStyle=fill==='none'?'#26364a':fill;target.fillText(p.text,p.x,p.y);
        }else if(p.type==='image'){
          var source=imageSource(p.href);if(source){var im=await loadImage(source),fit=(p.fit==='cover'?Math.max:Math.min)(p.width/im.naturalWidth,p.height/im.naturalHeight),iw=im.naturalWidth*fit,ih=im.naturalHeight*fit;
          if(p.fit==='cover'||p.radius){roundPath(target,p.x,p.y,p.width,p.height,p.radius||0);target.clip();}target.drawImage(im,p.x+(p.width-iw)/2,p.y+(p.height-ih)/2,iw,ih);}
        }
        target.restore();
      }
    }
    await draw(scene.primitives,ctx);return canvas;
  }
  window.NoticeRenderer = { build: build, toSvg: toSvg, toCanvas: toCanvas, wrap: wrapped };
})();
