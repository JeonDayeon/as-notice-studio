(function () {
  'use strict';
  var serial=0;
  function id(prefix){serial++;return (prefix||'grid')+'-'+Date.now().toString(36)+'-'+serial.toString(36)+'-'+Math.random().toString(36).slice(2,6);}
  function copy(value){return JSON.parse(JSON.stringify(value));}
  function style(values){return Object.assign({fill:'none',stroke:'none',strokeWidth:0,radius:6,opacity:1,blur:0},values||{});}
  function colors(model){var t=(model&&model.theme)||model||{};return {accent:t.accent||'#0866e8',ink:t.ink||'#132b49',text:'#26364a',muted:'#64748b',line:'#dce8f5',pale:'#edf7ff',red:'#ef233c',rose:'#fff7f7'};}
  function text(value,size,weight,color,extra){return Object.assign({id:id('item'),type:'text',text:String(value||''),fontSize:size||14,weight:weight||400,color:color||'#26364a',align:'left',lineHeight:1.5,listStyle:'plain',width:100,style:style()},extra||{});}
  function photo(src,height,extra){return Object.assign({id:id('item'),type:'image',src:src||'',height:height||120,width:100,fit:'contain',style:style()},extra||{});}
  function icon(name,size,color,extra){return Object.assign({id:id('item'),type:'icon',icon:name||'info',size:size||36,width:100,color:color||'#0866e8',align:'center',style:style()},extra||{});}
  function cell(items,extra){return Object.assign({id:id('cell'),weight:1,padding:0,gap:8,verticalAlign:'start',style:style(),items:items||[]},extra||{});}
  function row(cells,extra){return Object.assign({id:id('row'),gap:10,minHeight:0,cells:cells||[]},extra||{});}
  function grid(rows,extra){return Object.assign({version:1,padding:13,gap:9,style:style({fill:'#ffffff',stroke:'#dce8f5',strokeWidth:1,radius:8}),rows:rows||[]},extra||{});}
  function body(value,c,size,extra){return text(value,size||13.2,400,c.text,Object.assign({listStyle:'bullet',bulletColor:c.accent},extra||{}));}
  function header(title,c,size){return text(title,size||17,700,c.accent);}
  function faqGrid(title,value,c){return grid([
    row([cell([icon('phone',35,c.accent)],{weight:1}),cell([header(title,c,16)],{weight:8})],{gap:5}),
    row([cell([body(value,c,13)],{padding:0})])
  ]);}
  function noticeGrid(title,value,c){return grid([
    row([cell([icon('warning',24,c.red)],{weight:1}),cell([text(title,16.5,700,c.red)],{weight:9})],{gap:4}),
    row([cell([body(value,c,12.8,{bulletColor:c.red})])])
  ],{gap:8,style:style({fill:c.rose,stroke:'#f1acb7',strokeWidth:1,radius:8})});}
  function fromBlockBase(block,model){
    if(block&&block.grid)return copy(block.grid);
    block=block||{};var c=colors(model),rows=[];
    if(block.type==='hero'){
      var items=[];if(block.eyebrow)items.push(text(block.eyebrow,25,800,c.ink));
      items.push(text(block.title,28,700,c.accent));
      if(block.body)items.push(text(block.body,13.2,500,c.text));
      items.push(photo(block.image,198));
      return grid([row([cell(items,{gap:6})])]);
    }
    if(block.type==='steps'){
      if(block.title&&block.title!=='리셋 순서')rows.push(row([cell([header(block.title,c,17)])]));
      var steps=Array.isArray(block.items)?block.items:[];
      for(var offset=0;offset<steps.length;offset+=4){
        rows.push(row(steps.slice(offset,offset+4).map(function(item,index){
          var parts=[text('STEP '+(offset+index+1),12.5,700,'#ffffff',{align:'center',style:style({fill:c.accent,radius:7})}),text(item.title,14.2,700,c.accent)];
          if(item.duration&&!item.image){parts.push(icon('clock',54,c.accent,{height:72,style:style({fill:c.pale,radius:7})}));parts.push(text(item.duration,16,800,c.accent,{align:'center',style:style({fill:c.pale,radius:7})}));}
          else parts.push(photo(item.image,108));
          parts.push(text(item.body,12.5,400,c.text,{lineHeight:1.44}));
          return cell(parts,{padding:10,gap:8,style:style({fill:'#ffffff',stroke:c.line,strokeWidth:1,radius:8})});
        }),{gap:6}));
      }
      return grid(rows,{padding:0,gap:8,style:style()});
    }
    if(block.type==='photos'){
      rows.push(row([cell([header(block.title,c,16.5)])]));
      var photos=Array.isArray(block.items)?block.items:[];
      for(var pi=0;pi<photos.length;pi+=2)rows.push(row(photos.slice(pi,pi+2).map(function(item){return cell([photo(item.image,88),text(item.title,13,700,c.ink),text(item.body,11.8,400,c.muted)],{gap:5});}),{gap:10}));
      return grid(rows);
    }
    if(block.type==='notice'){
      var notice=noticeGrid(block.title,block.body,c);
      if(block.iconColor)notice.rows[0].cells[0].items[0].color=block.iconColor;
      if(block.icon==='none')notice.rows[0].cells.shift();
      else if(block.icon&&block.icon!=='auto'){var ni=notice.rows[0].cells[0].items[0];ni.icon=block.icon;ni.emoji=block.emoji||'❗';ni.iconImage=block.iconImage||'';ni.color=block.iconColor||c.red;}
      return notice;
    }
    if(block.type==='faq'){
      var result=faqGrid(block.title,block.body,c),n=Number((String(block.title).match(/^Q(\d+)/i)||[])[1])||5;
      var item=result.rows[0].cells[0].items[0];item.icon=['phone','thermometer','bolt','usb','wrench'][Math.min(4,Math.max(0,n-1))];item.color=n===2?'#ff1835':n===3?'#ffad00':c.accent;
      if(block.iconColor)item.color=block.iconColor;
      if(block.icon==='none')result.rows[0].cells.shift();
      else if(block.icon&&block.icon!=='auto'){item.icon=block.icon;item.emoji=block.emoji||'❗';item.iconImage=block.iconImage||'';item.color=block.iconColor||item.color;}
      return result;
    }
    if(block.type==='led')return grid([
      row([cell([header(block.title,c,17)])]),
      row([cell([photo(block.image,112)],{weight:7,padding:0}),cell([text(block.body,13.4,500,c.accent)],{weight:3,padding:8,verticalAlign:'center',style:style({fill:c.pale,radius:7})})],{gap:8})
    ]);
    if(block.type==='bullets')return grid([row([cell([header(block.title,c,17)])]),row([cell([body(block.body,c,13.3)])])]);
    if(block.type==='intro')return grid([row([cell([text(block.title,16.5,700,c.ink),text(block.body,13,400,c.text)],{gap:6})])]);
    return grid([row([cell([header(block.title||'새 블록',c),text(block.body||'내용을 입력해 주세요.',14,400,c.text)])])]);
  }
  function fromBlock(block,model){
    var result=fromBlockBase(block,model);if(block.grid||(!block.textStyles&&!block.softBreaks))return result;
    var values=[];for(var key of new Set([...Object.keys(block.textStyles||{}),...Object.keys(block.softBreaks||{})])){var value=key.split('.').reduce((o,k)=>o?.[k],block);if(typeof value==='string'&&(block.textStyles?.[key]?.length||block.softBreaks?.[key]?.length))values.push({text:value,spans:block.textStyles?.[key]||[],softBreaks:block.softBreaks?.[key]||[],used:false});}
    for(var r of result.rows)for(var c of r.cells)for(var item of c.items)if(item.type==='text'){var match=values.find(v=>!v.used&&v.text===item.text);if(match){item.spans=copy(match.spans);item.softBreaks=copy(match.softBreaks);match.used=true;}}
    return result;
  }
  function createPreset(kind,theme){
    var c=colors(theme);if(window.AS_FAQ_LAYOUTS?.[kind])return copy(window.AS_FAQ_LAYOUTS[kind]);
    if(kind==='blank')return grid([row([cell([])])]);
    if(kind==='image-text')return grid([row([cell([photo('',140)],{weight:1}),cell([header('사진 안내',c),text('사진 옆에 표시할 설명을 입력해 주세요.',14,400,c.text)],{weight:1,verticalAlign:'center'})])]);
    if(kind==='two-photos')return grid([row([cell([photo('',130),text('첫 번째 사진 설명',14,500,c.text)]),cell([photo('',130),text('두 번째 사진 설명',14,500,c.text)])])]);
    if(kind==='checklist')return grid([row([cell([header('확인 사항',c),body('첫 번째 확인 사항\n두 번째 확인 사항\n세 번째 확인 사항',c,14)])])]);
    if(kind==='faq')return faqGrid('새 질문을 입력해 주세요.','안내할 내용을 입력해 주세요.',c);
    if(kind==='notice')return noticeGrid('꼭 확인해 주세요.','강조할 안내 내용을 입력해 주세요.',c);
    return grid([row([cell([header('새 안내 제목',c),text('내용을 입력해 주세요.',14,400,c.text)])])]);
  }
  window.GridLayout={fromBlock:fromBlock,createPreset:createPreset};
})();
