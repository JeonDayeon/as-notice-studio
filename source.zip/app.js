(function () {
  'use strict';
  const $ = s => document.querySelector(s);
  const clone = x => JSON.parse(JSON.stringify(x));
  const escape = x => String(x == null ? '' : x).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const uuid = () => 'n-' + (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2));
  const TYPE_NAMES = {hero:'대표 안내',steps:'리셋 단계',photos:'설치 위치 사진',notice:'강조 안내',intro:'기본 설명',led:'제품 타입',bullets:'확인 사항',faq:'질문과 답변',grid:'칸 구성 블록',reference:'가져온 페이지'};
  const TYPE_SYMBOLS = {hero:'▧',steps:'▥',photos:'▧',notice:'!',intro:'≡',led:'◉',bullets:'☷',faq:'?',grid:'▦',reference:'▧'};
  let workspace, model, selectedId = 'reset-hero', view = 'all', scene, past = [], future = [], saveTimer, renderTimer, toastTimer, targetSection='faq', lastCheckpoint = 0, lastField = '';
  let storageOK = true, imageBusy = false;
  let gridSelection={rowId:null,cellId:null,itemId:null}, savingBlock=null;
  const ICONS=[['auto','기본 아이콘'],['phone','휴대폰'],['thermometer','온도계'],['bolt','번개'],['usb','USB'],['wrench','렌치'],['warning','느낌표'],['check','체크'],['clock','시계'],['info','정보'],['emoji','이모지'],['image','내 이미지 아이콘'],['none','없음']];
  let draftBlock=null,draftSelection={rowId:null,cellId:null,itemId:null};
  const PRESETS=[['image-text','▧','사진 + 글'],['two-photos','▥','사진 두 장'],['text','≡','설명'],['checklist','☑','체크리스트'],['faq','?','Q&A'],['notice','!','강조 안내'],['blank','▦','빈 칸']];

  const dbPromise = new Promise((resolve, reject) => {
    if (!window.indexedDB) return reject(new Error('IndexedDB unavailable'));
    const request = indexedDB.open('as-notice-studio', 1);
    request.onupgradeneeded = () => request.result.createObjectStore('data');
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
  // A rejected database connection is handled when storage is first used.
  dbPromise.catch(() => {});
  async function storageRead() {
    try {
      const db = await dbPromise;
      return await new Promise((resolve, reject) => {
        const request = db.transaction('data').objectStore('data').get('workspace');
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
      });
    } catch (_) {
      try { return JSON.parse(localStorage.getItem('as-notice-studio') || 'null'); } catch (_) { return null; }
    }
  }
  async function storageWrite(value) {
    try {
      const db = await dbPromise;
      await new Promise((resolve, reject) => {
        const tx = db.transaction('data', 'readwrite');
        tx.objectStore('data').put(clone(value), 'workspace');
        tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); tx.onabort = () => reject(tx.error);
      });
    } catch (_) { localStorage.setItem('as-notice-studio', JSON.stringify(value)); }
  }
  function toast(message) { clearTimeout(toastTimer); $('#toast').textContent = message; $('#toast').classList.add('visible'); toastTimer = setTimeout(() => $('#toast').classList.remove('visible'), 4600); }
  function saveStatus(text, error=false) { const el=$('#save-status'); el.innerHTML='<span></span>'+escape(text); el.classList.toggle('error',error); }
  function currentEntry() { return workspace.documents.find(e => e.model.document.id === workspace.activeId); }
  async function persist() {
    clearTimeout(saveTimer);
    const entry = currentEntry(); if (!entry) return;
    entry.model = clone(model); entry.updatedAt = new Date().toISOString();
    try { await storageWrite(workspace); localStorage.removeItem('as-notice-studio-pending'); storageOK=true; saveStatus('이 브라우저에 저장됨'); }
    catch (_) { storageOK=false; saveStatus('편집본을 파일로 저장해 주세요', true); }
  }
  function scheduleSave() { saveStatus('변경 내용 저장 중'); clearTimeout(saveTimer); saveTimer=setTimeout(persist,650); }
  function checkpoint(field='action') {
    if (field !== lastField || Date.now()-lastCheckpoint>1000) { past.push(clone(model)); if(past.length>24)past.shift(); future=[]; }
    lastCheckpoint=Date.now();lastField=field;
  }
  function mutate(fn, field='action', inspector=false) { checkpoint(field);fn();model.schemaVersion=2;scheduleSave();updateHeader();renderOutline();scheduleCanvas();if(inspector)renderInspector();updateHistory(); }
  function undo() { if(!past.length)return;future.push(clone(model));model=past.pop();lastField='';scheduleSave();renderAll(); }
  function redo() { if(!future.length)return;past.push(clone(model));model=future.pop();lastField='';scheduleSave();renderAll(); }
  function updateHistory() { $('#undo').disabled=!past.length;$('#redo').disabled=!future.length; }
  function findBlock(id=selectedId) { for(const section of model.document.sections){const block=section.blocks.find(b=>b.id===id);if(block)return{block,section};}return null; }
  function removeBlock(id=selectedId) {
    const f=findBlock(id);if(!f)return;
    mutate(()=>{f.section.blocks=f.section.blocks.filter(b=>b.id!==id);renumberFaq(f.section);if(selectedId===id){selectedId=null;gridSelection={};}},'delete-'+id,true);
    toast('블록을 삭제했습니다. 위쪽 되돌리기로 복구할 수 있습니다.');
  }
  function placementFields(section,block) {
    const columns=model.document.layout?.columns||3,span=Math.min(columns,Math.max(1,Number(section.span)||1));
    return `<details class="placement-settings" open><summary>너비 · 큰 틀의 자리</summary><label class="field"><span class="field-label">이 구역의 너비</span><select data-section-span="${escape(section.id)}">${Array.from({length:columns},(_,i)=>i+1).map(n=>`<option value="${n}" ${span===n?'selected':''}>${n===columns?'한 줄 전체':n+'칸 너비'}</option>`).join('')}</select></label><label class="toggle-field"><span>새 줄에서 시작</span><input type="checkbox" data-section-new-row="${escape(section.id)}" ${section.startNewRow?'checked':''}></label>${block?`<label class="field"><span class="field-label">블록을 넣을 구역</span><select data-block-section="${escape(block.id)}">${sectionOptions(section.id)}</select></label><button class="button secondary wide" data-full-row="${escape(block.id)}">↔ 이 블록을 한 줄 전체로</button>`:''}<label class="toggle-field"><span>구역 머리말 표시</span><input type="checkbox" data-section-heading="${escape(section.id)}" ${section.hideTitle?'':'checked'}></label><p class="field-hint">구역 안의 블록들이 같은 너비를 사용합니다.${block?' 이 블록만 넓히려면 위 버튼으로 별도 줄에 놓으세요.':''}</p></details>`;
  }
  function makeFullRow(id) {
    const f=findBlock(id);if(!f)return;
    mutate(()=>{const columns=model.document.layout?.columns||3;if(f.section.blocks.length===1){f.section.span=columns;f.section.startNewRow=true;}else{const at=model.document.sections.indexOf(f.section);f.section.blocks=f.section.blocks.filter(b=>b.id!==id);renumberFaq(f.section);model.document.sections.splice(at+1,0,{id:uuid(),label:'전체 너비 안내',title:'전체 너비 안내',span:columns,startNewRow:true,blocks:[f.block]});}selectedId=id;},'full-row-'+id,true);
    setView('all');toast('한 줄 전체 너비로 옮겼습니다. 큰 틀 설정에서 구역 순서를 바꿀 수 있습니다.');
  }
  function asset(value) { if(typeof value!=='string')return '';if(Object.prototype.hasOwnProperty.call(window.AS_ASSETS,value))return window.AS_ASSETS[value];return /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=\s]+$/i.test(value)?value:''; }
  function setPath(obj,path,value) { const parts=path.split('.');let target=obj; for(const p of parts.slice(0,-1)){target=target[p];if(target==null)return;}target[parts.at(-1)]=value; }
  function field(label,key,value,textarea=false,hint='') { return `<label class="field"><span class="field-label">${escape(label)}</span>${textarea?`<textarea maxlength="10000" class="${key==='body'?'body-field':''}" data-key="${escape(key)}">${escape(value)}</textarea>`:`<input type="text" maxlength="500" data-key="${escape(key)}" value="${escape(value)}">`}${hint?`<p class="field-hint">${escape(hint)}</p>`:''}</label>`; }
  function photoField(key,value,label='사진') { const url=asset(value);return `<div class="photo-field" data-photo-field="${escape(key)}"><div class="field-label">${escape(label)}<small>칸 안에 자동 맞춤</small></div><div class="photo-preview">${url?`<img src="${escape(url)}" alt="선택한 사진">`:'<span>사진을 넣어 주세요</span>'}</div><div class="photo-actions"><label class="button secondary" role="button" tabindex="0">사진 ${url?'바꾸기':'넣기'}<input type="file" hidden accept="image/png,image/jpeg,image/webp" data-image-key="${escape(key)}"></label>${url?`<button class="button quiet clear-photo" data-clear-image="${escape(key)}" title="사진 지우기">×</button>`:''}</div><p class="field-hint">JPG · PNG · WebP / 원본 사진으로 교체할 수 있습니다.</p></div>`; }
  function inspectorHeader(eyebrow,title,description) { return `<div class="inspector-heading"><span class="eyebrow">${eyebrow}</span><h2>${escape(title)}</h2><p>${escape(description)}</p></div>`; }
  function iconField(block){return `<button class="button secondary wide" data-pick-native-icon>😊 이모지 · 내 아이콘 고르기</button><p class="field-hint">Win + . 이모지 또는 내 PNG·ICO 아이콘을 넣어 보세요.</p><details class="native-icon-settings"${block.icon&&block.icon!=='auto'?' open':''}><summary>아이콘 · 이모지</summary><label class="field"><span class="field-label">표시할 아이콘</span><select data-native-icon>${ICONS.map(([v,t])=>`<option value="${v}" ${(block.icon||'auto')===v?'selected':''}>${t}</option>`).join('')}</select></label>${block.icon==='emoji'?field('이모지 입력','emoji',block.emoji||'❗')+'<div class="emoji-choices">'+['❗','⚠️','💡','✅','📱','🔌','🔧','🔋','ℹ️','⏱️'].map(e=>`<button data-native-emoji="${e}" aria-label="이모지 ${e}">${e}</button>`).join('')+'</div>':''}<label class="field"><span class="field-label">아이콘 색상</span><input type="color" data-key="iconColor" value="${/^#[0-9a-f]{6}$/i.test(block.iconColor||'')?block.iconColor:model.theme.accent}"></label></details>`;}
  function restoreBlockLayout(block){mutate(()=>{if(block.type==='grid')block.grid=GridLayout.createPreset('text',model.theme);else delete block.grid;gridSelection={rowId:null,cellId:null,itemId:null};},'restore-block',true);toast('기본 배치로 되돌렸습니다. 되돌리기로 복구할 수 있습니다.');}
  function saveLibraryBlock(block){savingBlock=clone(block);$('#block-save-name').value=(block.title||TYPE_NAMES[block.type]||'내 블록').replace(/^Q\d+\.\s*/,'');$('#save-block-dialog').showModal();}
  function saveNamedBlock(){if(!savingBlock)return;const name=$('#block-save-name').value.trim()||'내 블록';workspace.library.push({id:uuid(),name,block:clone(savingBlock),savedAt:new Date().toISOString()});savingBlock=null;$('#save-block-dialog').close();scheduleSave();toast('내 블록 보관함에 저장했습니다.');}
  function sectionOptions(selected){return model.document.sections.map(s=>`<option value="${escape(s.id)}" ${s.id===selected?'selected':''}>${escape(s.label)}</option>`).join('');}
  function renderLibrary() {
    $('#saved-blocks').innerHTML=workspace.library.length?workspace.library.map(entry=>`<div class="saved-block-row"><div><strong>${escape(entry.name)}</strong><small>${entry.block.grid?'칸 구성 블록':escape(TYPE_NAMES[entry.block.type]||'블록')}</small></div><button class="button secondary" data-insert-library="${escape(entry.id)}">넣기</button><button class="button quiet" data-edit-library="${escape(entry.id)}">편집</button><button class="button quiet danger" data-delete-library="${escape(entry.id)}" aria-label="보관 블록 삭제: ${escape(entry.name)}">삭제</button></div>`).join(''):'<div class="info-note">아직 저장한 블록이 없습니다. 새 블록을 만들거나 기존 블록에서 ‘내 블록에 저장’을 눌러 보세요.</div>';
    if(workspace.libraryTrash.length)$('#saved-blocks').innerHTML+=`<details class="library-trash"><summary>삭제한 보관 블록 ${workspace.libraryTrash.length}개 · 복구</summary>${workspace.libraryTrash.map(entry=>`<div class="saved-block-row"><div><strong>${escape(entry.name)}</strong></div><button class="button secondary" data-restore-library="${escape(entry.id)}">복구</button></div>`).join('')}</details>`;
  }
  function showLibrary(sectionId){targetSection=sectionId||findBlock()?.section.id||model.document.sections[0]?.id;$('#library-target').innerHTML=sectionOptions(targetSection);$('#library-presets').innerHTML=PRESETS.map(([kind,symbol,title])=>`<button class="library-preset" data-library-preset="${kind}"><span>${symbol}</span><strong>${title}</strong></button>`).join('');renderLibrary();$('#library-dialog').showModal();}
  function freshBlock(block){const b=clone(block);b.id=uuid();if(b.items)for(const i of b.items)i.id=uuid();if(b.source){b.source.image=asset(b.source.image);for(const r of b.source.regions)if(r.kind==='image'&&r.src)r.src=asset(r.src);}if(b.grid)for(const r of b.grid.rows){r.id=uuid();for(const c of r.cells){c.id=uuid();for(const i of c.items)i.id=uuid();}}return b;}
  function insertBlock(block,sectionId){const section=model.document.sections.find(s=>s.id===sectionId);if(!section)return toast('블록을 넣을 구역을 먼저 추가해 주세요.');const b=freshBlock(block);mutate(()=>{section.blocks.push(b);renumberFaq(section);selectedId=b.id;gridSelection={rowId:null,cellId:null,itemId:null};},'insert-library',true);setView('all',false);renderAll();$('#library-dialog').close();$('#draft-dialog').close();selectBlock(b.id);toast('선택한 구역에 블록을 넣었습니다.');}
  function openDraft(kind,entry){draftBlock=entry?freshBlock(entry.block):{id:uuid(),type:'grid',title:PRESETS.find(p=>p[0]===kind)?.[2]||'새 블록',grid:GridLayout.createPreset(kind,model.theme)};if(!draftBlock.grid)draftBlock.grid=GridLayout.fromBlock(draftBlock,model);draftSelection={rowId:null,cellId:null,itemId:null};$('#library-dialog').close();$('#draft-target').innerHTML=sectionOptions(targetSection);$('#draft-dialog').showModal();renderDraft();}
  function renderDraft(){if(!draftBlock)return;const mock={theme:model.theme,document:{sections:[{id:'block-draft',label:'블록 미리보기',title:'블록 미리보기',blocks:[draftBlock]}]}};const sc=NoticeRenderer.build(mock,{view:'block-draft'});$('#draft-preview').innerHTML=NoticeRenderer.toSvg(sc,{interactive:true,selectedId:draftBlock.id,selectedRowId:draftSelection.rowId,selectedCellId:draftSelection.cellId,selectedItemId:draftSelection.itemId,images:true});GridEditor.mount($('#draft-inspector'),{block:draftBlock,model,...draftSelection,assets:AS_ASSETS,change:(fn,refresh=false)=>{fn();if(refresh)renderDraft();else renderDraftPreview();},select:selection=>{draftSelection={...draftSelection,...selection};renderDraft();},saveLibrary:saveLibraryBlock,exit:()=>$('#draft-dialog').close(),restore:()=>{draftBlock.grid=GridLayout.createPreset('text',model.theme);renderDraft();},pickImage:imageFile,pickIcon:callback=>IconPicker.open(callback),notify:toast});}
  function renderDraftPreview(){if(!draftBlock)return;const mock={theme:model.theme,document:{sections:[{id:'block-draft',title:'블록 미리보기',blocks:[draftBlock]}]}};$('#draft-preview').innerHTML=NoticeRenderer.toSvg(NoticeRenderer.build(mock,{view:'block-draft'}),{interactive:true,selectedId:draftBlock.id,selectedRowId:draftSelection.rowId,selectedCellId:draftSelection.cellId,selectedItemId:draftSelection.itemId,images:true});}
  function addSection(){const n=model.document.sections.length+1,s={id:uuid(),label:'새 안내 '+n,title:n+'. 새 안내',blocks:[]};mutate(()=>{model.document.sections.push(s);selectedId=null;},'add-section',true);setView('all');toast('새 안내 구역을 추가했습니다. 구역 안에 블록을 넣어 보세요.');}
  function viewName(){return view==='all'?'전체':model.document.sections.find(s=>s.id===view)?.label||'안내문';}
  let importResult=null,importController=null;
  function bindSourceDrop(dialog,zone,onFile,isBusy,onReject){
    let depth=0;
    const hasFiles=e=>Array.from(e.dataTransfer?.types||[]).includes('Files');
    const reset=()=>{depth=0;zone.classList.remove('is-dragging');};
    dialog.addEventListener('dragenter',e=>{if(!hasFiles(e))return;e.preventDefault();depth++;if(!isBusy())zone.classList.add('is-dragging');});
    dialog.addEventListener('dragover',e=>{if(!hasFiles(e))return;e.preventDefault();e.dataTransfer.dropEffect=isBusy()?'none':'copy';});
    dialog.addEventListener('dragleave',e=>{if(!hasFiles(e))return;depth=Math.max(0,depth-1);if(!depth)reset();});
    dialog.addEventListener('drop',e=>{
      if(!hasFiles(e))return;e.preventDefault();e.stopPropagation();reset();
      if(isBusy())return onReject('현재 파일을 처리하고 있습니다. 완료 후 다른 파일을 넣어 주세요.');
      const files=Array.from(e.dataTransfer.files||[]);
      if(files.length!==1)return onReject('PDF 또는 이미지 파일을 한 개씩 넣어 주세요.');
      onFile(files[0]);
    });
    dialog.addEventListener('close',reset);
    // Keep a file dropped on the backdrop from replacing the editor tab.
    for(const name of ['dragover','drop'])document.addEventListener(name,e=>{if(dialog.open&&hasFiles(e)){e.preventDefault();if(name==='drop')reset();}});
  }
  function showTemplates(){
    const list=[{id:'original',name:'기존 3단 종합 안내',description:'리셋 · LED · Q&A',model:AS_DEFAULTS},...(window.AS_TEMPLATES||[])];
    $('#template-options').innerHTML=list.map(t=>`<button class="template-card" data-use-template="${escape(t.id)}"><div>${NoticeRenderer.toSvg(NoticeRenderer.build(t.model,{view:'all'}),{images:true})}</div><strong>${escape(t.name)}</strong><small>${escape(t.description)}</small><span>이 서식으로 새 안내문 만들기 →</span></button>`).join('');$('#templates-dialog').showModal();
  }
  async function addModel(next,message){await persist();next=validateModel(next);workspace.documents.push({model:next,updatedAt:new Date().toISOString()});workspace.activeId=next.document.id;model=next;selectedId=next.document.sections[0]?.blocks[0]?.id||null;gridSelection={};past=[];future=[];setView('all',false);renderAll();scheduleSave();toast(message);}
  function showSourceImport(){importResult=null;$('#source-result').innerHTML='';$('#source-status').textContent='파일을 끌어다 놓거나 선택하면 원본 모양을 유지하며 글과 사진 영역을 찾습니다.';$('#source-file-name').textContent='';$('#source-progress').value=0;$('#source-confirm').disabled=true;$('#source-file').value='';$('#source-import-dialog').showModal();}
  async function analyzeSource(file){
    if(!file)return;importController?.abort();const own=new AbortController();importController=own;importResult=null;$('#source-confirm').disabled=true;$('#source-file').disabled=true;$('#source-result').innerHTML='';$('#source-file-name').textContent='선택한 파일: '+file.name;$('#source-drop-zone').setAttribute('aria-busy','true');
    try{const result=await ReferenceImport.analyze(file,{signal:own.signal,progress:(text,p)=>{if(importController===own){$('#source-status').textContent=text;$('#source-progress').value=p;}}});if(own.signal.aborted)return;importResult=result;const all=result.document.sections.flatMap(s=>s.blocks[0].source.regions),texts=all.filter(r=>r.kind==='text'),low=texts.filter(r=>r.confidence<80);$('#source-status').textContent=`${result.document.sections.length}쪽 · 글상자 ${texts.length}개 · 사진 후보 ${all.length-texts.length}개 · 확인 필요 ${low.length}개`;$('#source-result').innerHTML='<p>아래는 원본 배치입니다. 추가한 뒤 글상자와 사진 후보를 눌러 확인·수정하세요.</p>'+NoticeRenderer.toSvg(NoticeRenderer.build(result,{view:result.document.sections[0].id}),{images:true});$('#source-confirm').disabled=false;}
    catch(error){if(!own.signal.aborted){$('#source-status').textContent=error.message||'파일을 가져오지 못했습니다. 인터넷 연결과 파일을 확인해 주세요.';$('#source-progress').value=0;}}
    finally{if(importController===own){$('#source-file').disabled=false;$('#source-drop-zone').setAttribute('aria-busy','false');importController=null;}}
  }
  function renderInspector() {
    const found=findBlock();
    if(!found) return renderSettings();
    const {block,section}=found;
    if(block.type==='reference'&&block.source){
      $('#inspector').oninput=null;$('#inspector').onchange=null;$('#inspector').onclick=null;
      ReferenceImport.mount($('#inspector'),{block,itemId:gridSelection.itemId,change:(fn,refresh=false)=>mutate(fn,'source.'+block.id,refresh),select:id=>{gridSelection={itemId:id};renderInspector();renderCanvas();},remove:()=>removeBlock(block.id),pickImage:imageFile,pickIcon:callback=>IconPicker.open(callback),notify:toast});return;
    }
    if(block.grid&&window.GridEditor){
      $('#inspector').oninput=null;$('#inspector').onchange=null;$('#inspector').onclick=null;
      GridEditor.mount($('#inspector'),{block,model,...gridSelection,assets:AS_ASSETS,placementHTML:placementFields(section,block),
        change:(fn,refresh=false)=>mutate(fn,'grid.'+block.id,refresh),
        select:selection=>{gridSelection={...gridSelection,...selection};renderInspector();renderCanvas();},
        saveLibrary:saveLibraryBlock,exit:()=>{selectedId=null;renderAll();},restore:()=>restoreBlockLayout(block),move:direction=>{const at=section.blocks.indexOf(block),to=at+direction;if(to>=0&&to<section.blocks.length)mutate(()=>{section.blocks.splice(at,1);section.blocks.splice(to,0,block);renumberFaq(section);},'move-grid',true);},remove:()=>removeBlock(block.id),pickImage:imageFile,pickIcon:callback=>IconPicker.open(callback),notify:toast});
      return;
    }
    $('#inspector').oninput=null;$('#inspector').onchange=null;$('#inspector').onclick=null;
    let content=placementFields(section,block)+`<button class="button secondary wide" data-design-block>▦ 칸 구성 · 색상 · 그라데이션</button><p class="field-hint" style="margin:7px 0 20px">기존 배치를 바꾸려면 칸을 나누어 글·사진을 넣어 보세요.</p>`+field('제목','title',block.title);
    if(['faq','notice'].includes(block.type))content+=iconField(block);
    if(block.type==='hero')content=field('상단 작은 제목','eyebrow',block.eyebrow)+content;
    if('body' in block)content+=field(['faq','bullets','notice'].includes(block.type)?'안내 항목':'설명','body',block.body,true,['faq','bullets','notice'].includes(block.type)?'한 줄에 한 항목씩 입력하면 글머리표가 붙습니다.':'줄바꿈은 Enter로 넣을 수 있습니다.');
    if('image' in block)content+=photoField('image',block.image);
    if(Array.isArray(block.items)){
      content+='<div class="field-hint">각 칸의 문구와 사진을 아래에서 수정하세요.</div>';
      block.items.forEach((item,i)=>{
        content+=`<div class="subitem"><div class="subitem-title"><span>${block.type==='steps'?'STEP':'사진'} ${i+1}</span><button class="icon-button danger" data-delete-item="${i}" title="이 칸 삭제" aria-label="${i+1}번 칸 삭제">×</button></div>`;
        content+=field('제목',`items.${i}.title`,item.title)+field('설명',`items.${i}.body`,item.body,true);
        if('duration' in item)content+=field('대기 시간 표시',`items.${i}.duration`,item.duration);
        content+=photoField(`items.${i}.image`,item.image)+`</div>`;
      });
      content+=`<button class="button secondary wide" data-add-item>＋ ${block.type==='steps'?'단계':'사진 칸'} 추가</button>`;
    }
    content+=`<button class="button secondary wide" data-save-library>＋ 내 블록으로 저장</button><label class="toggle-field"><span>이 항목을 출력에 포함</span><input type="checkbox" data-visible ${block.hidden?'':'checked'}></label><div class="inspector-actions"><button class="button secondary" data-move="-1">↑ 위로</button><button class="button secondary" data-move="1">↓ 아래로</button><button class="button quiet danger" data-delete-block>항목 삭제</button></div>`;
    $('#inspector').innerHTML=inspectorHeader('EDIT THIS BLOCK',TYPE_NAMES[block.type]||'항목 편집',section.label+' · 변경하면 미리보기에 바로 반영됩니다.')+`<div class="inspector-content"><button class="button delete-block-top" data-delete-block>블록 삭제</button>${content}</div>`;
  }
  function renderSettings() {
    $('#inspector').oninput=null;$('#inspector').onchange=null;$('#inspector').onclick=null;
    const sections=model.document.sections.map((section,i)=>`<div class="section-setting">${field('구역 이름',`document.sections.${i}.label`,section.label)}${field('출력 머리말',`document.sections.${i}.title`,section.title)}${placementFields(section)}<div class="section-tools"><button data-section-move="${i}" data-direction="-1" ${i===0?'disabled':''}>↑</button><button data-section-move="${i}" data-direction="1" ${i===model.document.sections.length-1?'disabled':''}>↓</button><button data-section-library="${escape(section.id)}">블록 넣기</button><button data-section-delete="${i}" class="danger">구역 삭제</button></div></div>`).join('');
    $('#inspector').innerHTML=inspectorHeader('DOCUMENT SETTINGS','큰 틀 · 문서 설정','구역은 계속 추가할 수 있습니다. 너비와 줄바꿈을 구역별로 정하고 블록을 넣으세요.')+`<div class="inspector-content">${field('안내문 이름','document.name',model.document.name)}<label class="field"><span class="field-label">한 줄에 배치할 구역</span><select data-document-columns>${[1,2,3,4].map(n=>`<option value="${n}" ${(model.document.layout?.columns||3)===n?'selected':''}>${n}단${n===3?' · 기존 안내문 비율':''}</option>`).join('')}</select><p class="field-hint">구역이 더 많으면 다음 줄로 이어집니다.</p></label><button class="button secondary wide" data-add-section>＋ 안내 구역 추가</button><details class="native-icon-settings" open><summary>안내 구역 ${model.document.sections.length}개</summary>${sections||'<p class="field-hint">아직 구역이 없습니다. 원하는 만큼 추가해 주세요.</p>'}</details><div class="color-row"><label class="field color-field"><span class="field-label">강조 색상</span><input type="color" data-theme="accent" value="${escape(model.theme.accent)}"></label><label class="field color-field"><span class="field-label">머리말 색상</span><input type="color" data-theme="ink" value="${escape(model.theme.ink)}"></label></div><label class="field"><span class="field-label range-label">전체 글자 크기 <small id="font-scale-label">${Math.round(model.theme.fontScale*100)}%</small></span><input type="range" min="0.85" max="1.3" step="0.05" data-theme="fontScale" value="${model.theme.fontScale}"></label><div class="info-note">기존 안내문은 기본 서식으로 보존됩니다. 새 안내문은 빈 화면에서 시작하며, 만든 블록을 보관함에 저장해 다시 쓸 수 있습니다.</div><button class="button secondary wide" data-restore-template>기존 안내문 서식 가져오기</button><div class="inspector-actions"><button class="button quiet danger" data-delete-document>현재 안내문 삭제</button></div></div>`;
  }
  function updateHeader() {
    $('#document-select').innerHTML=workspace.documents.map(e=>`<option value="${escape(e.model.document.id)}" ${e.model.document.id===workspace.activeId?'selected':''}>${escape(e.model.document.id===workspace.activeId?model.document.name:e.model.document.name)}</option>`).join('');
    $('#canvas-document-name').textContent=model.document.name || '이름 없는 안내문';
    const tabs=$('.view-switch');tabs.innerHTML='<button data-view="all" class="'+(view==='all'?'active':'')+'">한 장으로</button>'+model.document.sections.map(s=>`<button data-view="${escape(s.id)}" class="${view===s.id?'active':''}">${escape(s.label)}</button>`).join('');
  }
  function renderOutline() {
    let count=0;
    $('#outline').innerHTML=model.document.sections.map((s,i)=>{
      count+=s.blocks.length;
      return `<div class="outline-group"><button class="outline-section outline-section-button" data-settings-section="${escape(s.id)}"><span class="section-index">${i+1}</span>${escape(s.label)}<small>${(s.span||1)>1?((s.span||1)>=(model.document.layout?.columns||3)?'전체 너비':s.span+'칸'):'너비 설정'}</small></button>${s.blocks.map(b=>`<div class="outline-block-row"><button class="block-button ${b.id===selectedId?'active':''} ${b.hidden?'is-hidden':''}" data-select="${escape(b.id)}"><span class="block-symbol">${TYPE_SYMBOLS[b.type]||'□'}</span><span>${escape(b.type==='hero'?'대표 이미지 · 제목':b.type==='steps'?'리셋 순서':b.title||TYPE_NAMES[b.type])}</span></button><button class="outline-delete" data-remove-block="${escape(b.id)}" aria-label="블록 삭제: ${escape(b.title||TYPE_NAMES[b.type])}" title="블록 삭제">삭제</button></div>`).join('')}<button class="add-block" data-add-section="${escape(s.id)}">＋ 항목 추가</button></div>`;
    }).join('')+'<button class="add-section-button" data-add-section>＋ 안내 구역 추가</button>';
    $('#block-count').textContent=count+'개';
  }
  function scheduleCanvas() { clearTimeout(renderTimer);renderTimer=setTimeout(renderCanvas,80); }
  function renderCanvas() {
    try {
      if(view!=='all'&&!model.document.sections.some(s=>s.id===view))view='all';
      scene=NoticeRenderer.build(model,{view});
      const empty=!model.document.sections.length;
      $('#paper').classList.toggle('is-empty',empty);
      $('#paper').innerHTML=empty?'<div class="blank-document"><span>▦</span><h2>빈 안내문에서 시작하세요.</h2><p>큰 틀에 안내 구역을 추가하고,<br>직접 만든 블록을 넣어 보세요.</p><button class="button primary" data-add-section>＋ 첫 안내 구역 만들기</button><button class="button secondary" data-open-library>블록부터 만들기</button><button class="text-button" data-use-original>기존 안내문 서식으로 시작</button></div>':NoticeRenderer.toSvg(scene,{interactive:true,selectedId,selectedItemId:gridSelection.itemId,selectedCellId:gridSelection.cellId,selectedRowId:gridSelection.rowId,images:true});
      $('#canvas-dimensions').textContent=empty?'빈 안내문':`${scene.width} × ${scene.height} · ${view==='all'?(model.document.layout?.columns||3)+'단 · '+model.document.sections.length+'개 구역':'개별 안내문'}`;
      $('#canvas-message').textContent=scene.warnings?.length?scene.warnings[0]:'문구가 길어지면 칸 높이가 자동으로 늘어납니다.';
      applyZoom();
      const noContents=!model.document.sections.some(s=>s.blocks.some(b=>!b.hidden));$('#export-image').disabled=noContents;$('#print-document').disabled=noContents;
    } catch(e) { console.error(e);toast('미리보기를 만드는 중 문제가 생겼습니다. 내용을 줄이거나 편집본을 다시 불러와 주세요.'); }
  }
  function applyZoom() { if(!scene)return;const v=$('#zoom').value;$('#paper').style.width=v==='fit'?'100%':Math.round(scene.width*Number(v))+'px';$('#paper').style.maxWidth=v==='fit'?scene.width+'px':'none'; }
  function renderAll() { updateHeader();renderOutline();renderInspector();renderCanvas();updateHistory(); }
  function selectBlock(id,focus,selection) {
    const found=findBlock(id);if(!found)return;selectedId=id;
    gridSelection=selection||{rowId:null,cellId:null,itemId:null};
    if(view!=='all'&&view!==found.section.id)setView(found.section.id,false);
    renderOutline();renderInspector();renderCanvas();
    const selectedRegion=$('#paper').querySelector(`.edit-region[data-block-id="${CSS.escape(id)}"]:not([data-focus])`);
    if(selectedRegion)selectedRegion.scrollIntoView({behavior:'smooth',block:'nearest',inline:'nearest'});
    if(focus){const input=$('#inspector').querySelector(`[data-image-key="${CSS.escape(focus)}"],[data-key="${CSS.escape(focus)}"]`);if(input){input.closest('.photo-field,.field').scrollIntoView({behavior:'smooth',block:'nearest'});if(input.type!=='file')input.focus({preventScroll:true});}}
  }
  function setView(value,render=true) { view=value;document.querySelectorAll('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===view));if(render)renderCanvas(); }
  async function changeDocument(id) { await persist();workspace.activeId=id;model=clone(currentEntry().model);selectedId=model.document.sections[0]?.blocks[0]?.id||null;past=[];future=[];lastField='';setView('all',false);renderAll();scheduleSave(); }
  async function newDocument(copyCurrent=false) {
    await persist(); const next=copyCurrent?clone(model):{schemaVersion:2,theme:clone(model.theme),document:{id:uuid(),name:'새 안내문',layout:{columns:3,width:1536},sections:[]}};next.document.id=uuid();next.document.name=copyCurrent?model.document.name+' 복사본':'새 안내문';
    workspace.documents.push({model:next,updatedAt:new Date().toISOString()});workspace.activeId=next.document.id;model=next;selectedId=null;past=[];future=[];setView('all',false);renderAll();scheduleSave();toast(copyCurrent?'안내문을 복사했습니다.':'새 안내문을 만들었습니다. 오른쪽에서 이름을 적어 주세요.');
  }
  function renumberFaq(section) { let n=1;for(const b of section.blocks){if(b.type==='faq'){b.title=b.title.replace(/^Q\d+[.．]?\s*/,`Q${n}. `);if(b.grid){let replaced=false;for(const r of b.grid.rows)for(const c of r.cells)for(const item of c.items){if(!replaced&&item.type==='text'&&/^Q\d+[.．]?\s*/.test(item.text)){item.text=item.text.replace(/^Q\d+[.．]?\s*/,`Q${n}. `);replaced=true;}}}n++;}} }
  function addBlock(type) {
    const section=model.document.sections.find(s=>s.id===targetSection);if(!section)return;
    let block={id:uuid(),type,title:'새 안내 제목',body:'안내할 내용을 입력해 주세요.'};
    if(type==='faq')block.title=`Q${section.blocks.filter(b=>b.type==='faq').length+1}. 새 질문을 입력해 주세요.`;
    if(type==='led')Object.assign(block,{title:'새 제품 타입',image:''});
    if(type==='photos')block={id:block.id,type,title:'사진 안내',items:[{id:uuid(),title:'사진 설명',body:'설명을 입력해 주세요.',image:''}]};
    mutate(()=>{section.blocks.push(block);selectedId=block.id;},'add',true);$('#add-dialog').close();selectBlock(block.id);toast('새 칸을 추가했습니다.');
  }
  function showAddDialog(sectionId) {
    showLibrary(sectionId);
  }
  async function imageFile(file) {
    if(!/^image\/(png|jpeg|webp)$/.test(file.type))throw new Error('JPG, PNG, WebP 사진을 선택해 주세요.');
    if(file.size>25*1024*1024)throw new Error('사진 한 장은 25MB 이하로 선택해 주세요.');
    const url=URL.createObjectURL(file);const image=new Image();image.src=url;
    try{await image.decode();const ratio=Math.min(1,1600/Math.max(image.naturalWidth,image.naturalHeight));const c=document.createElement('canvas');c.width=Math.round(image.naturalWidth*ratio);c.height=Math.round(image.naturalHeight*ratio);const ctx=c.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,c.width,c.height);ctx.drawImage(image,0,0,c.width,c.height);return c.toDataURL('image/jpeg',.9);}finally{URL.revokeObjectURL(url);}
  }
  function cleanName() { return (model.document.name||'AS 안내문').replace(/[<>:"/\\|?*\x00-\x1f]/g,'_').slice(0,70); }
  function download(blob,name) { const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000); }
  function embeddedBlock(source){const b=clone(source);if('image'in b)b.image=asset(b.image);if(b.iconImage)b.iconImage=asset(b.iconImage);if(b.items)for(const item of b.items)item.image=asset(item.image);if(b.grid)for(const r of b.grid.rows)for(const c of r.cells)for(const item of c.items){if(item.type==='image')item.src=asset(item.src);if(item.iconImage)item.iconImage=asset(item.iconImage);}return b;}
  function exportProject() {
    const ready=clone(model);ready.schemaVersion=2;
    for(const section of ready.document.sections)section.blocks=section.blocks.map(embeddedBlock);
    const library=workspace.library.map(e=>({...e,block:embeddedBlock(e.block)}));
    download(new Blob([JSON.stringify({format:'as-notice-editor',schemaVersion:2,savedAt:new Date().toISOString(),model:ready,library},null,2)],{type:'application/json'}),cleanName()+'.안내문.json');toast('사진·칸 구성·효과·내 블록을 함께 저장했습니다.');
  }
  function validateModel(value) {
    if(!value||![1,2].includes(value.schemaVersion)||!value.document||!Array.isArray(value.document.sections)||value.document.sections.length>80)throw new Error('이 편집기의 안내문 파일을 선택해 주세요.');
    const m=clone(value);m.schemaVersion=2;const allowed=new Set(Object.keys(TYPE_NAMES));const ids=new Set();const sectionIds=new Set();
    m.document.id=uuid();m.document.name=String(m.document.name||'불러온 안내문').slice(0,500);
    m.document.layout={columns:Math.min(4,Math.max(1,Math.round(Number(m.document.layout?.columns)||3))),width:1536};
    m.theme={accent:/^#[0-9a-f]{6}$/i.test(m.theme?.accent)?m.theme.accent:'#0866e8',ink:/^#[0-9a-f]{6}$/i.test(m.theme?.ink)?m.theme.ink:'#132b49',fontScale:Math.min(1.3,Math.max(.85,Number(m.theme?.fontScale)||1))};
    m.document.sections.forEach((section,i)=>{
      if(typeof section.id!=='string'||!/^[a-zA-Z0-9_-]+$/.test(section.id)||sectionIds.has(section.id))section.id=uuid();sectionIds.add(section.id);
      section.hideTitle=section.hideTitle===true;section.span=Math.min(4,Math.max(1,Math.round(Number(section.span)||1)));section.startNewRow=section.startNewRow===true;
      section.label=String(section.label||'안내 '+(i+1)).slice(0,100);section.title=String(section.title||section.label).slice(0,500);
      if(!Array.isArray(section.blocks)||section.blocks.length>100)throw new Error('안내문 항목 형식을 확인해 주세요.');
      section.blocks.forEach(b=>{
        if(!allowed.has(b.type))throw new Error('지원하지 않는 안내문 칸이 있습니다.');
        if(typeof b.id!=='string'||ids.has(b.id))b.id=uuid();ids.add(b.id);
        for(const key of ['title','eyebrow','body'])if(key in b)b[key]=String(b[key]??'').slice(0,10000);
        if('image'in b)b.image=asset(b.image);
        if(b.iconImage)b.iconImage=asset(b.iconImage);
        if(b.icon&&!ICONS.some(([key])=>key===b.icon))b.icon='auto';if(b.emoji)b.emoji=String(b.emoji).slice(0,80);if(b.iconColor&&!/^#[0-9a-f]{6}$/i.test(b.iconColor))delete b.iconColor;
        if(['steps','photos'].includes(b.type)&&!Array.isArray(b.items))b.items=[];
        if(b.items){if(!Array.isArray(b.items)||b.items.length>100)throw new Error('사진·단계 수를 확인해 주세요.');b.items=b.items.map(item=>({id:uuid(),title:String(item.title||'').slice(0,500),body:String(item.body||'').slice(0,10000),image:asset(item.image),...(item.duration?{duration:String(item.duration).slice(0,100)}:{})}));}
        if(b.type==='reference')b.source=ReferenceImport.normalize(b.source);
        if(b.grid)b.grid=GridValidator.normalize(b.grid);else if(b.type==='grid')throw new Error('칸 구성이 없는 블록입니다.');
      });
    });return m;
  }
  async function importProject(file) {
    if(file.size>35*1024*1024)throw new Error('편집본은 35MB 이하 파일을 선택해 주세요.');
    const data=JSON.parse(await file.text());const next=validateModel(data.model||data);const imported=[];
    if(data.library){if(!Array.isArray(data.library)||data.library.length>200)throw new Error('블록 보관함 형식을 확인해 주세요.');for(const entry of data.library){const temp=validateModel({schemaVersion:2,theme:next.theme,document:{sections:[{id:'imported',label:'블록',blocks:[entry.block]}]}});imported.push({id:uuid(),name:String(entry.name||'불러온 블록').slice(0,100),block:temp.document.sections[0].blocks[0],savedAt:entry.savedAt||new Date().toISOString()});}}
    await persist();workspace.documents.push({model:next,updatedAt:new Date().toISOString()});workspace.library.push(...imported);workspace.activeId=next.document.id;model=next;selectedId=null;gridSelection={};past=[];future=[];setView('all',false);renderAll();scheduleSave();toast('안내문과 블록 보관함을 불러왔습니다. 기존 안내문은 보관했습니다.');
  }
  async function exportImage() {
    if(imageBusy)return;imageBusy=true;const button=$('#confirm-export');const original=button.textContent;button.textContent='이미지를 만들고 있어요…';button.disabled=true;
    try{
      await document.fonts.ready;renderCanvas();const mode=$('input[name="export-quality"]:checked').value;
      let blob,outputWidth;const widths=mode==='notion'?[2400,2200,2000,1800,1600,1400,1200]:[3200];
      for(const width of widths){if(scene.height/scene.width*width*width>50000000)continue;const canvas=await NoticeRenderer.toCanvas(scene,width);blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));outputWidth=width;if(blob&&(mode!=='notion'||blob.size<4700000))break;}
      if(!blob)throw new Error('내용이 너무 길어 이미지로 만들기 어렵습니다. 개별 안내문으로 나눠 저장해 주세요.');
      if(mode==='notion'&&blob.size>=4700000)throw new Error('사진이 많아 5MB 이하로 줄이지 못했습니다. 개별 안내문을 선택해 저장해 주세요.');
      const suffix=viewName();download(blob,cleanName()+'_'+suffix+'.png');$('#export-dialog').close();toast(`PNG 저장 완료 · ${(blob.size/1000000).toFixed(2)}MB · 가로 ${outputWidth}px`);
    }catch(e){console.error(e);toast(e.message||'이미지 저장 중 문제가 생겼습니다.');}finally{imageBusy=false;button.textContent=original;button.disabled=false;}
  }
  function preparePrint() {
    scene=NoticeRenderer.build(model,{view});let area=$('#print-area');if(!area){area=document.createElement('div');area.id='print-area';document.body.append(area);}area.innerHTML=NoticeRenderer.toSvg(scene,{interactive:false,images:true});
    let css=$('#print-sizes');if(!css){css=document.createElement('style');css.id='print-sizes';document.head.append(css);}css.textContent=`@media print{@page{size:A4 ${view==='all'?'landscape':'portrait'};margin:10mm}#print-area svg{max-height:${view==='all'?185:277}mm}}`;
  }
  async function printDocument() {
    await document.fonts.ready;preparePrint();$('#print-dialog').close();await new Promise(resolve=>setTimeout(resolve,180));window.print();
  }
  async function downloadPDF() {
    const button=$('#download-pdf');button.disabled=true;button.textContent='PDF를 만들고 있어요…';
    try{
      await document.fonts.ready;scene=NoticeRenderer.build(model,{view});
      const width=Math.min(2600,Math.floor(Math.sqrt(45000000*scene.width/scene.height)));
      const canvas=await NoticeRenderer.toCanvas(scene,width);
      const blob=await NoticeExporter.toPDF(canvas,{landscape:view==='all'});
      download(blob,cleanName()+'_'+viewName()+'.pdf');
      $('#print-dialog').close();toast('PDF를 저장했습니다.');
    }catch(e){console.error(e);toast(e.message||'PDF 저장 중 문제가 생겼습니다.');}
    finally{button.disabled=false;button.textContent='PDF 파일 저장';}
  }
  function attachEvents() {
    $('#document-select').addEventListener('change',e=>changeDocument(e.target.value));$('#new-document').onclick=()=>newDocument();$('#duplicate-document').onclick=()=>newDocument(true);
    $('#document-settings').onclick=()=>{selectedId=null;renderInspector();renderOutline();renderCanvas();};
    $('#outline').onclick=e=>{const remove=e.target.closest('[data-remove-block]');if(remove){removeBlock(remove.dataset.removeBlock);return;}const settings=e.target.closest('[data-settings-section]');if(settings){selectedId=null;renderAll();$('#inspector').querySelector('[data-section-span="'+CSS.escape(settings.dataset.settingsSection)+'"]').closest('.section-setting').scrollIntoView({block:'nearest'});return;}const s=e.target.closest('[data-select]');if(s)selectBlock(s.dataset.select);const add=e.target.closest('[data-add-section]');if(add){if(add.dataset.addSection)showAddDialog(add.dataset.addSection);else addSection();}};
    $('#paper').addEventListener('click',e=>{const el=e.target.closest('[data-block-id]');if(el)selectBlock(el.dataset.blockId,el.dataset.focus,{rowId:el.dataset.rowId||null,cellId:el.dataset.cellId||null,itemId:el.dataset.itemId||null});if(e.target.closest('[data-add-section]'))addSection();if(e.target.closest('[data-open-library]'))showLibrary();if(e.target.closest('[data-use-original]')){mutate(()=>{const id=model.document.id,name=model.document.name;model=clone(AS_DEFAULTS);model.document.id=id;model.document.name=name;selectedId=null;},'original',true);}});
    $('#paper').addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){const el=e.target.closest('[data-block-id]');if(el){e.preventDefault();selectBlock(el.dataset.blockId,el.dataset.focus);}}});
    $('.view-switch').onclick=e=>{const b=e.target.closest('[data-view]');if(b)setView(b.dataset.view);};$('#zoom').onchange=applyZoom;$('#undo').onclick=undo;$('#redo').onclick=redo;
    $('#inspector').addEventListener('input',e=>{
      const key=e.target.dataset.key;const theme=e.target.dataset.theme;
      if(theme){mutate(()=>model.theme[theme]=theme==='fontScale'?Number(e.target.value):e.target.value,'theme.'+theme);if(theme==='fontScale')$('#font-scale-label').textContent=Math.round(model.theme.fontScale*100)+'%';return;}
      if(!key)return;
      if(!selectedId)mutate(()=>setPath(model,key,e.target.value),key);else{const f=findBlock();if(f)mutate(()=>setPath(f.block,key,e.target.value),selectedId+'.'+key);}
    });
    $('#inspector').addEventListener('change',async e=>{
      if(e.target.matches('[data-document-columns]'))mutate(()=>{model.document.layout={...(model.document.layout||{}),columns:Number(e.target.value),width:1536};},'columns',true);
      if(e.target.hasAttribute('data-section-span')){const section=model.document.sections.find(s=>s.id===e.target.dataset.sectionSpan);if(section)mutate(()=>section.span=Number(e.target.value),'section-span-'+section.id,true);}
      if(e.target.hasAttribute('data-section-heading')){const section=model.document.sections.find(s=>s.id===e.target.dataset.sectionHeading);if(section)mutate(()=>section.hideTitle=!e.target.checked,'section-heading-'+section.id);}
      if(e.target.hasAttribute('data-section-new-row')){const section=model.document.sections.find(s=>s.id===e.target.dataset.sectionNewRow);if(section)mutate(()=>section.startNewRow=e.target.checked,'section-row-'+section.id);}
      if(e.target.hasAttribute('data-block-section')){const f=findBlock(e.target.dataset.blockSection),target=model.document.sections.find(s=>s.id===e.target.value);if(f&&target&&f.section!==target)mutate(()=>{f.section.blocks=f.section.blocks.filter(b=>b!==f.block);target.blocks.push(f.block);renumberFaq(f.section);renumberFaq(target);},'move-section',true);}
      if(e.target.matches('[data-native-icon]')){const f=findBlock();if(f)mutate(()=>{f.block.icon=e.target.value;if(f.block.icon==='emoji'&&!f.block.emoji)f.block.emoji='❗';},'icon',true);}
      if(e.target.matches('[data-visible]')){const f=findBlock();if(f)mutate(()=>f.block.hidden=!e.target.checked,'visible');}
      if(e.target.matches('[data-image-key]')&&e.target.files[0]){const f=findBlock();const key=e.target.dataset.imageKey;try{const data=await imageFile(e.target.files[0]);if(f){mutate(()=>setPath(f.block,key,data),'image',true);toast('사진을 바꿨습니다.');}}catch(error){toast(error.message);}}
    });
    $('#inspector').addEventListener('click',e=>{
      const f=findBlock();const target=e.target.closest('button');if(!target)return;
      if(target.hasAttribute('data-pick-native-icon')&&f){const b=f.block;IconPicker.open(value=>mutate(()=>Object.assign(b,value),'custom-icon',true));}
      if(target.hasAttribute('data-design-block')&&f)mutate(()=>{f.block.grid=GridLayout.fromBlock(f.block,model);gridSelection={};},'design',true);
      if(target.hasAttribute('data-save-library')&&f)saveLibraryBlock(f.block);
      if(target.hasAttribute('data-native-emoji')&&f)mutate(()=>{f.block.icon='emoji';f.block.emoji=target.dataset.nativeEmoji;},'emoji',true);
      if(target.hasAttribute('data-add-section'))addSection();
      if(target.hasAttribute('data-section-library'))showLibrary(target.dataset.sectionLibrary);
      if(target.hasAttribute('data-section-move')){const i=Number(target.dataset.sectionMove),next=i+Number(target.dataset.direction);if(next>=0&&next<model.document.sections.length)mutate(()=>{const [s]=model.document.sections.splice(i,1);model.document.sections.splice(next,0,s);},'section-move',true);}
      if(target.hasAttribute('data-section-delete'))mutate(()=>{model.document.sections.splice(Number(target.dataset.sectionDelete),1);},'section-delete',true);
      if(target.hasAttribute('data-clear-image')&&f)mutate(()=>setPath(f.block,target.dataset.clearImage,''),'image',true);
      if(target.hasAttribute('data-delete-block')&&f)removeBlock(f.block.id);
      if(target.hasAttribute('data-full-row'))makeFullRow(target.dataset.fullRow);
      if(target.hasAttribute('data-move')&&f){const i=f.section.blocks.indexOf(f.block);const n=i+Number(target.dataset.move);if(n>=0&&n<f.section.blocks.length)mutate(()=>{f.section.blocks.splice(i,1);f.section.blocks.splice(n,0,f.block);renumberFaq(f.section);},'move');}
      if(target.hasAttribute('data-add-item')&&f){mutate(()=>f.block.items.push({id:uuid(),title:'새 제목',body:'설명을 입력해 주세요.',image:''}),'add-item',true);}
      if(target.hasAttribute('data-delete-item')&&f)mutate(()=>f.block.items.splice(Number(target.dataset.deleteItem),1),'delete-item',true);
      if(target.hasAttribute('data-restore-template')){mutate(()=>{const id=model.document.id;const name=model.document.name;model=clone(AS_DEFAULTS);model.document.id=id;model.document.name=name;selectedId=null;},'restore',true);toast('기본 서식으로 되돌렸습니다. 되돌리기로 복구할 수 있습니다.');}
      if(target.hasAttribute('data-delete-document')){const index=workspace.documents.findIndex(e=>e.model.document.id===workspace.activeId);workspace.documents.splice(index,1);if(!workspace.documents.length){const fresh=clone(AS_DEFAULTS);fresh.document.id=uuid();workspace.documents.push({model:fresh,updatedAt:new Date().toISOString()});}workspace.activeId=workspace.documents[0].model.document.id;model=clone(workspace.documents[0].model);selectedId=null;past=[];future=[];renderAll();scheduleSave();toast('안내문을 삭제했습니다.');}
    });
    $('#inspector').addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target.matches('label[role="button"]')){e.preventDefault();e.target.querySelector('input[type="file"]').click();}});
    $('#add-options').onclick=e=>{const b=e.target.closest('[data-add-type]');if(b)addBlock(b.dataset.addType);};
    $('#template-library').onclick=showTemplates;$('#source-import').onclick=showSourceImport;
    bindSourceDrop($('#source-import-dialog'),$('#source-drop-zone'),analyzeSource,()=>!!importController,toast);
    $('#template-options').onclick=async e=>{const b=e.target.closest('[data-use-template]');if(!b)return;const t=b.dataset.useTemplate==='original'?AS_DEFAULTS:window.AS_TEMPLATES.find(t=>t.id===b.dataset.useTemplate)?.model;if(t){await addModel(t,'새 서식의 안내문을 만들었습니다. 기존 안내문은 보관했습니다.');$('#templates-dialog').close();}};
    $('#source-file').onchange=e=>analyzeSource(e.target.files[0]);$('#source-confirm').onclick=async()=>{if(!importResult)return;await addModel(importResult,'가져온 자료를 새 안내문으로 추가했습니다. 인식 내용을 원본과 확인해 주세요.');$('#source-import-dialog').close();};$('#source-import-dialog').addEventListener('close',()=>{importController?.abort();importResult=null;});
    $('#block-library').onclick=()=>showLibrary();$('#save-block-confirm').onclick=saveNamedBlock;
    $('#library-presets').onclick=e=>{const b=e.target.closest('[data-library-preset]');if(b)openDraft(b.dataset.libraryPreset);};
    $('#library-target').onchange=e=>targetSection=e.target.value;
    $('#saved-blocks').onclick=e=>{
      const remove=e.target.closest('[data-delete-library]'),restore=e.target.closest('[data-restore-library]');
      if(remove){const at=workspace.library.findIndex(b=>b.id===remove.dataset.deleteLibrary);if(at<0)return;workspace.libraryTrash.push(workspace.library.splice(at,1)[0]);scheduleSave();renderLibrary();toast('보관함에서 삭제했습니다. 아래 ‘삭제한 보관 블록’에서 복구할 수 있습니다.');return;}
      if(restore){const at=workspace.libraryTrash.findIndex(b=>b.id===restore.dataset.restoreLibrary);if(at<0)return;workspace.library.push(workspace.libraryTrash.splice(at,1)[0]);scheduleSave();renderLibrary();toast('블록을 보관함에 복구했습니다.');return;}
      const insert=e.target.closest('[data-insert-library]'),edit=e.target.closest('[data-edit-library]');const entry=workspace.library.find(b=>b.id===(insert?.dataset.insertLibrary||edit?.dataset.editLibrary));if(!entry)return;if(insert)insertBlock(entry.block,$('#library-target').value);else openDraft(null,entry);
    };
    $('#insert-draft').onclick=()=>{if(!draftBlock)return;if(!model.document.sections.length){const s={id:uuid(),label:'새 안내 1',title:'1. 새 안내',blocks:[]};mutate(()=>model.document.sections.push(s),'first-section');$('#draft-target').innerHTML=sectionOptions(s.id);}insertBlock(draftBlock,$('#draft-target').value);};
    $('#draft-preview').onclick=e=>{const el=e.target.closest('[data-block-id]');if(el){draftSelection={rowId:el.dataset.rowId||null,cellId:el.dataset.cellId||null,itemId:el.dataset.itemId||null};renderDraft();}};
    $('#download-project').onclick=exportProject;$('#import-project').onclick=()=>$('#project-file').click();
    $('#project-file').onchange=async e=>{if(!e.target.files[0])return;try{await importProject(e.target.files[0]);}catch(error){toast(error.message||'편집본 파일을 확인해 주세요.');}e.target.value='';};
    $('#export-image').onclick=()=>$('#export-dialog').showModal();$('#confirm-export').onclick=exportImage;$('#print-document').onclick=()=>$('#print-dialog').showModal();$('#open-print').onclick=printDocument;$('#download-pdf').onclick=downloadPDF;
    $('#help-button').onclick=()=>$('#help-dialog').showModal();$('#close-help').onclick=()=>$('#help-dialog').close();
    window.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s'){e.preventDefault();exportProject();}if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'&&!e.target.matches('input,textarea')){e.preventDefault();e.shiftKey?redo():undo();}});
    window.addEventListener('beforeprint',preparePrint);
    window.addEventListener('resize',applyZoom);window.addEventListener('beforeunload',()=>{if(saveTimer){const entry=currentEntry();if(entry)entry.model=clone(model);try{localStorage.setItem('as-notice-studio-pending',JSON.stringify(workspace));}catch(_){}storageWrite(workspace).catch(()=>{});}});
    document.addEventListener('visibilitychange',()=>{if(document.hidden&&saveTimer)persist();});
  }
  async function init() {
    await document.fonts.ready;
    let pending;try{pending=JSON.parse(localStorage.getItem('as-notice-studio-pending')||'null');}catch(_){}
    const saved=pending||await storageRead();
    if(saved?.schemaVersion===1&&Array.isArray(saved.documents)&&saved.documents.length){workspace=saved;if(!saved.documents.some(e=>e.model?.document?.id===saved.activeId))workspace.activeId=saved.documents[0].model.document.id;model=clone(currentEntry().model);}
    else {const first=clone(AS_DEFAULTS);workspace={schemaVersion:1,activeId:first.document.id,documents:[{model:first,updatedAt:new Date().toISOString()}]};model=clone(first);}
    if(!Array.isArray(workspace.library))workspace.library=[];
    if(!Array.isArray(workspace.libraryTrash))workspace.libraryTrash=[];
    attachEvents();renderAll();await persist();
    window.NoticeStudio={getModel:()=>clone(model),getScene:()=>scene,getView:()=>view,storageAvailable:()=>storageOK};
  }
  init().catch(e=>{console.error(e);$('#paper').innerHTML='<div class="empty-inspector">편집기를 시작하지 못했습니다. 새로고침하거나 사용 방법을 확인해 주세요.</div>';saveStatus('시작하지 못했습니다',true);});
})();
