(function(){
  'use strict';
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const bindings=new WeakMap();
  const same=(a,b)=>a.fontSize===b.fontSize&&a.weight===b.weight&&a.color===b.color;
  function cleanStyle(s){const o={};if(Number.isFinite(s.fontSize))o.fontSize=Math.max(8,Math.min(72,s.fontSize));if(Number.isFinite(s.weight))o.weight=Math.round(Math.max(400,Math.min(800,s.weight))/100)*100;if(/^#[0-9a-f]{6}$/i.test(s.color||''))o.color=s.color.toLowerCase();return o;}
  function normalize(text,spans){
    if(spans==null)return [];
    if(!Array.isArray(spans)||spans.length>2000)throw Error('부분 글자 서식은 2,000개 이하로 나누어 주세요.');
    const result=[];let end=0;
    for(const s of [...spans].sort((a,b)=>(a?.start||0)-(b?.start||0))){
      if(!s||!Number.isInteger(s.start)||!Number.isInteger(s.end)||s.start<0||s.end>text.length||s.end<=s.start||s.start<end)throw Error('부분 글자 서식의 선택 범위를 확인해 주세요.');
      const v={start:s.start,end:s.end,...cleanStyle(s)};end=s.end;
      if(Object.keys(v).length===2)continue;
      const prev=result.at(-1);if(prev&&prev.end===v.start&&same(prev,v))prev.end=v.end;else result.push(v);
    }return result;
  }
  function apply(text,spans,start,end,patch){
    const old=normalize(text,spans);start=Math.max(0,Math.min(text.length,start));end=Math.max(start,Math.min(text.length,end));if(start===end)return old;
    const points=[...new Set([0,text.length,start,end,...old.flatMap(s=>[s.start,s.end])])].sort((a,b)=>a-b),result=[];
    for(let i=0;i<points.length-1;i++){const a=points[i],b=points[i+1];let s=cleanStyle(old.find(v=>a>=v.start&&a<v.end)||{});if(a>=start&&b<=end)s=patch===null?{}:{...s,...cleanStyle(patch)};if(Object.keys(s).length)result.push({start:a,end:b,...s});}
    return normalize(text,result);
  }
  function edit(before,after,spans){
    const old=normalize(before,spans);let start=0,tail=0;
    while(start<before.length&&start<after.length&&before[start]===after[start])start++;
    while(tail<before.length-start&&tail<after.length-start&&before[before.length-tail-1]===after[after.length-tail-1])tail++;
    const stop=before.length-tail,insertEnd=after.length-tail,delta=after.length-before.length,out=[];
    for(const s of old){if(s.start<start)out.push({...s,end:Math.min(s.end,start)});if(s.end>stop)out.push({...s,start:Math.max(s.start,stop)+delta,end:s.end+delta});}
    const inherited=old.find(s=>start>=s.start&&start<s.end)||old.find(s=>start===s.end);
    if(inherited&&insertEnd>start)out.push({start,end:insertEnd,...cleanStyle(inherited)});
    return normalize(after,out);
  }
  function slice(text,spans,start,end){return {text:text.slice(start,end),spans:normalize(text,spans).filter(s=>s.end>start&&s.start<end).map(s=>({...s,start:Math.max(start,s.start)-start,end:Math.min(end,s.end)-start}))};}
  function normalizeBreaks(text,breaks){
    if(breaks==null)return [];if(!Array.isArray(breaks)||breaks.length>10000||breaks.some(p=>!Number.isInteger(p)||p<0||text[p]!=='\n'))throw Error('같은 항목 안의 줄바꿈 위치를 확인해 주세요.');return [...new Set(breaks)].sort((a,b)=>a-b);
  }
  function editBreaks(before,after,breaks){
    const old=normalizeBreaks(before,breaks);let start=0,tail=0;while(start<before.length&&start<after.length&&before[start]===after[start])start++;while(tail<before.length-start&&tail<after.length-start&&before[before.length-tail-1]===after[after.length-tail-1])tail++;
    return normalizeBreaks(after,old.filter(p=>p<start||p>=before.length-tail).map(p=>p<start?p:p+after.length-before.length));
  }
  function layout(text,spans,width,base,measure,scale=1,bullets=false,softBreaks=[]){
    const ranges=normalize(text,spans),lines=[];let offset=0;
    const pieces=s=>{try{return Array.from(new Intl.Segmenter(undefined,{granularity:'grapheme'}).segment(s),v=>v.segment);}catch(_){return Array.from(s);}};
    function describe(chars,bullet){
      const runs=[];for(const ch of chars){const prev=runs.at(-1);if(prev&&same(prev,ch))prev.text+=ch.text;else runs.push({...ch});}
      let total=0,max=base.fontSize;for(const r of runs){r.width=measure(r.text,r.fontSize,r.weight);total+=r.width;max=Math.max(max,r.fontSize);}
      return {runs,width:total,size:max,height:max*base.lineHeight,bullet,text:chars.map(c=>c.text).join('')};
    }
    for(const para of text.split('\n')){
      const paragraphStart=offset;offset+=para.length+1;const continuation=softBreaks.includes(paragraphStart-1);if(bullets&&!para.trim()&&!continuation)continue;
      let row=[],rowWidth=0,first=!continuation;
      const flush=()=>{while(row.length&&/^[ \t]$/.test(row.at(-1).text))row.pop();lines.push(describe(row,bullets&&first));first=false;};
      let at=paragraphStart;
      for(const ch of pieces(para)){
        const s=ranges.find(s=>at>=s.start&&at<s.end)||{},c={text:ch,fontSize:s.fontSize? s.fontSize*scale:base.fontSize,weight:s.weight||base.weight,color:s.color||base.color};at+=ch.length;
        const cw=measure(ch,c.fontSize,c.weight);
        if(row.length&&rowWidth+cw>width){
          let space=-1;row.forEach((c,i)=>{if(c.text===' ')space=i;});
          if(space>row.length*.45){const carry=row.slice(space+1);row=row.slice(0,space);flush();row=carry;rowWidth=describe(row,false).width;}
          else {flush();row=[];rowWidth=0;}
        }
        row.push(c);rowWidth+=cw;
      }flush();
    }
    if(!lines.length)lines.push(describe([],false));return {lines,height:lines.reduce((sum,l)=>sum+l.height,0)};
  }
  function preview(text,spans){
    text=String(text??'');
    const ranges=normalize(text,spans);let at=0,html='';for(const s of ranges){html+=esc(text.slice(at,s.start));const st=cleanStyle(s);html+='<span style="'+(st.fontSize?'font-size:'+st.fontSize+'px;':'')+(st.weight?'font-weight:'+st.weight+';':'')+(st.color?'color:'+st.color+';':'')+'">'+esc(text.slice(s.start,s.end))+'</span>';at=s.end;}return html+esc(text.slice(at));
  }
  function field(label,text,key,attrs,area=false,spans=[]){text=String(text??'');return `<div class="rich-field" data-rich-field="${esc(key)}"><label class="ge-field field"><span class="field-label">${esc(label)}</span>${area?`<textarea rows="6" maxlength="10000" data-rich-input ${attrs}>${esc(text)}</textarea>`:`<input type="text" maxlength="500" data-rich-input ${attrs} value="${esc(text)}">`}</label>${area?'<p class="rt-break-hint">Enter: 새 항목 · Shift+Enter: 같은 항목 안에서 줄바꿈</p>':''}<div class="rt-toolbar" role="group" aria-label="선택한 글자 서식"><button type="button" data-rich-bold title="선택한 글자를 굵게" aria-label="선택한 글자를 굵게"><b>B</b> 굵게</button><select data-rich-size aria-label="선택한 글자 크기"><option value="">크기</option>${[10,12,14,16,18,20,22,24,28,32,36,40,48,60,72].map(n=>`<option value="${n}">${n}px</option>`).join('')}</select><input type="color" data-rich-color value="#0866e8" aria-label="선택한 글자 색상"><button type="button" data-rich-clear title="선택한 글자의 부분 서식 지우기">서식 지우기</button></div><p class="rt-status" aria-live="polite">위 글에서 원하는 부분을 드래그해 선택하세요.</p><div class="rt-preview" aria-label="부분 서식 미리보기" ${spans.length?'':'hidden'}>${preview(text,spans)}</div></div>`;}
  function bind(root,adapter){
    bindings.get(root)?.abort();const controller=new AbortController();bindings.set(root,controller);const options={capture:true,signal:controller.signal};
    const selections=new WeakMap();
    function update(w){const input=w.querySelector('[data-rich-input]'),range=selections.get(w)||[0,0],has=range[1]>range[0];w.querySelectorAll('.rt-toolbar button,.rt-toolbar select,.rt-toolbar input').forEach(el=>el.disabled=!has);w.querySelector('.rt-status').textContent=has?`선택한 ${range[1]-range[0]}자에만 적용합니다.`:'위 글에서 원하는 부분을 드래그해 선택하세요.';const value=adapter.read(w.dataset.richField),p=w.querySelector('.rt-preview');p.hidden=!value.spans?.length;p.innerHTML=preview(input.value,value.spans);}
    function selected(e){const input=e.target;if(!input.matches?.('[data-rich-input]'))return;const w=input.closest('[data-rich-field]');selections.set(w,[input.selectionStart,input.selectionEnd]);update(w);}
    for(const event of ['select','keyup','mouseup','focusin'])root.addEventListener(event,selected,options);
    root.addEventListener('input',e=>{const input=e.target;if(!input.matches?.('[data-rich-input]'))return;e.stopImmediatePropagation();const w=input.closest('[data-rich-field]'),old=adapter.read(w.dataset.richField);adapter.write(w.dataset.richField,input.value,edit(old.text,input.value,old.spans),editBreaks(old.text,input.value,old.softBreaks));selected(e);},options);
    root.addEventListener('keydown',e=>{const input=e.target;if(e.key!=='Enter'||!e.shiftKey||!input.matches?.('textarea[data-rich-input]'))return;e.preventDefault();e.stopImmediatePropagation();const w=input.closest('[data-rich-field]'),old=adapter.read(w.dataset.richField),start=input.selectionStart,end=input.selectionEnd,value=input.value.slice(0,start)+'\n'+input.value.slice(end),breaks=editBreaks(old.text,value,old.softBreaks);breaks.push(start);adapter.write(w.dataset.richField,value,edit(old.text,value,old.spans),normalizeBreaks(value,breaks));input.value=value;input.setSelectionRange(start+1,start+1);selected({target:input});},options);
    root.addEventListener('pointerdown',e=>{if(e.target.closest('[data-rich-bold],[data-rich-clear]'))e.preventDefault();},options);
    function format(e){const el=e.target.closest('[data-rich-bold],[data-rich-clear],[data-rich-size],[data-rich-color]');if(!el)return;const w=el.closest('[data-rich-field]');if(!w)return;e.stopImmediatePropagation();const range=selections.get(w);if(!range||range[1]<=range[0])return;const v=adapter.read(w.dataset.richField),input=w.querySelector('[data-rich-input]');let patch;
      if(el.hasAttribute('data-rich-size')){if(!el.value)return;patch={fontSize:Number(el.value)};}
      else if(el.hasAttribute('data-rich-color'))patch={color:el.value};
      else if(el.hasAttribute('data-rich-clear'))patch=null;
      else {const s=normalize(v.text,v.spans).find(s=>range[0]>=s.start&&range[0]<s.end);patch={weight:(s?.weight||v.weight||400)>=700?400:700};}
      adapter.write(w.dataset.richField,v.text,apply(v.text,v.spans,range[0],range[1],patch),v.softBreaks||[]);update(w);
      if(el.tagName==='BUTTON'){input.focus();input.setSelectionRange(...range);}el.value=el.hasAttribute('data-rich-size')?'':el.value;
    }
    root.addEventListener('click',e=>{if(e.target.closest('[data-rich-bold],[data-rich-clear]'))format(e);},options);
    root.addEventListener('change',e=>{if(e.target.matches('[data-rich-size],[data-rich-color]'))format(e);},options);
    root.querySelectorAll('[data-rich-field]').forEach(update);
  }
  window.RichText={normalize,apply,edit,slice,layout,field,bind,preview,normalizeBreaks,editBreaks};
})();
