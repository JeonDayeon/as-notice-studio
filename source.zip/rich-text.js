(function(){
  'use strict';
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const bindings=new WeakMap();
  const same=(a,b)=>a.fontSize===b.fontSize&&a.weight===b.weight&&a.color===b.color;
  function cleanStyle(s){const o={};if(Number.isFinite(s.fontSize))o.fontSize=Math.max(8,Math.min(72,s.fontSize));if(Number.isFinite(s.weight))o.weight=Math.round(Math.max(400,Math.min(800,s.weight))/100)*100;if(/^#[0-9a-f]{6}$/i.test(s.color||''))o.color=s.color.toLowerCase();return o;}
  function normalize(text,spans){
    if(spans==null)return [];
    if(!Array.isArray(spans)||spans.length>2000)throw Error('부분 글자 서식은 2,000개 이하로 나누어 주세요.');
    const result=[];let end=0;
    for(const s of [...spans].sort((a,b)=>(a?.start||0)-(b?.start||0))){
      if(!s||!Number.isInteger(s.start)||!Number.isInteger(s.end)||s.start<0||s.end>text.length||s.end<=s.start||s.start<end)throw Error('부분 글자 서식의 선택 범위를 확인해 주세요.');
      const v={start:s.start,end:s.end,...cleanStyle(s)};end=s.end;
      if(Object.keys(v).length===2)continue;
      const prev=result.at(-1);if(prev&&prev.end===v.start&&same(prev,v))prev.end=v.end;else result.push(v);
    }return result;
  }
  function apply(text,spans,start,end,patch){
    const old=normalize(text,spans);start=Math.max(0,Math.min(text.length,start));end=Math.max(start,Math.min(text.length,end));if(start===end)return old;
    const points=[...new Set([0,text.length,start,end,...old.flatMap(s=>[s.start,s.end])])].sort((a,b)=>a-b),result=[];
    for(let i=0;i<points.length-1;i++){const a=points[i],b=points[i+1];let s=cleanStyle(old.find(v=>a>=v.start&&a<v.end)||{});if(a>=start&&b<=end)s=patch===null?{}:{...s,...cleanStyle(patch)};if(Object.keys(s).length)result.push({start:a,end:b,...s});}
    return normalize(text,result);
  }
  function edit(before,after,spans){
    const old=normalize(before,spans);let start=0,tail=0;
    while(start<before.length&&start<after.length&&before[start]===after[start])start++;
    while(tail<before.length-start&&tail<after.length-start&&before[before.length-tail-1]===after[after.length-tail-1])tail++;
    const stop=before.length-tail,insertEnd=after.length-tail,delta=after.length-before.length,out=[];
    for(const s of old){if(s.start<start)out.push({...s,end:Math.min(s.end,start)});if(s.end>stop)out.push({...s,start:Math.max(s.start,stop)+delta,end:s.end+delta});}
    const inherited=old.find(s=>start>=s.start&&start<s.end)||old.find(s=>start===s.end);
    if(inherited&&insertEnd>start)out.push({start,end:insertEnd,...cleanStyle(inherited)});
    return normalize(after,out);
  }
  function slice(text,spans,start,end){return {text:text.slice(start,end),spans:normalize(text,spans).filter(s=>s.end>start&&s.start<end).map(s=>({...s,start:Math.max(start,s.start)-start,end:Math.min(end,s.end)-start}))};}
  function normalizeBreaks(text,breaks){
    if(breaks==null)return [];if(!Array.isArray(breaks)||breaks.length>10000||breaks.some(p=>!Number.isInteger(p)||p<0||text[p]!=='\n'))throw Error('같은 항목 안의 줄바꿈 위치를 확인해 주세요.');return [...new Set(breaks)].sort((a,b)=>a-b);
  }
  function editBreaks(before,after,breaks){
    const old=normalizeBreaks(before,breaks);let start=0,tail=0;while(start<before.length&&start<after.length&&before[start]===after[start])start++;while(tail<before.length-start&&tail<after.length-start&&before[before.length-tail-1]===after[after.length-tail-1])tail++;
    return normalizeBreaks(after,old.filter(p=>p<start||p>=before.length-tail).map(p=>p<start?p:p+after.length-before.length));
  }
  function prefix(value){return String(value).match(/^[ \t]*(?:Q\d+[.．]?|\d+[.)]|[가-힣A-Za-z][.)]|[•●▪▶✓✔→\-–])[ \t]+/)?.[0]||'';}
  function normalizeLayout(value){
    value=value||{};const out={};
    if(value.wrapIndent!=null){if(!['none','prefix','custom'].includes(value.wrapIndent))throw Error('다음 줄 맞춤을 확인해 주세요.');out.wrapIndent=value.wrapIndent;}
    if(value.wrapIndentSize!=null){if(!Number.isFinite(Number(value.wrapIndentSize)))throw Error('다음 줄 들여쓰기를 확인해 주세요.');out.wrapIndentSize=Math.max(0,Math.min(240,Number(value.wrapIndentSize)));}
    if(value.listStyle!=null){if(!['plain','bullet','custom'].includes(value.listStyle))throw Error('목록 표시를 확인해 주세요.');out.listStyle=value.listStyle;}
    if(value.marker!=null){const m=value.marker;if(!m||typeof m!=='object'||!['text','emoji','image'].includes(m.type))throw Error('목차 표시를 확인해 주세요.');
      const text=String(m.text??'•');if(text.length>80||/[\u0000-\u001f]/.test(text))throw Error('목차 문자는 줄바꿈 없이 80자 이하로 넣어 주세요.');
      const src=m.src||'';if(m.type==='image'&&(typeof src!=='string'||src.length>16000000||!/^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/]+={0,2}$/i.test(src)))throw Error('목차 아이콘은 PNG·JPG·WebP 이미지를 사용해 주세요.');
      const size=m.size==null?0:Number(m.size),gap=m.gap==null?8:Number(m.gap);if(!Number.isFinite(size)||!Number.isFinite(gap))throw Error('목차 크기와 간격을 확인해 주세요.');
      out.marker={type:m.type,text,size:Math.max(0,Math.min(120,size)),gap:Math.max(0,Math.min(80,gap)),...(m.type==='image'?{src}:{})};
    }return out;
  }
  function layout(text,spans,width,base,measure,scale=1,bullets=false,softBreaks=[],options={}){
    const ranges=normalize(text,spans),lines=[],format=normalizeLayout(options);let offset=0,logicalIndent=0;
    const pieces=s=>{try{return Array.from(new Intl.Segmenter(undefined,{granularity:'grapheme'}).segment(s),v=>v.segment);}catch(_){return Array.from(s);}};
    function describe(chars,bullet){
      const runs=[];for(const ch of chars){const prev=runs.at(-1);if(prev&&same(prev,ch))prev.text+=ch.text;else runs.push({...ch});}
      let total=0,max=base.fontSize;for(const r of runs){r.width=measure(r.text,r.fontSize,r.weight);total+=r.width;max=Math.max(max,r.fontSize);}
      if(bullet&&options.markerSize)max=Math.max(max,options.markerSize);
      return {runs,width:total,size:max,height:max*base.lineHeight,bullet,text:chars.map(c=>c.text).join('')};
    }
    for(const para of text.split('\n')){
      const paragraphStart=offset;offset+=para.length+1;const continuation=softBreaks.includes(paragraphStart-1);if(bullets&&!para.trim()&&!continuation)continue;
      if(!continuation)logicalIndent=format.wrapIndent==='custom'?(format.wrapIndentSize||0):format.wrapIndent==='prefix'?measure(prefix(para),base.fontSize,base.weight):0;
      logicalIndent=Math.min(Math.max(0,width-base.fontSize),logicalIndent);
      let row=[],rowWidth=0,first=!continuation,lineOffset=continuation?logicalIndent:0;
      const flush=()=>{const line=describe(row,bullets&&first);line.offset=lineOffset;lines.push(line);first=false;lineOffset=logicalIndent;};
      let at=paragraphStart;
      for(const ch of pieces(para)){
        const s=ranges.find(s=>at>=s.start&&at<s.end)||{},c={text:ch,fontSize:s.fontSize? s.fontSize*scale:base.fontSize,weight:s.weight||base.weight,color:s.color||base.color};at+=ch.length;
        const cw=measure(ch,c.fontSize,c.weight);
        if(row.length&&rowWidth+cw>width-lineOffset){
          let space=-1;row.forEach((c,i)=>{if(c.text===' ')space=i;});
          if(space>row.length*.45){const carry=row.slice(space+1);row=row.slice(0,space);flush();row=carry;rowWidth=describe(row,false).width;}
          else {flush();row=[];rowWidth=0;}
        }
        row.push(c);rowWidth+=cw;
      }flush();
    }
    if(!lines.length)lines.push(describe([],false));return {lines,height:lines.reduce((sum,l)=>sum+l.height,0)};
  }
  function preview(text,spans){
    text=String(text??'');
    const ranges=normalize(text,spans);let at=0,html='';for(const s of ranges){html+=esc(text.slice(at,s.start));const st=cleanStyle(s);html+='<span style="'+(st.fontSize?'font-size:'+st.fontSize+'px;':'')+(st.weight?'font-weight:'+st.weight+';':'')+(st.color?'color:'+st.color+';':'')+'">'+esc(text.slice(s.start,s.end))+'</span>';at=s.end;}return html+esc(text.slice(at));
  }
  function layoutControls(value){
    const v=normalizeLayout(value),m=v.marker||{type:'text',text:'•',size:0,gap:8};
    return `<details class="rt-layout-controls"><summary>다음 줄 맞춤 · 목차 표시</summary><label class="ge-field field"><span class="field-label">다음 줄 시작 위치</span><select data-rt-layout="wrapIndent"><option value="none" ${!v.wrapIndent||v.wrapIndent==='none'?'selected':''}>기존 위치</option>${v.wrapIndent==='prefix'?'<option value="prefix" selected disabled hidden>저장된 줄맞춤 유지</option>':''}<option value="custom" ${v.wrapIndent==='custom'?'selected':''}>들여쓰기 직접 지정</option></select></label><label class="ge-field field" data-rt-custom-indent ${v.wrapIndent==='custom'?'':'hidden'}><span class="field-label">다음 줄 들여쓰기 (px)</span><input type="number" min="0" max="240" value="${v.wrapIndentSize||40}" data-rt-layout="wrapIndentSize"></label><label class="ge-field field"><span class="field-label">목록 표시</span><select data-rt-layout="listStyle"><option value="plain" ${!v.listStyle||v.listStyle==='plain'?'selected':''}>일반 글</option><option value="bullet" ${v.listStyle==='bullet'?'selected':''}>기본 글머리표</option><option value="custom" ${v.listStyle==='custom'?'selected':''}>내 문자 · 아이콘</option></select></label><div data-rt-custom-marker ${v.listStyle==='custom'?'':'hidden'}><label class="ge-field field"><span class="field-label">목차 문자 · 기호 직접 입력</span><input type="text" maxlength="80" data-rt-layout="marker.text" value="${esc(m.text)}"></label><button type="button" data-rt-pick-marker>😊 이모지 · 내 아이콘 넣기</button><div class="rt-marker-preview">${m.type==='image'?`<img src="${esc(m.src)}" alt="선택한 목차 아이콘">`:esc(m.text)}</div><label class="ge-field field"><span class="field-label">목차와 글 사이 간격 (px)</span><input type="number" min="0" max="80" value="${m.gap??8}" data-rt-layout="marker.gap"></label><label class="ge-field field"><span class="field-label">목차 크기 (px · 0은 글자와 같게)</span><input type="number" min="0" max="120" value="${m.size||0}" data-rt-layout="marker.size"></label></div><button type="button" data-rt-split-prefix>맨 앞 Q5. · 번호를 목차로 분리</button><p class="rt-break-hint">목차를 분리하면 다음 줄은 본문에 자동으로 맞춰집니다. Shift+Enter와 줄 앞 스페이스도 유지됩니다.</p></details>`;
  }
  function field(label,text,key,attrs,area=false,spans=[],format={}){text=String(text??'');return `<div class="rich-field" data-rich-field="${esc(key)}"><label class="ge-field field"><span class="field-label">${esc(label)}</span>${area?`<textarea rows="6" maxlength="10000" data-rich-input ${attrs}>${esc(text)}</textarea>`:`<input type="text" maxlength="500" data-rich-input ${attrs} value="${esc(text)}">`}</label>${area?'<p class="rt-break-hint">Enter: 새 항목·문단 · Shift+Enter: 같은 항목 안에서 줄바꿈</p>':''}<div class="rt-toolbar" role="group" aria-label="선택한 글자 서식"><button type="button" data-rich-bold title="선택한 글자를 굵게" aria-label="선택한 글자를 굵게"><b>B</b> 굵게</button><select data-rich-size aria-label="선택한 글자 크기"><option value="">크기</option>${[10,12,14,16,18,20,22,24,28,32,36,40,48,60,72].map(n=>`<option value="${n}">${n}px</option>`).join('')}</select><input type="color" data-rich-color value="#0866e8" aria-label="선택한 글자 색상"><button type="button" data-rich-clear title="선택한 글자의 부분 서식 지우기">서식 지우기</button></div><p class="rt-status" aria-live="polite">위 글에서 원하는 부분을 드래그해 선택하세요.</p><div class="rt-preview" aria-label="부분 서식 미리보기" ${spans.length?'':'hidden'}>${preview(text,spans)}</div>${layoutControls(format)}</div>`;}
  function bind(root,adapter){
    bindings.get(root)?.abort();const controller=new AbortController();bindings.set(root,controller);const options={capture:true,signal:controller.signal};
    const selections=new WeakMap();
    function update(w){const input=w.querySelector('[data-rich-input]'),range=selections.get(w)||[0,0],has=range[1]>range[0];w.querySelectorAll('.rt-toolbar button,.rt-toolbar select,.rt-toolbar input').forEach(el=>el.disabled=!has);w.querySelector('.rt-status').textContent=has?`선택한 ${range[1]-range[0]}자에만 적용합니다.`:'위 글에서 원하는 부분을 드래그해 선택하세요.';const value=adapter.read(w.dataset.richField),p=w.querySelector('.rt-preview');p.hidden=!value.spans?.length;p.innerHTML=preview(input.value,value.spans);}
    function selected(e){const input=e.target;if(!input.matches?.('[data-rich-input]'))return;const w=input.closest('[data-rich-field]');selections.set(w,[input.selectionStart,input.selectionEnd]);update(w);}
    for(const event of ['select','keyup','mouseup','focusin'])root.addEventListener(event,selected,options);
    root.addEventListener('input',e=>{const input=e.target;if(!input.matches?.('[data-rich-input]'))return;e.stopImmediatePropagation();const w=input.closest('[data-rich-field]'),old=adapter.read(w.dataset.richField);adapter.write(w.dataset.richField,input.value,edit(old.text,input.value,old.spans),editBreaks(old.text,input.value,old.softBreaks));selected(e);},options);
    root.addEventListener('keydown',e=>{const input=e.target;if(e.key!=='Enter'||!e.shiftKey||!input.matches?.('textarea[data-rich-input]'))return;e.preventDefault();e.stopImmediatePropagation();const w=input.closest('[data-rich-field]'),old=adapter.read(w.dataset.richField),start=input.selectionStart,end=input.selectionEnd,value=input.value.slice(0,start)+'\n'+input.value.slice(end),breaks=editBreaks(old.text,value,old.softBreaks);breaks.push(start);adapter.write(w.dataset.richField,value,edit(old.text,value,old.spans),normalizeBreaks(value,breaks));input.value=value;input.setSelectionRange(start+1,start+1);selected({target:input});},options);
    function currentLayout(w){return normalizeLayout(adapter.read(w.dataset.richField).layout||{});}
    function layoutUpdate(w,next){adapter.writeLayout?.(w.dataset.richField,normalizeLayout(next));w.querySelector('[data-rt-custom-indent]').hidden=next.wrapIndent!=='custom';w.querySelector('[data-rt-custom-marker]').hidden=next.listStyle!=='custom';const m=next.marker||{},p=w.querySelector('.rt-marker-preview');p.innerHTML=m.type==='image'?`<img src="${esc(m.src)}" alt="선택한 목차 아이콘">`:esc(m.text||'•');w.querySelector('[data-rt-layout="listStyle"]').value=next.listStyle||'plain';w.querySelector('[data-rt-layout="marker.text"]').value=m.text||'•';}
    function layoutEvent(e){const el=e.target,key=el.dataset.rtLayout;if(!key)return;e.stopImmediatePropagation();const w=el.closest('[data-rich-field]'),v=currentLayout(w);if(key.startsWith('marker.')){v.marker={type:'text',text:'•',size:0,gap:8,...v.marker};const part=key.split('.')[1];v.marker[part]=part==='text'?el.value:Number(el.value);if(part==='text')v.marker.type='text';}else v[key]=key==='wrapIndentSize'?Number(el.value):el.value;if(v.listStyle==='custom'&&!v.marker)v.marker={type:'text',text:'•',size:0,gap:8};layoutUpdate(w,v);}
    root.addEventListener('input',e=>{if(e.target.dataset.rtLayout&&e.target.tagName!=='SELECT')layoutEvent(e);},options);
    root.addEventListener('change',e=>{if(e.target.dataset.rtLayout)layoutEvent(e);},options);
    root.addEventListener('click',e=>{const button=e.target.closest('[data-rt-pick-marker],[data-rt-split-prefix]');if(!button)return;e.stopImmediatePropagation();const w=button.closest('[data-rich-field]'),old=adapter.read(w.dataset.richField),format=currentLayout(w);
      if(button.hasAttribute('data-rt-pick-marker')){adapter.pickIcon?.(value=>{format.listStyle='custom';format.marker={size:0,gap:8,...format.marker,...(value.icon==='image'?{type:'image',src:value.iconImage}:{type:'emoji',text:value.emoji})};layoutUpdate(w,format);});return;}
      const mark=prefix(old.text);if(!mark){adapter.notify?.('맨 앞에 Q5. 또는 번호와 공백이 있는 글에서 사용해 주세요.');return;}
      const value=old.text.slice(mark.length),spans=normalize(old.text,old.spans).filter(s=>s.end>mark.length).map(s=>({...s,start:Math.max(0,s.start-mark.length),end:s.end-mark.length})),breaks=(old.softBreaks||[]).filter(p=>p>=mark.length).map(p=>p-mark.length);format.wrapIndent='none';format.listStyle='custom';format.marker={type:'text',text:mark.trim(),size:0,gap:8};adapter.write(w.dataset.richField,value,spans,breaks,format);w.querySelector('[data-rich-input]').value=value;w.querySelector('[data-rt-layout="wrapIndent"]').value='none';layoutUpdate(w,format);update(w);
    },options);
    root.addEventListener('pointerdown',e=>{if(e.target.closest('[data-rich-bold],[data-rich-clear]'))e.preventDefault();},options);
    function format(e){const el=e.target.closest('[data-rich-bold],[data-rich-clear],[data-rich-size],[data-rich-color]');if(!el)return;const w=el.closest('[data-rich-field]');if(!w)return;e.stopImmediatePropagation();const range=selections.get(w);if(!range||range[1]<=range[0])return;const v=adapter.read(w.dataset.richField),input=w.querySelector('[data-rich-input]');let patch;
      if(el.hasAttribute('data-rich-size')){if(!el.value)return;patch={fontSize:Number(el.value)};}
      else if(el.hasAttribute('data-rich-color'))patch={color:el.value};
      else if(el.hasAttribute('data-rich-clear'))patch=null;
      else {const s=normalize(v.text,v.spans).find(s=>range[0]>=s.start&&range[0]<s.end);patch={weight:(s?.weight||v.weight||400)>=700?400:700};}
      adapter.write(w.dataset.richField,v.text,apply(v.text,v.spans,range[0],range[1],patch),v.softBreaks||[]);update(w);
      if(el.tagName==='BUTTON'){input.focus();input.setSelectionRange(...range);}el.value=el.hasAttribute('data-rich-size')?'':el.value;
    }
    root.addEventListener('click',e=>{if(e.target.closest('[data-rich-bold],[data-rich-clear]'))format(e);},options);
    root.addEventListener('change',e=>{if(e.target.matches('[data-rich-size],[data-rich-color]'))format(e);},options);
    root.querySelectorAll('[data-rich-field]').forEach(update);
  }
  window.RichText={normalize,apply,edit,slice,layout,field,bind,preview,normalizeBreaks,editBreaks,normalizeLayout,prefix};
})();
